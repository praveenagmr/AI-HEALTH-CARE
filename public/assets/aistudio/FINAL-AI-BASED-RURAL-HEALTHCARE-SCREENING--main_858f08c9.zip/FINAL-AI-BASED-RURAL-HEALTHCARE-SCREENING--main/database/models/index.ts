/**
 * Database Models and Mongoose Schemas for Varur Rural Healthcare System
 * Compatible with MongoDB Compass (mongodb://localhost:27017/rural_health_varur)
 * Includes in-memory auto-sync resilience so the application works seamlessly
 * both in local MongoDB setups and hosted web environments.
 */
import mongoose, { Schema, Document } from 'mongoose';

// 1. User Interface & Schema
export interface IUserData {
  name: string;
  mobile: string;
  email?: string;
  passwordHash: string;
  age: number;
  gender: 'male' | 'female' | 'other';
  houseId: string; // e.g. "VRR-H01"
  role: 'admin' | 'user' | 'health_worker';
  address: string;
  createdAt: Date;
}
export interface IUser extends IUserData, Document {}

const UserSchema = new Schema<IUser>({
  name: { type: String, required: true },
  mobile: { type: String, required: true, unique: true },
  email: { type: String },
  passwordHash: { type: String, required: true },
  age: { type: Number, required: true },
  gender: { type: String, enum: ['male', 'female', 'other'], default: 'male' },
  houseId: { type: String, required: true },
  role: { type: String, enum: ['admin', 'user', 'health_worker'], default: 'user' },
  address: { type: String, default: 'Varur Village, Hubballi Taluk' },
  createdAt: { type: Date, default: Date.now },
});

// 2. House Interface & Schema (15 Houses of Varur)
export interface IHouseData {
  houseId: string; // e.g., "VRR-H01"
  headOfFamily: string;
  familyMembersCount: number;
  contactNumber: string;
  addressLine: string;
  landmark: string;
  latitude: number;
  longitude: number;
  rationCardNo?: string;
  registeredDate: Date;
  notes?: string;
}
export interface IHouse extends IHouseData, Document {}

const HouseSchema = new Schema<IHouse>({
  houseId: { type: String, required: true, unique: true },
  headOfFamily: { type: String, required: true },
  familyMembersCount: { type: Number, required: true, min: 1 },
  contactNumber: { type: String, required: true },
  addressLine: { type: String, required: true },
  landmark: { type: String, required: true },
  latitude: { type: Number, required: true },
  longitude: { type: Number, required: true },
  rationCardNo: { type: String },
  registeredDate: { type: Date, default: Date.now },
  notes: { type: String },
});

// 3. Health Screening Result Interface & Schema
export interface IScreening extends Document {
  screeningId: string;
  userId: string;
  userName: string;
  userMobile: string;
  houseId: string;
  age: number;
  gender: string;
  symptoms: string[];
  durationDays: number;
  vitals?: {
    temperatureF?: number;
    bloodPressure?: string;
    pulseRate?: number;
    oxygenSaturationSpO2?: number;
  };
  preExistingConditions: string[];
  lifestyleNotes?: string;
  // AI screening results
  riskLevel: 'Low' | 'Moderate' | 'High';
  preliminaryCondition: string;
  explanation: string;
  recommendations: string[];
  urgentActionRequired: boolean;
  prescribedOtcMedicines?: string[];
  nearestHospitalReferral?: string;
  language: 'kannada' | 'hindi' | 'english';
  createdAt: Date;
}

const ScreeningSchema = new Schema<IScreening>({
  screeningId: { type: String, required: true, unique: true },
  userId: { type: String, required: true },
  userName: { type: String, required: true },
  userMobile: { type: String, required: true },
  houseId: { type: String, required: true },
  age: { type: Number, required: true },
  gender: { type: String, required: true },
  symptoms: [{ type: String }],
  durationDays: { type: Number, default: 1 },
  vitals: {
    temperatureF: Number,
    bloodPressure: String,
    pulseRate: Number,
    oxygenSaturationSpO2: Number,
  },
  preExistingConditions: [{ type: String }],
  lifestyleNotes: String,
  riskLevel: { type: String, enum: ['Low', 'Moderate', 'High'], required: true },
  preliminaryCondition: { type: String, required: true },
  explanation: { type: String, required: true },
  recommendations: [{ type: String }],
  urgentActionRequired: { type: Boolean, default: false },
  prescribedOtcMedicines: [{ type: String }],
  nearestHospitalReferral: String,
  language: { type: String, default: 'english' },
  createdAt: { type: Date, default: Date.now },
});

// 4. Medical Store (Pharmacy) Interface & Schema
export interface IMedicalStore extends Document {
  storeId: string;
  name: string;
  ownerName: string;
  phone: string;
  alternatePhone?: string;
  location: string;
  landmark: string;
  distanceFromVarurCenterKm: number;
  homeDeliveryAvailable: boolean;
  deliveryTimeMins: number;
  openingHours: string;
  isOpen24x7: boolean;
  latitude: number;
  longitude: number;
  availableMedicines: string[];
}

const MedicalStoreSchema = new Schema<IMedicalStore>({
  storeId: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  ownerName: { type: String, required: true },
  phone: { type: String, required: true },
  alternatePhone: String,
  location: { type: String, required: true },
  landmark: { type: String, required: true },
  distanceFromVarurCenterKm: { type: Number, default: 0.5 },
  homeDeliveryAvailable: { type: Boolean, default: true },
  deliveryTimeMins: { type: Number, default: 30 },
  openingHours: { type: String, default: '8:00 AM - 10:00 PM' },
  isOpen24x7: { type: Boolean, default: false },
  latitude: { type: Number, required: true },
  longitude: { type: Number, required: true },
  availableMedicines: [{ type: String }],
});

// 5. Hospital Interface & Schema
export interface IHospital extends Document {
  hospitalId: string;
  name: string;
  type: 'PHC' | 'Government Hospital' | 'Multi-Speciality' | 'Private Clinic';
  phone: string;
  ambulancePhone: string;
  location: string;
  distanceFromVarurKm: number;
  emergency24x7: boolean;
  icuAvailable: boolean;
  specialities: string[];
  address: string;
  latitude: number;
  longitude: number;
  nearbyMedicals: string[];
}

const HospitalSchema = new Schema<IHospital>({
  hospitalId: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  type: { type: String, required: true },
  phone: { type: String, required: true },
  ambulancePhone: { type: String, required: true },
  location: { type: String, required: true },
  distanceFromVarurKm: { type: Number, required: true },
  emergency24x7: { type: Boolean, default: true },
  icuAvailable: { type: Boolean, default: true },
  specialities: [{ type: String }],
  address: { type: String, required: true },
  latitude: { type: Number, required: true },
  longitude: { type: Number, required: true },
  nearbyMedicals: [{ type: String }],
});

// 6. Medicine Order Interface & Schema
export interface IMedicineOrder extends Document {
  orderId: string;
  userId: string;
  userName: string;
  userPhone: string;
  houseId: string;
  deliveryAddress: string;
  pharmacyId: string;
  pharmacyName: string;
  items: {
    name: string;
    quantity: number;
    dosage?: string;
    price: number;
  }[];
  totalAmount: number;
  orderStatus: 'Placed' | 'Confirmed' | 'Out for Village Delivery' | 'Delivered' | 'Cancelled';
  paymentMode: 'Cash on Delivery' | 'UPI at Doorstep';
  prescriptionUploaded?: boolean;
  notes?: string;
  orderedAt: Date;
  deliveredAt?: Date;
}

const MedicineOrderSchema = new Schema<IMedicineOrder>({
  orderId: { type: String, required: true, unique: true },
  userId: { type: String, required: true },
  userName: { type: String, required: true },
  userPhone: { type: String, required: true },
  houseId: { type: String, required: true },
  deliveryAddress: { type: String, required: true },
  pharmacyId: { type: String, required: true },
  pharmacyName: { type: String, required: true },
  items: [
    {
      name: { type: String, required: true },
      quantity: { type: Number, default: 1 },
      dosage: String,
      price: { type: Number, required: true },
    },
  ],
  totalAmount: { type: Number, required: true },
  orderStatus: {
    type: String,
    enum: ['Placed', 'Confirmed', 'Out for Village Delivery', 'Delivered', 'Cancelled'],
    default: 'Placed',
  },
  paymentMode: { type: String, default: 'Cash on Delivery' },
  prescriptionUploaded: { type: Boolean, default: false },
  notes: String,
  orderedAt: { type: Date, default: Date.now },
  deliveredAt: Date,
});

// Export Mongoose Models (with safe fallback for reload environments)
export const UserModel = mongoose.models.User || mongoose.model<IUser>('User', UserSchema);
export const HouseModel = mongoose.models.House || mongoose.model<IHouse>('House', HouseSchema);
export const ScreeningModel = mongoose.models.Screening || mongoose.model<IScreening>('Screening', ScreeningSchema);
export const MedicalStoreModel = mongoose.models.MedicalStore || mongoose.model<IMedicalStore>('MedicalStore', MedicalStoreSchema);
export const HospitalModel = mongoose.models.Hospital || mongoose.model<IHospital>('Hospital', HospitalSchema);
export const MedicineOrderModel = mongoose.models.MedicineOrder || mongoose.model<IMedicineOrder>('MedicineOrder', MedicineOrderSchema);
