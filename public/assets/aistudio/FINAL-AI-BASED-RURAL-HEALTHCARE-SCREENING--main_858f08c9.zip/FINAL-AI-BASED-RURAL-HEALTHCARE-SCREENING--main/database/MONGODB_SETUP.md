# MongoDB Compass Connection Guide - Varur Rural Healthcare

### Direct Connection URI for MongoDB Compass:
```
mongodb://localhost:27017/rural_health_varur
```

---

### File Structure:
```
├── database/
│   ├── connection.ts          <- Mongoose connection with resilient fallback & auto-sync
│   ├── seedData.ts            <- 15 Varur village houses, 4 medicals, 5 hospitals
│   ├── models/
│   │   └── index.ts           <- Mongoose schemas (User, House, Screening, MedicalStore, Hospital, MedicineOrder)
│   └── MONGODB_SETUP.md       <- This guide
├── backend/
│   ├── geminiClient.ts        <- Server-side GoogleGenAI configuration
│   ├── middleware/
│   │   └── auth.ts            <- JWT verification & Admin authorization
│   └── routes/
│       ├── auth.ts            <- Register, Login, Me with JWT
│       ├── screening.ts       <- 11-step health screening & explainable AI
│       ├── assistant.ts       <- Multilingual voice & chat assistant
│       ├── houses.ts          <- 15 houses data & new house registration
│       ├── healthcare.ts      <- Varur PHC, KIMS Hospital, pharmacies
│       └── orders.ts          <- Doorstep medicine delivery
└── frontend/ (src/)
    ├── context/               <- Auth, Language (3 languages), Day/Night Mode
    ├── i18n/                  <- Translations (Kannada, Hindi, English)
    └── components/            <- Screening Wizard, Voice Assistant, Admin Panel, Orders
```

---

### Step-by-Step Instructions to Connect MongoDB Compass:

1. **Start MongoDB locally** on your system:
   ```bash
   # Windows (via Services or cmd)
   net start MongoDB
   
   # Or run directly
   mongod --dbpath <your_db_folder>
   
   # Linux / macOS
   sudo systemctl start mongod
   # or
   brew services start mongodb-community
   ```

2. **Open MongoDB Compass**:
   - In the connection window, paste:
     ```
     mongodb://localhost:27017/rural_health_varur
     ```
   - Click **Connect**.

3. **Collections Available in Database `rural_health_varur`**:
   - `users`: Registered village users & Admin profile.
   - `houses`: 15 accurate households in Varur village (VRR-H01 to VRR-H15) + new registrations.
   - `screenings`: Clinical AI triage reports, symptoms, vitals, risk level, explainability.
   - `medicalstores`: Local pharmacies with home delivery.
   - `hospitals`: Nearby referral hospitals with ambulance & distances.
   - `medicineorders`: Varur village doorstep delivery orders.

4. **Admin Credentials**:
   - **Mobile Number:** `8073370065`
   - **Password:** `dj123456`
   *(Admin has exclusive rights to view & edit all 15 houses, view all patient screenings, and update medicine delivery status)*
