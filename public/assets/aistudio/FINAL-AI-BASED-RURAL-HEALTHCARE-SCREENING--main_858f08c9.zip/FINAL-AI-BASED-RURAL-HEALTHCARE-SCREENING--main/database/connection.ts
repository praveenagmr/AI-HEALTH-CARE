/**
 * MongoDB Connection Handler & Store Synchronizer
 * Designed for direct connection with MongoDB Compass:
 * Connection String: mongodb://localhost:27017/rural_health_varur
 */
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import {
  UserModel,
  HouseModel,
  MedicalStoreModel,
  HospitalModel,
  ScreeningModel,
  MedicineOrderModel,
  IUser,
  IHouse,
  IScreening,
  IMedicalStore,
  IHospital,
  IMedicineOrder,
} from './models/index.ts';
import {
  ADMIN_PHONE,
  ADMIN_DEFAULT_PASS,
  INITIAL_HOUSES,
  INITIAL_MEDICAL_STORES,
  INITIAL_HOSPITALS,
} from './seedData.ts';

export const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/rural_health_varur';

export let isConnectedToMongo = false;

// Fallback in-memory cache synchronized with MongoDB so the app runs smoothly
// even if MongoDB service is offline or being launched locally
export class LocalDataStore {
  static users: any[] = [];
  static houses: any[] = [];
  static screenings: any[] = [];
  static medicalStores: any[] = [];
  static hospitals: any[] = [];
  static medicineOrders: any[] = [];
  static initialized = false;
}

export async function initSeedData() {
  if (LocalDataStore.initialized) return;

  const adminPasswordHash = await bcrypt.hash(ADMIN_DEFAULT_PASS, 10);
  const defaultAdmin: Partial<IUser> = {
    name: 'Praveen Hottiholi (Admin)',
    mobile: ADMIN_PHONE,
    email: 'praveen.admin@varurhealth.org',
    passwordHash: adminPasswordHash,
    age: 32,
    gender: 'male',
    houseId: 'VRR-H14',
    role: 'admin',
    address: 'Grama Chavadi Road, Near Panchayat Hall, Varur',
    createdAt: new Date(),
  };

  // Seed into in-memory store
  LocalDataStore.users = [defaultAdmin as IUser];
  LocalDataStore.houses = INITIAL_HOUSES.map((h) => ({
    ...h,
    registeredDate: new Date(),
  })) as unknown as IHouse[];
  LocalDataStore.medicalStores = INITIAL_MEDICAL_STORES as unknown as IMedicalStore[];
  LocalDataStore.hospitals = INITIAL_HOSPITALS as unknown as IHospital[];
  LocalDataStore.screenings = [
    {
      screeningId: 'SCR-VRR-DEMO-01',
      userId: 'admin-001',
      userName: 'Suresh Patil',
      userMobile: '9480112340',
      houseId: 'VRR-H01',
      age: 58,
      gender: 'male',
      symptoms: ['Fever', 'Cough', 'Body pain'],
      durationDays: 3,
      vitals: {
        temperatureF: 101.2,
        bloodPressure: '135/85',
        pulseRate: 88,
        oxygenSaturationSpO2: 97,
      },
      preExistingConditions: ['Hypertension'],
      riskLevel: 'Moderate',
      preliminaryCondition: 'Acute Upper Respiratory Tract Infection (Flu / Seasonal Viral)',
      explanation: 'Combination of fever (>101°F) for 3 days with persistent cough and pre-existing hypertension elevates risk. Oxygen saturation is stable (97%).',
      recommendations: [
        'Visit Varur Primary Health Centre (PHC) for clinical examination and auscultation.',
        'Paracetamol 650mg after food for fever control.',
        'Drink boiled and cooled water with ORS.',
        'Immediate warning: If breathing difficulty develops, rush to KIMS Hubballi.',
      ],
      urgentActionRequired: false,
      prescribedOtcMedicines: ['Paracetamol 650mg (Dolo 650)', 'ORS Sachet', 'Ayurvedic Cough Syrup'],
      nearestHospitalReferral: 'Primary Health Centre (PHC) Varur (0.8 km)',
      language: 'english',
      createdAt: new Date(Date.now() - 86400000),
    } as unknown as IScreening,
  ];

  LocalDataStore.medicineOrders = [
    {
      orderId: 'ORD-VRR-1001',
      userId: 'usr-demo-01',
      userName: 'Suresh Patil',
      userPhone: '9480112340',
      houseId: 'VRR-H01',
      deliveryAddress: 'Main Bazaar Road, Near Old Banyan Tree, House VRR-H01, Varur',
      pharmacyId: 'MED-VRR-01',
      pharmacyName: 'Shri Basaveshwara Medical & General Stores',
      items: [
        { name: 'Paracetamol 650mg (Dolo 650)', quantity: 2, price: 32 },
        { name: 'ORS Oral Rehydration Salts', quantity: 3, price: 21 },
        { name: 'Ayurvedic Cough Syrup', quantity: 1, price: 95 },
      ],
      totalAmount: 222,
      orderStatus: 'Out for Village Delivery',
      paymentMode: 'Cash on Delivery',
      orderedAt: new Date(Date.now() - 3600000),
    } as unknown as IMedicineOrder,
  ];

  LocalDataStore.initialized = true;

  // If MongoDB is connected, sync documents if collections are empty
  if (isConnectedToMongo) {
    try {
      const houseCount = await HouseModel.countDocuments();
      if (houseCount === 0) {
        await HouseModel.insertMany(LocalDataStore.houses);
        console.log('🌱 Seeded 15 Varur Houses into MongoDB');
      }

      const medicalCount = await MedicalStoreModel.countDocuments();
      if (medicalCount === 0) {
        await MedicalStoreModel.insertMany(LocalDataStore.medicalStores);
        console.log('🌱 Seeded 4 Medical Stores into MongoDB');
      }

      const hospCount = await HospitalModel.countDocuments();
      if (hospCount === 0) {
        await HospitalModel.insertMany(LocalDataStore.hospitals);
        console.log('🌱 Seeded 5 Hospitals into MongoDB');
      }

      const adminCount = await UserModel.countDocuments({ mobile: ADMIN_PHONE });
      if (adminCount === 0) {
        await UserModel.create(defaultAdmin);
        console.log(`🌱 Created Admin user (${ADMIN_PHONE}) in MongoDB`);
      }
    } catch (err) {
      console.warn('MongoDB initial seeding notice:', err);
    }
  }
}

export async function connectToMongoDB(): Promise<boolean> {
  try {
    mongoose.set('strictQuery', false);
    // Timeout quickly so local development doesn't block if local mongod is not started yet
    await mongoose.connect(MONGODB_URI, {
      serverSelectionTimeoutMS: 2500,
      connectTimeoutMS: 2500,
    });
    isConnectedToMongo = true;
    console.log(`✅ Connected successfully to MongoDB at: ${MONGODB_URI}`);
    await initSeedData();
    return true;
  } catch (error: any) {
    isConnectedToMongo = false;
    console.log(`ℹ️ MongoDB offline/not detected (${error?.message || 'timeout'}). App running with seamless synchronized in-memory database.`);
    console.log(`👉 To connect MongoDB Compass directly, ensure MongoDB is running and connect to: ${MONGODB_URI}`);
    await initSeedData();
    return false;
  }
}
