/**
 * Gemini Client for Varur Rural Health System
 * Uses modern @google/genai SDK with server-side proxy
 */
import { GoogleGenAI } from '@google/genai';

export const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});
