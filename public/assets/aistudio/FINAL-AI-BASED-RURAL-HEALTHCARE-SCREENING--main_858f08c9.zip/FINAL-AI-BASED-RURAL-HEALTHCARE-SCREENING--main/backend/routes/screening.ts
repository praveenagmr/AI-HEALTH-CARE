/**
 * Health Screening Routes (Steps 5 to 11)
 * Validates patient data, queries Gemini 3.8 Flash for explainable rural health triage,
 * and records reports into MongoDB / LocalStore.
 */
import { Router, Response } from 'express';
import { ai } from '../geminiClient.ts';
import { Type } from '@google/genai';
import { ScreeningModel, IScreening } from '../../database/models/index.ts';
import { LocalDataStore, isConnectedToMongo } from '../../database/connection.ts';
import { optionalAuth, verifyAuthToken, AuthenticatedRequest } from '../middleware/auth.ts';

const router = Router();

// POST /api/screening/submit
router.post('/submit', optionalAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user;
    const {
      patientName,
      patientMobile,
      houseId: inputHouseId,
      age,
      gender,
      symptoms,
      durationDays,
      vitals,
      preExistingConditions,
      lifestyleNotes,
      language = 'english',
    } = req.body;

    // STEP 6: Data Validation
    // "before sending the information to the ai model, the system checks whether the entered information is valid.
    // if something is missing or invalid: the system should response as please enter the valid health information."
    const parsedAge = Number(age);
    if (!age || isNaN(parsedAge) || parsedAge < 1 || parsedAge > 120) {
      return res.status(400).json({ error: 'Please enter the valid health information: Age must be between 1 and 120.' });
    }

    if (!gender || !['male', 'female', 'other'].includes(String(gender).toLowerCase())) {
      return res.status(400).json({ error: 'Please enter the valid health information: Please select a valid gender.' });
    }

    if (!Array.isArray(symptoms) || symptoms.length === 0) {
      return res.status(400).json({ error: 'Please enter the valid health information: Please select at least one symptom.' });
    }

    const parsedDuration = Number(durationDays) || 1;
    if (parsedDuration < 1 || parsedDuration > 365) {
      return res.status(400).json({ error: 'Please enter the valid health information: Please provide a valid symptom duration in days.' });
    }

    // STEP 7: Data Processing
    const processedData = {
      patientName: patientName?.trim() || user?.name || 'Varur Resident',
      patientMobile: patientMobile?.trim() || user?.mobile || '9480000000',
      houseId: inputHouseId || user?.houseId || 'VRR-H01',
      age: parsedAge,
      gender: String(gender).toLowerCase(),
      symptoms: symptoms.map((s: string) => s.trim()),
      durationDays: parsedDuration,
      vitals: {
        temperatureF: vitals?.temperatureF ? Number(vitals.temperatureF) : undefined,
        bloodPressure: vitals?.bloodPressure ? String(vitals.bloodPressure).trim() : undefined,
        pulseRate: vitals?.pulseRate ? Number(vitals.pulseRate) : undefined,
        oxygenSaturationSpO2: vitals?.oxygenSaturationSpO2 ? Number(vitals.oxygenSaturationSpO2) : undefined,
      },
      preExistingConditions: Array.isArray(preExistingConditions) ? preExistingConditions : [],
      lifestyleNotes: lifestyleNotes ? String(lifestyleNotes).trim() : '',
      language: ['kannada', 'hindi', 'english'].includes(language) ? language : 'english',
    };

    // STEP 8 & 9 & 10: AI / ML Screening with Gemini 3.8 Flash
    const systemPrompt = `You are a clinical decision-support AI for rural health screening in Varur village (Hubballi taluk, Dharwad, Karnataka, India).
Your purpose is triage and early screening guidance for villagers where immediate doctors may not be at hand.
CRITICAL MANDATE:
1. You are NOT replacing a doctor. You provide early screening, risk categorization (Low, Moderate, High), explainable clinical reasoning, home care guidance, OTC medicine suggestions, and nearest hospital referrals.
2. Local Varur medical landscape:
   - Village clinic / 24x7 Sub-centre: Primary Health Centre (PHC) Varur (0.8 km)
   - Tertiary / Super-speciality referral: KIMS Hospital Hubballi (16.5 km) or Lifeline Hospital Hubballi (15 km)
   - Local village pharmacies with home delivery: Shri Basaveshwara Medicals, Jain Medicals, Sanjeevani Medicals, Jan Aushadhi Kendra Varur.
3. Respond in the requested language: "${processedData.language}".
   - If "kannada", write the explanation, recommendations, and condition in clear, natural Kannada (ಕನ್ನಡ ಲಿಪಿ).
   - If "hindi", write in Hindi (हिंदी ಲಿಪಿ).
   - If "english", write in English.
4. Categorize risk:
   - "High" if red flags exist (difficulty breathing, chest tightness, oxygen < 94%, severe vomiting/dehydration, high fever > 4 days, elderly/comorbid).
   - "Moderate" if persistent symptoms (> 3 days), fever, moderate body pain needing clinic check.
   - "Low" if mild acute symptoms (< 2 days), clear viral prodrome without red flags.`;

    const userPrompt = `Analyze the following patient screening data for a resident of Varur village:
- Patient Age: ${processedData.age}
- Gender: ${processedData.gender}
- Village House ID: ${processedData.houseId}
- Symptoms: ${processedData.symptoms.join(', ')}
- Symptom Duration: ${processedData.durationDays} days
- Vitals: Temperature: ${processedData.vitals.temperatureF || 'Not measured'} °F, Blood Pressure: ${processedData.vitals.bloodPressure || 'Not measured'}, Pulse: ${processedData.vitals.pulseRate || 'Not measured'} bpm, SpO2: ${processedData.vitals.oxygenSaturationSpO2 || 'Not measured'} %
- Pre-existing Conditions: ${processedData.preExistingConditions.join(', ') || 'None reported'}
- Additional Notes: ${processedData.lifestyleNotes || 'None'}
- Target Response Language: ${processedData.language}

Provide a comprehensive, empathetic, explainable screening assessment.`;

    let aiResult: any = null;

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: userPrompt,
        config: {
          systemInstruction: systemPrompt,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              riskLevel: {
                type: Type.STRING,
                description: 'Must be exactly "Low", "Moderate", or "High"',
              },
              preliminaryCondition: {
                type: Type.STRING,
                description: 'Name of the suspected health problem / disease category',
              },
              explanation: {
                type: Type.STRING,
                description: 'Step 9: Why the system produced this result, correlating symptoms and vitals.',
              },
              recommendations: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'Step 10: Step-by-step guidance for patient and family.',
              },
              urgentActionRequired: {
                type: Type.BOOLEAN,
                description: 'True if immediate hospital visit/ambulance is warranted.',
              },
              prescribedOtcMedicines: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'Safe Over-the-counter remedies available in Varur village medicals.',
              },
              nearestHospitalReferral: {
                type: Type.STRING,
                description: 'Specific facility (e.g. Varur PHC for mild/moderate, KIMS Hospital Hubballi for high/emergency).',
              },
            },
            required: ['riskLevel', 'preliminaryCondition', 'explanation', 'recommendations', 'urgentActionRequired'],
          },
        },
      });

      if (response.text) {
        aiResult = JSON.parse(response.text.trim());
      }
    } catch (apiError) {
      console.warn('Gemini API call returned error or fallback mode, generating rule-based triage:', apiError);
    }

    // Rule-based clinical triage fallback ensuring 100% reliability
    if (!aiResult) {
      const hasBreathingDifficulty = processedData.symptoms.some((s) =>
        s.toLowerCase().includes('breath') || s.toLowerCase().includes('chest')
      );
      const hasHighFever = (processedData.vitals.temperatureF || 0) >= 102 || (processedData.durationDays > 4 && processedData.symptoms.includes('Fever'));
      const hasLowOxygen = (processedData.vitals.oxygenSaturationSpO2 || 100) < 94;

      let risk: 'Low' | 'Moderate' | 'High' = 'Low';
      let urgent = false;
      let condition = 'Mild Viral Infection / Seasonal Cold';

      if (hasBreathingDifficulty || hasLowOxygen || (processedData.age > 60 && hasHighFever)) {
        risk = 'High';
        urgent = true;
        condition = 'Possible Acute Lower Respiratory Infection / Severe Systemic Illness';
      } else if (hasHighFever || processedData.durationDays >= 3 || processedData.symptoms.length >= 3) {
        risk = 'Moderate';
        condition = 'Possible Acute Respiratory Infection / Prolonged Viral Pyrexia';
      }

      const isKannada = processedData.language === 'kannada';
      const isHindi = processedData.language === 'hindi';

      let explanation = `The patient presents with ${processedData.symptoms.join(', ')} lasting ${processedData.durationDays} day(s). `;
      if (risk === 'High') {
        explanation += 'Presence of breathing difficulty or abnormal vitals warrants high vigilance and urgent clinical evaluation.';
      } else if (risk === 'Moderate') {
        explanation += 'Moderate risk assigned due to symptom duration (> 3 days) or multiple systemic complaints requiring physical examination.';
      } else {
        explanation += 'Symptoms appear localized and mild with stable vitals, consistent with early viral prodrome.';
      }

      if (isKannada) {
        explanation = `ರೋಗಿಯಲ್ಲಿ ${processedData.symptoms.join(', ')} ಲಕ್ಷಣಗಳು ${processedData.durationDays} ದಿನಗಳಿಂದ ಕಂಡುಬಂದಿವೆ. ${
          risk === 'High'
            ? 'ಉಸಿರಾಟದ ತೊಂದರೆ ಅಥವಾ ಜ್ವರದ ತೀವ್ರತೆಯಿಂದಾಗಿ ತಕ್ಷಣ ವೈದ್ಯಕೀಯ ಪರೀಕ್ಷೆ ಅಗತ್ಯವಿದೆ.'
            : 'ಲಕ್ಷಣಗಳ ಆಧಾರದಲ್ಲಿ ಪ್ರಾಥಮಿಕ ಆರೋಗ್ಯ ಕೇಂದ್ರ ವರೂರಿನಲ್ಲಿ ವೈದ್ಯರನ್ನು ಸಂಪರ್ಕಿಸುವುದು ಸೂಕ್ತ.'
        }`;
      } else if (isHindi) {
        explanation = `मरीज में ${processedData.symptoms.join(', ')} के लक्षण ${processedData.durationDays} दिनों से हैं। ${
          risk === 'High'
            ? 'सांस लेने में कठिनाई या उच्च बुखार के कारण तत्काल अस्पताल जाने की सलाह दी जाती है।'
            : 'लक्षणों के आधार पर प्राथमिक स्वास्थ्य केंद्र वरूर में जांच की आवश्यकता है।'
        }`;
      }

      aiResult = {
        riskLevel: risk,
        preliminaryCondition: isKannada ? (risk === 'High' ? 'ತೀವ್ರ ಉಸಿರಾಟದ ಸೋಂಕು / ಜ್ವರ' : 'ಸಾಮಾನ್ಯ ವೈರಲ್ ಜ್ವರ ಮತ್ತು ಶೀತ') : condition,
        explanation,
        recommendations: isKannada
          ? [
              'ದಯವಿಟ್ಟು ವರೂರು ಪ್ರಾಥಮಿಕ ಆರೋಗ್ಯ ಕೇಂದ್ರ (PHC) ಅಥವಾ ಹುಬ್ಬಳ್ಳಿ ಕಿಮ್ಸ್ (KIMS) ಆಸ್ಪತ್ರೆಗೆ ಭೇಟಿ ನೀಡಿ.',
              'ಸಾಕಷ್ಟು ಪ್ರಮಾಣದಲ್ಲಿ ಕುದಿಸಿ ಆರಿಸಿದ ನೀರು ಮತ್ತು ಓಆರ್ಎಸ್ (ORS) ದ್ರಾವಣ ಸೇವಿಸಿ.',
              'ಜ್ವರ ನಿಯಂತ್ರಣಕ್ಕೆ ಪ್ಯಾರಸಿಟಮಾಲ್ ತೆಗೆದುಕೊಳ್ಳಿ (ಆಹಾರದ ನಂತರ).',
              'ನೆನಪಿರಲಿ: ಈ ತಂತ್ರಾಂಶವು ವೈದ್ಯರಿಗೆ ಪರ್ಯಾಯವಲ್ಲ, ಪ್ರಾಥಮಿಕ ಮಾರ್ಗದರ್ಶನಕ್ಕಾಗಿ ಮಾತ್ರ.',
            ]
          : [
              'Consult a healthcare professional at Varur PHC for formal diagnosis and stethoscope examination.',
              'Stay well hydrated with boiled drinking water and ORS electrolyte solution.',
              'Take Paracetamol 650mg after food for fever or body ache if temperature is elevated.',
              'Important: This system is not replacing a doctor, it is helping with early screening and guidance.',
            ],
        urgentActionRequired: urgent,
        prescribedOtcMedicines: ['Paracetamol 650mg (Dolo 650)', 'ORS Oral Rehydration Salts', 'Ayurvedic Cough Syrup'],
        nearestHospitalReferral: risk === 'High' ? 'KIMS Hospital Hubballi (16.5 km) / Dial 108' : 'Varur Primary Health Centre (PHC) (0.8 km)',
      };
    }

    // STEP 11: Create & Save Screening Record
    const screeningId = `SCR-VRR-${Date.now().toString().slice(-6)}`;
    const newScreeningObj = {
      screeningId,
      userId: user ? user.id : 'guest-triage',
      userName: processedData.patientName,
      userMobile: processedData.patientMobile,
      houseId: processedData.houseId,
      age: processedData.age,
      gender: processedData.gender,
      symptoms: processedData.symptoms,
      durationDays: processedData.durationDays,
      vitals: processedData.vitals,
      preExistingConditions: processedData.preExistingConditions,
      lifestyleNotes: processedData.lifestyleNotes,
      riskLevel: aiResult.riskLevel,
      preliminaryCondition: aiResult.preliminaryCondition,
      explanation: aiResult.explanation,
      recommendations: aiResult.recommendations,
      urgentActionRequired: Boolean(aiResult.urgentActionRequired),
      prescribedOtcMedicines: aiResult.prescribedOtcMedicines || [],
      nearestHospitalReferral: aiResult.nearestHospitalReferral || 'Varur Primary Health Centre (PHC)',
      language: processedData.language,
      createdAt: new Date(),
    };

    if (isConnectedToMongo) {
      await ScreeningModel.create(newScreeningObj);
    } else {
      LocalDataStore.screenings.unshift(newScreeningObj as unknown as IScreening);
    }

    return res.status(201).json({
      message: 'Screening processed successfully.',
      screening: newScreeningObj,
    });
  } catch (error: any) {
    console.error('Screening submission error:', error);
    return res.status(500).json({ error: 'Failed to process health screening. Please check inputs and try again.' });
  }
});

// GET /api/screening/history
router.get('/history', verifyAuthToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    let list: any[] = [];

    // Admin sees all village records; regular user only sees their own
    if (user.role === 'admin') {
      if (isConnectedToMongo) {
        list = await ScreeningModel.find().sort({ createdAt: -1 });
      } else {
        list = [...LocalDataStore.screenings].sort(
          (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
      }
    } else {
      if (isConnectedToMongo) {
        list = await ScreeningModel.find({
          $or: [{ userId: user.id }, { userMobile: user.mobile }, { houseId: user.houseId }],
        }).sort({ createdAt: -1 });
      } else {
        list = LocalDataStore.screenings.filter(
          (s) => s.userId === user.id || s.userMobile === user.mobile || s.houseId === user.houseId
        );
      }
    }

    return res.json({ screenings: list });
  } catch (error) {
    return res.status(500).json({ error: 'Failed to load screening history' });
  }
});

// GET /api/screening/:id
router.get('/:id', verifyAuthToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const { id } = req.params;

    let item: any = null;
    if (isConnectedToMongo) {
      item = await ScreeningModel.findOne({ screeningId: id });
    } else {
      item = LocalDataStore.screenings.find((s) => s.screeningId === id);
    }

    if (!item) {
      return res.status(404).json({ error: 'Screening report not found' });
    }

    // Role check: non-admin can only view their own
    if (user.role !== 'admin' && item.userId !== user.id && item.userMobile !== user.mobile && item.houseId !== user.houseId) {
      return res.status(403).json({ error: 'Access denied to this patient record.' });
    }

    return res.json({ screening: item });
  } catch (error) {
    return res.status(500).json({ error: 'Failed to retrieve screening details' });
  }
});

export default router;
