/**
 * Medicine Ordering & Home Delivery Routes for Varur Village
 * Allows villagers to order OTC/prescribed medicines for delivery to their House ID.
 */
import { Router, Response } from 'express';
import { MedicineOrderModel, IMedicineOrder } from '../../database/models/index.ts';
import { LocalDataStore, isConnectedToMongo } from '../../database/connection.ts';
import { verifyAuthToken, requireAdmin, AuthenticatedRequest } from '../middleware/auth.ts';

const router = Router();

// POST /api/orders (Place Medicine Order)
router.post('/', verifyAuthToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const { pharmacyId, pharmacyName, items, deliveryAddress, houseId, notes, paymentMode = 'Cash on Delivery' } = req.body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'Please select at least one medicine item to order.' });
    }

    const totalAmount = items.reduce((acc: number, item: any) => {
      const price = Number(item.price) || 0;
      const qty = Number(item.quantity) || 1;
      return acc + price * qty;
    }, 0);

    const orderId = `ORD-VRR-${Math.floor(1000 + Math.random() * 9000)}`;

    const newOrderObj = {
      orderId,
      userId: user.id,
      userName: user.name,
      userPhone: user.mobile,
      houseId: houseId || user.houseId || 'VRR-H01',
      deliveryAddress: deliveryAddress || `House ${user.houseId || 'VRR-H01'}, Varur Village`,
      pharmacyId: pharmacyId || 'MED-VRR-01',
      pharmacyName: pharmacyName || 'Shri Basaveshwara Medical & General Stores, Varur',
      items,
      totalAmount,
      orderStatus: 'Placed',
      paymentMode,
      notes: notes || '',
      orderedAt: new Date(),
    };

    let savedOrder: any = null;
    if (isConnectedToMongo) {
      savedOrder = await MedicineOrderModel.create(newOrderObj);
    } else {
      savedOrder = newOrderObj as unknown as IMedicineOrder;
      LocalDataStore.medicineOrders.unshift(savedOrder);
    }

    return res.status(201).json({
      message: `Medicine order placed successfully! Local delivery will reach House ${newOrderObj.houseId} in Varur within 30-45 minutes.`,
      order: savedOrder,
    });
  } catch (error) {
    console.error('Order creation error:', error);
    return res.status(500).json({ error: 'Failed to place medicine order' });
  }
});

// GET /api/orders/my (User's Own Orders)
router.get('/my', verifyAuthToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    let orders: any[] = [];

    if (isConnectedToMongo) {
      orders = await MedicineOrderModel.find({
        $or: [{ userId: user.id }, { userPhone: user.mobile }, { houseId: user.houseId }],
      }).sort({ orderedAt: -1 });
    } else {
      orders = LocalDataStore.medicineOrders.filter(
        (o) => o.userId === user.id || o.userPhone === user.mobile || o.houseId === user.houseId
      );
    }

    return res.json({ orders });
  } catch (error) {
    return res.status(500).json({ error: 'Failed to retrieve orders' });
  }
});

// GET /api/orders/all (Admin View of Village Deliveries)
router.get('/all', verifyAuthToken, requireAdmin, async (_req: AuthenticatedRequest, res: Response) => {
  try {
    let orders: any[] = [];
    if (isConnectedToMongo) {
      orders = await MedicineOrderModel.find().sort({ orderedAt: -1 });
    } else {
      orders = [...LocalDataStore.medicineOrders].sort(
        (a, b) => new Date(b.orderedAt).getTime() - new Date(a.orderedAt).getTime()
      );
    }

    return res.json({ orders });
  } catch (error) {
    return res.status(500).json({ error: 'Failed to retrieve village order list' });
  }
});

// PATCH /api/orders/:orderId/status (Admin or Pharmacy Status Update)
router.patch('/:orderId/status', verifyAuthToken, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { orderId } = req.params;
    const { status } = req.body;

    const allowed = ['Placed', 'Confirmed', 'Out for Village Delivery', 'Delivered', 'Cancelled'];
    if (!allowed.includes(status)) {
      return res.status(400).json({ error: 'Invalid order status' });
    }

    if (isConnectedToMongo) {
      const updated = await MedicineOrderModel.findOneAndUpdate(
        { orderId },
        { $set: { orderStatus: status, ...(status === 'Delivered' ? { deliveredAt: new Date() } : {}) } },
        { new: true }
      );
      if (!updated) return res.status(404).json({ error: 'Order not found' });
      return res.json({ message: 'Order status updated', order: updated });
    } else {
      const idx = LocalDataStore.medicineOrders.findIndex((o) => o.orderId === orderId);
      if (idx === -1) return res.status(404).json({ error: 'Order not found' });
      LocalDataStore.medicineOrders[idx].orderStatus = status;
      if (status === 'Delivered') {
        LocalDataStore.medicineOrders[idx].deliveredAt = new Date();
      }
      return res.json({ message: 'Order status updated', order: LocalDataStore.medicineOrders[idx] });
    }
  } catch (error) {
    return res.status(500).json({ error: 'Failed to update order status' });
  }
});

export default router;
