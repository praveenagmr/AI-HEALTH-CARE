/**
 * Healthcare Directory Routes for Varur
 * Medical Stores with Home Delivery & Nearby Hospitals with Emergency Services
 */
import { Router, Response } from 'express';
import { MedicalStoreModel, HospitalModel } from '../../database/models/index.ts';
import { LocalDataStore, isConnectedToMongo } from '../../database/connection.ts';
import { ESSENTIAL_MEDICINES } from '../../database/seedData.ts';
import { verifyAuthToken, requireAdmin, AuthenticatedRequest } from '../middleware/auth.ts';

const router = Router();

// GET /api/healthcare/medicals
router.get('/medicals', async (_req, res: Response) => {
  try {
    let stores = [];
    if (isConnectedToMongo) {
      stores = await MedicalStoreModel.find();
    } else {
      stores = LocalDataStore.medicalStores;
    }
    return res.json({ medicals: stores });
  } catch (error) {
    return res.status(500).json({ error: 'Failed to retrieve medical stores' });
  }
});

// GET /api/healthcare/hospitals
router.get('/hospitals', async (_req, res: Response) => {
  try {
    let hospitals = [];
    if (isConnectedToMongo) {
      hospitals = await HospitalModel.find().sort({ distanceFromVarurKm: 1 });
    } else {
      hospitals = [...LocalDataStore.hospitals].sort((a, b) => a.distanceFromVarurKm - b.distanceFromVarurKm);
    }
    return res.json({ hospitals });
  } catch (error) {
    return res.status(500).json({ error: 'Failed to retrieve hospitals' });
  }
});

// GET /api/healthcare/medicines-catalog
router.get('/medicines-catalog', async (_req, res: Response) => {
  return res.json({ medicines: ESSENTIAL_MEDICINES });
});

// POST /api/healthcare/medicals (Admin only)
router.post('/medicals', verifyAuthToken, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const data = req.body;
    const storeId = `MED-VRR-${Date.now().toString().slice(-4)}`;
    const storeObj = { ...data, storeId };

    if (isConnectedToMongo) {
      await MedicalStoreModel.create(storeObj);
    } else {
      LocalDataStore.medicalStores.push(storeObj as any);
    }
    return res.status(201).json({ message: 'Medical store added successfully', store: storeObj });
  } catch (error) {
    return res.status(500).json({ error: 'Failed to add medical store' });
  }
});

export default router;
