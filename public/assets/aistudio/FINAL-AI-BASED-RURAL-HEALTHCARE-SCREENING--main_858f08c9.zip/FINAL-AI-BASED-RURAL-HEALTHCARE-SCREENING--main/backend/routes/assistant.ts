/**
 * Multilingual AI Voice & Chat Assistant for Varur Rural Health
 * Full clinical knowledge + Complete User Interface Guide for the entire website
 * High-fidelity TTS generation using gemini-3.8-flash-lite-tts
 */
import { Router, Request, Response } from 'express';
import { ai } from '../geminiClient.ts';

const router = Router();

// Helper to strip markdown formatting for TTS reading
function cleanTextForSpeech(text: string): string {
  return text
    .replace(/[*#_~`>•-]/g, ' ')
    .replace(/\[.*?\]\(.*?\)/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

// POST /api/assistant/chat
router.post('/chat', async (req: Request, res: Response) => {
  try {
    const { question, language = 'kannada', conversationHistory = [] } = req.body;

    if (!question || !question.trim()) {
      return res.status(400).json({ error: 'Please ask a health question or speak into the microphone.' });
    }

    const selectedLang = ['kannada', 'hindi', 'english'].includes(language) ? language : 'kannada';
    const lowerQuery = question.toLowerCase();

    // 1. Domain Boundary Detection:
    // User interface guide terms
    const uiGuideTerms = [
      'guide', 'help', 'app', 'website', 'portal', 'use', 'how to', 'screen', 'wizard',
      'order', 'medicine', 'medicines', 'history', 'report', 'reports', 'record', 'records',
      'language', 'theme', 'dark', 'light', 'day', 'night', 'hospital', 'hospitals', 'doctor',
      'phc', 'kims', 'ambulance', 'login', 'register', 'profile', 'step', 'steps',
      // Kannada UI terms
      'ಮಾರ್ಗದರ್ಶಿ', 'ಸಹಾಯ', 'ಆ್ಯಪ್', 'ವೆಬ್‌ಸೈಟ್', 'ಬಳಸುವುದು', 'ಹೇಗೆ', 'ಸ್ಕ್ರೀನಿಂಗ್', 'ತಪಾಸಣೆ',
      'ಆರ್ಡರ್', 'ಔಷಧ', 'ಔಷಧಿ', 'ಇತಿಹಾಸ', 'ದಾಖಲೆ', 'ದಾಖಲೆಗಳು', 'ವರದಿ', 'ವರದಿಗಳು', 'ಭಾಷೆ', 'ಬದಲಾವಣೆ',
      'ಥೀಮ್', 'ಮೋಡ್', 'ರಾತ್ರಿ', 'ಹಗಲು', 'ಆಸ್ಪತ್ರೆ', 'ಆಸ್ಪತ್ರೆಗಳು', 'ವೈದ್ಯರು', 'ಲಾಗಿನ್', 'ನೋಂದಣಿ', 'ಪ್ರೊಫೈಲ್',
      'ಹಂತ', 'ಹಂತಗಳು', 'ವಿವರ', 'ಹಿಸ್ಟರಿ',
      // Hindi UI terms
      'गाइड', 'मदद', 'ऐप', 'पोर्टल', 'उपयोग', 'कैसे', 'स्क्रीनिंग', 'जांच', 'दवा', 'दवाइयां',
      'ऑर्डर', 'इतिहास', 'रिकॉर्ड', 'रिपोर्ट', 'भाषा', 'बदलें', 'थीम', 'मोड', 'अस्पताल', 'डॉक्टर',
      'लॉगिन', 'पंजीकरण', 'चरण'
    ];

    // Common health terms
    const commonHealthTerms = [
      'health', 'fever', 'cough', 'cold', 'headache', 'pain', 'vomit', 'stomach', 'ache', 'doctor', 'hospital',
      'medicine', 'tablet', 'clinic', 'phc', 'kims', 'ambulance', 'bp', 'sugar', 'diabetes', 'rash', 'allergy',
      'eye', 'ear', 'throat', 'breath', 'chest', 'pregnant', 'baby', 'child', 'infection', 'disease', 'dengue',
      'malaria', 'wound', 'injury', 'bleed', 'symptom', 'diet', 'treatment', 'cure', 'rest', 'hydration', 'ors',
      // Kannada health terms
      'ಆರೋಗ್ಯ', 'ಜ್ವರ', 'ಕೆಮ್ಮು', 'ನೆಗಡಿ', 'ಶೀತ', 'ತಲೆನೋವು', 'ಹೊಟ್ಟೆ', 'ನೋವು', 'ವಾಂತಿ', 'ವೈದ್ಯ', 'ಆಸ್ಪತ್ರೆ', 'ಔಷಧ',
      'ಮಾತ್ರೆ', 'ಕಾಯಿಲೆ', 'ರೋಗ', 'ಉಸಿರಾಟ', 'ಎದೆ', 'ಗಂಟಲು', 'ಚಿಕಿತ್ಸೆ', 'ಗರ್ಭ', 'ಮಗು', 'ಕೇಂದ್ರ', 'ವರೂರು',
      'ರಕ್ತದೊತ್ತಡ', 'ಸಕ್ಕರೆ', 'ಅಲರ್ಜಿ', 'ಗಾಯ', 'ವಿಶ್ರಾಂತಿ', 'ನೀರು',
      // Hindi health terms
      'स्वास्थ्य', 'बुखार', 'खांसी', 'जुकाम', 'सिरदर्द', 'पेट', 'दर्द', 'उल्टी', 'डॉक्टर', 'अस्पताल', 'दवा',
      'गोली', 'बीमारी', 'रोग', 'सांस', 'सीना', 'इलाज', 'गर्भवती', 'बच्चा', 'बीपी', 'शुगर'
    ];

    const nonHealthTriggers = [
      'cricket', 'football', 'ipl', 'match', 'movie', 'cinema', 'actor', 'actress', 'song', 'joke', 'politics',
      'election', 'prime minister', 'president', 'capital of', 'programming', 'python', 'javascript', 'code',
      'weather', 'rain', 'temperature outside', 'bitcoin', 'crypto', 'stock', 'share market', 'game', 'play station',
      'hero', 'dance', 'car', 'bike', 'math', 'calculate',
      // Kannada non-health triggers
      'ಕ್ರಿಕೆಟ್', 'ಸಿನಿಮಾ', 'ಹಾಡು', 'ಚುನಾವಣೆ', 'ರಾಜಕೀಯ', 'ಹವಾಮಾನ', 'ಮಳೆ', 'ಆಟ', 'ಕಾರು', 'ಬೈಕ್', 'ಜೋಕ್', 'ಪಂದ್ಯ',
      // Hindi non-health triggers
      'क्रिकेट', 'फिल्म', 'सिनेमा', 'गाना', 'चुनाव', 'राजनीति', 'मौसम', 'बारिश', 'खेल', 'गाड़ी', 'जोक'
    ];

    const isNonHealthTrigger = nonHealthTriggers.some((nh) => lowerQuery.includes(nh));
    const hasHealthTerm = commonHealthTerms.some((ht) => lowerQuery.includes(ht));
    const isUiGuideQuery = uiGuideTerms.some((ut) => lowerQuery.includes(ut));

    // If completely unrelated to health AND unrelated to using the app, decline with exact phrase requested:
    if (isNonHealthTrigger && !hasHealthTerm && !isUiGuideQuery) {
      const refusalMessages: Record<string, string> = {
        kannada: 'ದಯವಿಟ್ಟು ನಿಮ್ಮ ಆರೋಗ್ಯಕ್ಕೆ ಸಂಬಂಧಿಸಿದ ಸಮಸ್ಯೆಯನ್ನು ತಿಳಿಸಿ.',
        hindi: 'कृपया अपनी स्वास्थ्य संबंधी समस्या बताइए।',
        english: 'Please tell me the health related issue.',
      };

      const declineText = refusalMessages[selectedLang] || refusalMessages.english;

      // Generate TTS for decline text too
      let audioBase64 = '';
      try {
        const ttsRes = await ai.models.generateContent({
          model: 'gemini-3.8-flash-lite-tts',
          contents: [{ role: 'user', parts: [{ text: declineText }] }],
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
            },
          },
        });
        audioBase64 = ttsRes.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || '';
      } catch (e) {
        console.warn('TTS generation skipped on decline:', e);
      }

      return res.json({
        answer: declineText,
        language: selectedLang,
        isHealthRelated: false,
        audio: audioBase64,
      });
    }

    const systemPrompt = `You are "Varur Arogya Mitra" (ವರೂರು ಆರೋಗ್ಯ ಮಿತ್ರ), an expert rural healthcare assistant AND complete User Interface Guide for the Varur Village Healthcare Portal (Hubballi taluk, Dharwad, Karnataka).

YOUR CORE RESPONSIBILITIES:
1. HEALTH & CLINICAL GUIDANCE:
   - Provide comprehensive, warm, accurate answers to every single health query: fever, cough, respiratory issues, diabetes, hypertension, maternal/child care, first aid, home remedies, and OTC medicines.
   - Mention Varur Village local healthcare:
     * Varur Primary Health Centre (PHC) - Dr. Sneha Kulkarni, phone 0836-2310108, 0.8 km distance.
     * KIMS Hospital Hubballi (16.5 km) for tertiary emergency care.
     * 108 Free Emergency Ambulance.
     * Varur Village Pharmacies offering 30-45 min doorstep delivery: Shri Basaveshwara Medicals (9480123451), Jain Medicals (9845233412), Sanjeevani Medicals (9741288902).

2. COMPLETE USER INTERFACE (UI) NAVIGATION GUIDE:
   - Act as an interactive guide to EVERYTHING on this website:
     * Health Screening: Tell user to click "ಆರೋಗ್ಯ ತಪಾಸಣೆ" / "Health Screening" tab -> enter age, gender, symptoms, vitals -> submit to receive instant AI risk evaluation and printable report.
     * Medicine Orders: Tell user to click "ಔಷಧ ಆರ್ಡರ್" / "Order Medicines" tab -> choose remedies -> pick their Varur House ID (VRR-H01 to H15+) -> choose Cash on Delivery or UPI -> order is delivered to doorstep in 30-45 mins.
     * Separate History Page: Tell user to click "ಇತಿಹಾಸ ಮತ್ತು ದಾಖಲೆಗಳು" / "History & Records" tab in the top navigation bar to view all previous screening reports, medicine delivery orders, and voice consultations.
     * Hospitals & Doctors: Tell user to click "ಆಸ್ಪತ್ರೆಗಳು ಮತ್ತು ಮೆಡಿಕಲ್ಸ್" / "Hospitals & Medicals" tab to view 24/7 contacts and directions.
     * Language Changing: Tell user to click the Globe icon on top right to choose ಕನ್ನಡ (Kannada), हिंदी (Hindi), or English.
     * Day & Night Mode: Tell user to click the Sun/Moon icon on the top bar.

3. STRICT LANGUAGE ISOLATION:
   - If language is "kannada", reply strictly in 100% natural, polite, authentic spoken Kannada (ಕನ್ನಡ ಲಿಪಿ). DO NOT mix English words or Hindi words.
   - If language is "hindi", reply strictly in 100% clear, respectful Hindi (हिंदी ಲಿಪಿ).
   - If language is "english", reply strictly in clear, caring English.

4. NON-HEALTH & NON-APP QUERIES:
   - If the user asks questions completely outside health and outside using this app:
     * In Kannada: "ದಯವಿಟ್ಟು ನಿಮ್ಮ ಆರೋಗ್ಯಕ್ಕೆ ಸಂಬಂಧಿಸಿದ ಸಮಸ್ಯೆಯನ್ನು ತಿಳಿಸಿ."
     * In Hindi: "कृपया अपनी स्वास्थ्य संबंधी समस्या बताइए।"
     * In English: "Please tell me the health related issue."`;

    const contents = [
      ...conversationHistory.slice(-6).map((msg: any) => ({
        role: msg.sender === 'user' ? 'user' : 'model',
        parts: [{ text: msg.text }],
      })),
      {
        role: 'user',
        parts: [{ text: question.trim() }],
      },
    ];

    let replyText = '';

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: contents as any,
        config: {
          systemInstruction: systemPrompt,
          temperature: 0.65,
        },
      });

      replyText = response.text || '';
    } catch (err) {
      console.warn('Gemini Assistant call error, using local fallback:', err);
    }

    if (!replyText) {
      // Local fallback for uninterrupted village experience
      if (selectedLang === 'kannada') {
        replyText = `ನಮಸ್ಕಾರ, ನಿಮ್ಮ ಪ್ರಶ್ನೆಗೆ ವರೂರು ಆರೋಗ್ಯ ಮಿತ್ರದ ಮಾರ್ಗದರ್ಶನ:
- ಆರೋಗ್ಯ ತಪಾಸಣೆಗಾಗಿ ಮೇಲಿನ 'ಆರೋಗ್ಯ ತಪಾಸಣೆ' ಟ್ಯಾಬ್ ಒತ್ತಿ ನಿಮ್ಮ ಲಕ್ಷಣಗಳನ್ನು ದಾಖಲಿಸಿ.
- ಮನೆ ಬಾಗಿಲಿಗೆ ಔಷಧ ತರಿಸಲು 'ಔಷಧ ಆರ್ಡರ್' ಟ್ಯಾಬ್ ಬಳಸಿ ನಿಮ್ಮ ವರೂರು ಮನೆ ಸಂಖ್ಯೆ ಆಯ್ಕೆಮಾಡಿ.
- ಹಿಂದಿನ ಎಲ್ಲಾ ತಪಾಸಣಾ ವರದಿಗಳು ಮತ್ತು ಆರ್ಡರ್‌ಗಳನ್ನು ನೋಡಲು ಮೇಲಿನ 'ಇತಿಹಾಸ' ಪುಟವನ್ನು ಕ್ಲಿಕ್ ಮಾಡಿ.
- ಜ್ವರ ಅಥವಾ ಶೀತವಿದ್ದಲ್ಲಿ ಬಿಸಿ ನೀರು ಕುಡಿಯಿರಿ ಮತ್ತು ಅಗತ್ಯವಿದ್ದಲ್ಲಿ ವರೂರು ಪ್ರಾಥಮಿಕ ಆರೋಗ್ಯ ಕೇಂದ್ರ (PHC) ಅಥವಾ ೧೦೮ ಆಂಬ್ಯುಲೆನ್ಸ್‌ಗೆ ಕರೆ ಮಾಡಿ.`;
      } else if (selectedLang === 'hindi') {
        replyText = `नमस्ते, वरूर स्वास्थ्य मित्र की सलाह:
- स्वास्थ्य जांच के लिए ऊपर 'स्वास्थ्य जांच' टैब पर क्लिक करके लक्षण दर्ज करें।
- घर तक दवा मंगाने के लिए 'दवा ऑर्डर' टैब पर जाएं और वरूर घर संख्या चुनें।
- पिछले सभी रिकॉर्ड और रिपोर्ट देखने के लिए 'इतिहास' पेज पर क्लिक करें।
- आपातकालीन स्थिति में वरूर पीएचसी या 108 एम्बुलेंस पर तुरंत संपर्क करें।`;
      } else {
        replyText = `Hello, here is guidance from Varur Health Mitra:
- To perform a health checkup, click the 'Health Screening' tab above.
- To order medicines to your doorstep, click 'Order Medicines' and select your Varur House ID.
- To view all past screening reports and delivery records, click the dedicated 'History & Records' page.
- For emergency care, contact Varur PHC (0836-2310108) or call 108 Ambulance.`;
      }
    }

    // High-fidelity speech synthesis using gemini-3.8-flash-lite-tts
    let audioBase64 = '';
    try {
      const cleanSnippet = cleanTextForSpeech(replyText).slice(0, 220);
      if (cleanSnippet) {
        const ttsRes = await ai.models.generateContent({
          model: 'gemini-3.8-flash-lite-tts',
          contents: [{ role: 'user', parts: [{ text: cleanSnippet }] }],
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: 'Kore' },
              },
            },
          },
        });
        audioBase64 = ttsRes.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || '';
      }
    } catch (ttsErr) {
      console.warn('Gemini TTS warning, client will use Web Speech fallback:', ttsErr);
    }

    return res.json({
      answer: replyText,
      language: selectedLang,
      audio: audioBase64,
    });
  } catch (error) {
    console.error('Assistant error:', error);
    return res.status(500).json({ error: 'Failed to process assistant question. Please try again.' });
  }
});

// GET /api/assistant/tts
// Dedicated streaming endpoint that returns high-fidelity WAV audio
router.get('/tts', async (req: Request, res: Response) => {
  try {
    const text = String(req.query.text || '').trim();
    if (!text) {
      return res.status(400).send('Text parameter is required.');
    }

    const shortText = cleanTextForSpeech(text).slice(0, 220);

    const ttsRes = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [{ role: 'user', parts: [{ text: shortText }] }],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });

    const audioBase64 = ttsRes.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (audioBase64) {
      const buffer = Buffer.from(audioBase64, 'base64');
      res.set({
        'Content-Type': 'audio/wav',
        'Content-Length': buffer.length,
        'Cache-Control': 'public, max-age=86400',
      });
      return res.send(buffer);
    }

    return res.status(500).send('Could not generate audio');
  } catch (err) {
    console.error('TTS endpoint error:', err);
    return res.status(500).send('Error generating TTS');
  }
});

export default router;

