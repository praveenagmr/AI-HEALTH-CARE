/**
 * Houses Management Routes for Varur Village
 * Restricts overall 15-house data visibility and editing to Admin only.
 * Allows village residents to add/register new houses.
 */
import { Router, Response } from 'express';
import { HouseModel, IHouse } from '../../database/models/index.ts';
import { LocalDataStore, isConnectedToMongo } from '../../database/connection.ts';
import { verifyAuthToken, requireAdmin, optionalAuth, AuthenticatedRequest } from '../middleware/auth.ts';

const router = Router();

// GET /api/houses
// Admin gets full house dataset; regular users / guests only get public selector list
router.get('/', optionalAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const isAdmin = req.user?.role === 'admin';

    let allHouses: any[] = [];
    if (isConnectedToMongo) {
      allHouses = await HouseModel.find().sort({ houseId: 1 });
    } else {
      allHouses = [...LocalDataStore.houses].sort((a, b) => a.houseId.localeCompare(b.houseId));
    }

    if (isAdmin) {
      // Admin sees complete data of all 15+ houses
      return res.json({
        totalHouses: allHouses.length,
        houses: allHouses,
      });
    }

    // Regular users: Only public identifiers for house registration/selection
    const publicHouseList = allHouses.map((h) => ({
      houseId: h.houseId,
      landmark: h.landmark,
      addressLine: h.addressLine,
    }));

    return res.json({
      totalHouses: publicHouseList.length,
      houses: publicHouseList,
    });
  } catch (error) {
    return res.status(500).json({ error: 'Failed to retrieve house data' });
  }
});

// POST /api/houses/register
// Village users or admin can register a new house in Varur
router.post('/register', optionalAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { headOfFamily, familyMembersCount, contactNumber, addressLine, landmark, rationCardNo, notes } = req.body;

    if (!headOfFamily || !headOfFamily.trim()) {
      return res.status(400).json({ error: 'Head of family name is required.' });
    }

    const members = Number(familyMembersCount);
    if (isNaN(members) || members < 1) {
      return res.status(400).json({ error: 'Please enter a valid count of family members.' });
    }

    const cleanPhone = String(contactNumber || '').replace(/\D/g, '');
    if (!cleanPhone || cleanPhone.length < 10) {
      return res.status(400).json({ error: 'Please enter a valid 10-digit contact number.' });
    }

    if (!addressLine || !addressLine.trim()) {
      return res.status(400).json({ error: 'Address line in Varur village is required.' });
    }

    // Calculate next House ID
    let currentHouses: any[] = [];
    if (isConnectedToMongo) {
      currentHouses = await HouseModel.find();
    } else {
      currentHouses = LocalDataStore.houses;
    }

    const nextNumber = currentHouses.length + 1;
    const houseId = `VRR-H${nextNumber < 10 ? '0' + nextNumber : nextNumber}`;

    // Base coordinates for Varur village center
    const latOffset = (Math.random() - 0.5) * 0.006;
    const lngOffset = (Math.random() - 0.5) * 0.006;

    const newHouseObj = {
      houseId,
      headOfFamily: headOfFamily.trim(),
      familyMembersCount: members,
      contactNumber: cleanPhone,
      addressLine: addressLine.trim(),
      landmark: landmark?.trim() || 'Varur Village Main Area',
      latitude: 15.2285 + latOffset,
      longitude: 75.1872 + lngOffset,
      rationCardNo: rationCardNo?.trim() || `BPL-VRR-${1000 + nextNumber}`,
      registeredDate: new Date(),
      notes: notes?.trim() || 'Newly registered Varur household.',
    };

    let saved: any = null;
    if (isConnectedToMongo) {
      saved = await HouseModel.create(newHouseObj);
    } else {
      saved = newHouseObj as unknown as IHouse;
      LocalDataStore.houses.push(saved);
    }

    return res.status(201).json({
      message: `House ${houseId} registered successfully in Varur village registry!`,
      house: saved,
    });
  } catch (error) {
    console.error('Error adding house:', error);
    return res.status(500).json({ error: 'Failed to register house. Please try again.' });
  }
});

// PUT /api/houses/:houseId (Admin Only)
router.put('/:houseId', verifyAuthToken, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { houseId } = req.params;
    const { headOfFamily, familyMembersCount, contactNumber, addressLine, landmark, rationCardNo, notes } = req.body;

    if (isConnectedToMongo) {
      const updated = await HouseModel.findOneAndUpdate(
        { houseId },
        {
          $set: {
            headOfFamily,
            familyMembersCount: Number(familyMembersCount),
            contactNumber,
            addressLine,
            landmark,
            rationCardNo,
            notes,
          },
        },
        { new: true }
      );
      if (!updated) return res.status(404).json({ error: 'House not found' });
      return res.json({ message: 'House updated successfully', house: updated });
    } else {
      const idx = LocalDataStore.houses.findIndex((h) => h.houseId === houseId);
      if (idx === -1) return res.status(404).json({ error: 'House not found' });

      LocalDataStore.houses[idx] = {
        ...LocalDataStore.houses[idx],
        headOfFamily: headOfFamily || LocalDataStore.houses[idx].headOfFamily,
        familyMembersCount: Number(familyMembersCount) || LocalDataStore.houses[idx].familyMembersCount,
        contactNumber: contactNumber || LocalDataStore.houses[idx].contactNumber,
        addressLine: addressLine || LocalDataStore.houses[idx].addressLine,
        landmark: landmark || LocalDataStore.houses[idx].landmark,
        rationCardNo: rationCardNo || LocalDataStore.houses[idx].rationCardNo,
        notes: notes || LocalDataStore.houses[idx].notes,
      };

      return res.json({ message: 'House updated successfully', house: LocalDataStore.houses[idx] });
    }
  } catch (error) {
    return res.status(500).json({ error: 'Failed to update house record' });
  }
});

export default router;
