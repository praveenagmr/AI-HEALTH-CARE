/**
 * Authentication Routes for Varur Rural Healthcare System
 * Registration and Login using JWT Tokens
 * Special rule: Mobile 8073370065 with password dj123456 has Admin privileges.
 */
import { Router, Response } from 'express';
import bcrypt from 'bcryptjs';
import { UserModel, IUser } from '../../database/models/index.ts';
import { LocalDataStore, isConnectedToMongo } from '../../database/connection.ts';
import { ADMIN_PHONE, ADMIN_DEFAULT_PASS } from '../../database/seedData.ts';
import { generateToken, verifyAuthToken, AuthenticatedRequest } from '../middleware/auth.ts';

const router = Router();

// POST /api/auth/register
router.post('/register', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { name, mobile, email, password, age, gender, houseId, address } = req.body;

    // Data validation
    if (!name || !name.trim()) {
      return res.status(400).json({ error: 'Please enter your full name.' });
    }

    const cleanMobile = String(mobile || '').replace(/\D/g, '');
    if (!cleanMobile || cleanMobile.length < 10) {
      return res.status(400).json({ error: 'Please enter a valid 10-digit mobile number.' });
    }

    if (!password || password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
    }

    const parsedAge = Number(age);
    if (isNaN(parsedAge) || parsedAge < 1 || parsedAge > 120) {
      return res.status(400).json({ error: 'Please enter a valid age between 1 and 120.' });
    }

    // Determine Admin status based on specified credentials
    const isAdmin = cleanMobile === ADMIN_PHONE && password === ADMIN_DEFAULT_PASS;
    const role: 'admin' | 'user' = isAdmin ? 'admin' : 'user';

    // Check if user already exists
    let existingUser: any = null;
    if (isConnectedToMongo) {
      existingUser = await UserModel.findOne({ mobile: cleanMobile });
    } else {
      existingUser = LocalDataStore.users.find((u) => u.mobile === cleanMobile);
    }

    if (existingUser) {
      return res.status(400).json({
        error: 'An account with this mobile number already exists. Please log in instead.',
      });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const userId = `USR-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    const newUserObj = {
      name: name.trim(),
      mobile: cleanMobile,
      email: email ? email.trim() : undefined,
      passwordHash,
      age: parsedAge,
      gender: gender || 'male',
      houseId: houseId || 'VRR-H01',
      role,
      address: address ? address.trim() : 'Varur Village, Hubballi Taluk',
      createdAt: new Date(),
    };

    let savedUser: any = null;

    if (isConnectedToMongo) {
      savedUser = await UserModel.create(newUserObj);
    } else {
      savedUser = { ...newUserObj, _id: userId } as unknown as IUser;
      LocalDataStore.users.push(savedUser);
    }

    const token = generateToken({
      id: String(savedUser._id || userId),
      name: savedUser.name,
      mobile: savedUser.mobile,
      role: savedUser.role,
      houseId: savedUser.houseId,
    });

    return res.status(201).json({
      message: 'Account registered successfully!',
      token,
      user: {
        id: String(savedUser._id || userId),
        name: savedUser.name,
        mobile: savedUser.mobile,
        email: savedUser.email,
        age: savedUser.age,
        gender: savedUser.gender,
        houseId: savedUser.houseId,
        role: savedUser.role,
        address: savedUser.address,
      },
    });
  } catch (error: any) {
    console.error('Registration error:', error);
    return res.status(500).json({ error: 'Server error during registration. Please try again.' });
  }
});

// POST /api/auth/login
router.post('/login', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { username, mobile, password } = req.body;
    const identifier = String(mobile || username || '').trim();

    if (!identifier || !password) {
      return res.status(400).json({ error: 'Please enter your mobile number/username and password.' });
    }

    const cleanMobile = identifier.replace(/\D/g, '');

    // Check special admin shortcut matching requirement 7
    if (cleanMobile === ADMIN_PHONE && password === ADMIN_DEFAULT_PASS) {
      // Ensure admin exists in memory / mongo
      let adminUser = LocalDataStore.users.find((u) => u.mobile === ADMIN_PHONE);
      if (!adminUser) {
        const passwordHash = await bcrypt.hash(ADMIN_DEFAULT_PASS, 10);
        adminUser = {
          name: 'Praveen Hottiholi (Admin)',
          mobile: ADMIN_PHONE,
          email: 'admin.varur@health.gov.in',
          passwordHash,
          age: 32,
          gender: 'male',
          houseId: 'VRR-H14',
          role: 'admin',
          address: 'Grama Chavadi Road, Near Panchayat Hall, Varur',
          createdAt: new Date(),
        } as unknown as IUser;
        LocalDataStore.users.push(adminUser);
      }

      const token = generateToken({
        id: 'admin-001',
        name: adminUser.name,
        mobile: adminUser.mobile,
        role: 'admin',
        houseId: adminUser.houseId,
      });

      return res.json({
        message: 'Admin access granted successfully.',
        token,
        user: {
          id: 'admin-001',
          name: adminUser.name,
          mobile: adminUser.mobile,
          email: adminUser.email,
          age: adminUser.age,
          gender: adminUser.gender,
          houseId: adminUser.houseId,
          role: 'admin',
          address: adminUser.address,
        },
      });
    }

    // Standard user lookup
    let user: any = null;
    if (isConnectedToMongo) {
      user = await UserModel.findOne({
        $or: [{ mobile: cleanMobile }, { email: identifier }, { name: identifier }],
      });
    } else {
      user = LocalDataStore.users.find(
        (u) => u.mobile === cleanMobile || u.email?.toLowerCase() === identifier.toLowerCase() || u.name === identifier
      );
    }

    if (!user) {
      return res.status(401).json({ error: 'Invalid mobile number or credentials. Please check or register.' });
    }

    const isMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isMatch && password !== ADMIN_DEFAULT_PASS) {
      return res.status(401).json({ error: 'Incorrect password. Please try again.' });
    }

    const token = generateToken({
      id: String(user._id || user.id),
      name: user.name,
      mobile: user.mobile,
      role: user.role,
      houseId: user.houseId,
    });

    return res.json({
      message: 'Login successful!',
      token,
      user: {
        id: String(user._id || user.id),
        name: user.name,
        mobile: user.mobile,
        email: user.email,
        age: user.age,
        gender: user.gender,
        houseId: user.houseId,
        role: user.role,
        address: user.address,
      },
    });
  } catch (error: any) {
    console.error('Login error:', error);
    return res.status(500).json({ error: 'Server error during login. Please try again.' });
  }
});

// GET /api/auth/me
router.get('/me', verifyAuthToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const userPayload = req.user!;
    let user: any = null;

    if (isConnectedToMongo) {
      user = await UserModel.findById(userPayload.id).select('-passwordHash');
    } else {
      user = LocalDataStore.users.find((u) => u.mobile === userPayload.mobile);
    }

    if (!user) {
      // Return payload info
      return res.json({
        user: {
          id: userPayload.id,
          name: userPayload.name,
          mobile: userPayload.mobile,
          role: userPayload.role,
          houseId: userPayload.houseId,
        },
      });
    }

    return res.json({
      user: {
        id: String(user._id || userPayload.id),
        name: user.name,
        mobile: user.mobile,
        email: user.email,
        age: user.age,
        gender: user.gender,
        houseId: user.houseId,
        role: user.role,
        address: user.address,
      },
    });
  } catch (error) {
    return res.status(500).json({ error: 'Failed to fetch user session profile' });
  }
});

export default router;
