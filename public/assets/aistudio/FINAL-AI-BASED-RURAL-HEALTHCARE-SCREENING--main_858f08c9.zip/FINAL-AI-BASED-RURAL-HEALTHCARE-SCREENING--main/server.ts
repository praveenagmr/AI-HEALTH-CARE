/**
 * Full-stack Express Server with Vite Dev Middlewares
 * Port: 3000
 * Direct MongoDB Compass connection: mongodb://localhost:27017/rural_health_varur
 */
import 'dotenv/config';
import express, { Request, Response } from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { connectToMongoDB } from './database/connection.ts';
import authRoutes from './backend/routes/auth.ts';
import screeningRoutes from './backend/routes/screening.ts';
import assistantRoutes from './backend/routes/assistant.ts';
import housesRoutes from './backend/routes/houses.ts';
import healthcareRoutes from './backend/routes/healthcare.ts';
import ordersRoutes from './backend/routes/orders.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  // Middlewares
  app.use(cors());
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  // Initialize Database (connects to local/compass MongoDB or seamless memory engine)
  await connectToMongoDB();

  // API Routes
  app.use('/api/auth', authRoutes);
  app.use('/api/screening', screeningRoutes);
  app.use('/api/assistant', assistantRoutes);
  app.use('/api/houses', housesRoutes);
  app.use('/api/healthcare', healthcareRoutes);
  app.use('/api/orders', ordersRoutes);

  // Health check endpoint
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      status: 'healthy',
      village: 'Varur',
      taluk: 'Hubballi',
      district: 'Dharwad',
      pincode: '581207',
      timestamp: new Date().toISOString(),
      mongoUriInstruction: 'mongodb://localhost:27017/rural_health_varur',
    });
  });

  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    // Vite Dev Server middleware
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🏥 Varur Rural Healthcare System running at: http://localhost:${PORT}`);
    console.log(`📡 MongoDB Compass URI: mongodb://localhost:27017/rural_health_varur`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
});
