/**
 * Navigation Bar Component
 * 100% Language Isolation: Strictly displays only Kannada when Kannada is selected,
 * only Hindi when Hindi is selected, and only English when English is selected.
 * Includes Language Switcher, Day/Night Toggle, Voice Assistant Trigger, and Auth Controls.
 */
import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { useTheme } from '../context/ThemeContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import {
  HeartPulse,
  Sun,
  Moon,
  Globe,
  Mic,
  ShieldCheck,
  User,
  LogOut,
  LogIn,
  UserPlus,
  Home,
  Building2,
  ShoppingBag,
  Activity,
  Menu,
  X,
  Clock,
} from 'lucide-react';
import { Language } from '../i18n/translations.ts';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  openVoiceAssistant: () => void;
  openLoginModal: () => void;
  openRegisterModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  openVoiceAssistant,
  openLoginModal,
  openRegisterModal,
}) => {
  const { language, setLanguage, t } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const { user, isAdmin, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);

  const navItems = [
    { id: 'home', label: t.home, icon: Home },
    { id: 'screening', label: t.screening, icon: Activity },
    { id: 'hospitals', label: t.hospitals, icon: Building2 },
    { id: 'orders', label: t.medicineOrder, icon: ShoppingBag },
    { id: 'history', label: t.history, icon: Clock },
    ...(isAdmin ? [{ id: 'admin', label: t.adminPanel, icon: ShieldCheck }] : []),
  ];

  const handleLangChange = (lang: Language) => {
    setLanguage(lang);
    setLangDropdownOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors duration-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Village Identity */}
          <div
            onClick={() => setCurrentTab('home')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 via-teal-600 to-cyan-600 flex items-center justify-center text-white shadow-md shadow-emerald-500/20 group-hover:scale-105 transition-transform">
              <HeartPulse className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg text-slate-900 dark:text-white tracking-tight">
                  {t.appName}
                </span>
                <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                  {t.villageBadge}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 hidden sm:block">
                {t.talukInfo}
              </p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setCurrentTab(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 shadow-xs font-semibold'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Right Action Tools: Voice Assistant, Language Switcher, Dark/Light Mode, Auth */}
          <div className="hidden sm:flex items-center gap-2 lg:gap-3">
            {/* Voice Assistant Trigger */}
            <button
              onClick={openVoiceAssistant}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-linear-to-r from-teal-500 to-emerald-600 text-white text-xs font-semibold hover:from-teal-600 hover:to-emerald-700 shadow-sm shadow-emerald-500/25 hover:shadow-md transition-all"
              title={t.voiceAssistant}
            >
              <Mic className="w-3.5 h-3.5" />
              <span>{t.voiceAssistant}</span>
            </button>

            {/* Language Switcher - 100% Isolated */}
            <div className="relative">
              <button
                onClick={() => setLangDropdownOpen(!langDropdownOpen)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-xs font-medium hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                title={t.langLabel}
              >
                <Globe className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span className="font-semibold">{t.currentLanguageName}</span>
              </button>

              {langDropdownOpen && (
                <div className="absolute right-0 mt-2 w-32 bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 py-1 z-50 animate-in fade-in zoom-in-95">
                  <button
                    onClick={() => handleLangChange('kannada')}
                    className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between ${
                      language === 'kannada'
                        ? 'font-bold text-emerald-600 bg-emerald-50 dark:bg-slate-700'
                        : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700'
                    }`}
                  >
                    <span>{t.kannadaChoice}</span>
                    {language === 'kannada' && <span className="text-emerald-600">✓</span>}
                  </button>
                  <button
                    onClick={() => handleLangChange('hindi')}
                    className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between ${
                      language === 'hindi'
                        ? 'font-bold text-emerald-600 bg-emerald-50 dark:bg-slate-700'
                        : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700'
                    }`}
                  >
                    <span>{t.hindiChoice}</span>
                    {language === 'hindi' && <span className="text-emerald-600">✓</span>}
                  </button>
                  <button
                    onClick={() => handleLangChange('english')}
                    className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between ${
                      language === 'english'
                        ? 'font-bold text-emerald-600 bg-emerald-50 dark:bg-slate-700'
                        : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700'
                    }`}
                  >
                    <span>{t.englishChoice}</span>
                    {language === 'english' && <span className="text-emerald-600">✓</span>}
                  </button>
                </div>
              )}
            </div>

            {/* Day / Night Mode Toggle */}
            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors border border-slate-200 dark:border-slate-700"
              title={t.dayNightModeTitle}
              aria-label="Toggle theme"
            >
              {theme === 'dark' ? (
                <Sun className="w-4 h-4 text-amber-400" />
              ) : (
                <Moon className="w-4 h-4 text-slate-700" />
              )}
            </button>

            {/* Authentication Buttons (Login/Register or User Badge) */}
            {user ? (
              <div className="flex items-center gap-2 pl-1 border-l border-slate-200 dark:border-slate-700">
                <div
                  onClick={() => setCurrentTab('profile')}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                >
                  <User className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="font-semibold truncate max-w-[110px]">{user.name.split(' ')[0]}</span>
                </div>
                <button
                  onClick={logout}
                  className="p-1.5 text-slate-500 hover:text-red-600 dark:text-slate-400 dark:hover:text-red-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                  title={t.logout}
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={openLoginModal}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>{t.login}</span>
                </button>
                <button
                  onClick={openRegisterModal}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-xs transition-colors"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>{t.register}</span>
                </button>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={openVoiceAssistant}
              className="p-1.5 rounded-full bg-emerald-600 text-white"
              title={t.voiceAssistant}
            >
              <Mic className="w-4 h-4" />
            </button>
            <button
              onClick={toggleTheme}
              className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 pt-3 pb-5 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
            <span className="text-xs font-medium text-slate-500">{t.langLabel}:</span>
            <div className="flex gap-1">
              <button
                onClick={() => handleLangChange('kannada')}
                className={`px-2 py-1 text-xs rounded ${language === 'kannada' ? 'bg-emerald-600 text-white font-bold' : 'bg-slate-100 dark:bg-slate-800'}`}
              >
                {t.kannadaChoice}
              </button>
              <button
                onClick={() => handleLangChange('hindi')}
                className={`px-2 py-1 text-xs rounded ${language === 'hindi' ? 'bg-emerald-600 text-white font-bold' : 'bg-slate-100 dark:bg-slate-800'}`}
              >
                {t.hindiChoice}
              </button>
              <button
                onClick={() => handleLangChange('english')}
                className={`px-2 py-1 text-xs rounded ${language === 'english' ? 'bg-emerald-600 text-white font-bold' : 'bg-slate-100 dark:bg-slate-800'}`}
              >
                {t.englishChoice}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setCurrentTab(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium ${
                    currentTab === item.id
                      ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 font-bold'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
            {user ? (
              <div className="flex items-center justify-between">
                <div className="text-xs">
                  <p className="font-semibold text-slate-900 dark:text-white">{user.name}</p>
                  <p className="text-slate-500">{t.houseLabel}: {user.houseId}</p>
                </div>
                <button
                  onClick={() => {
                    logout();
                    setMobileMenuOpen(false);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-red-50 text-red-600 text-xs font-semibold hover:bg-red-100 dark:bg-red-950/50"
                >
                  {t.logout}
                </button>
              </div>
            ) : (
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    openLoginModal();
                    setMobileMenuOpen(false);
                  }}
                  className="flex-1 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold text-center"
                >
                  {t.login}
                </button>
                <button
                  onClick={() => {
                    openRegisterModal();
                    setMobileMenuOpen(false);
                  }}
                  className="flex-1 py-2 rounded-lg bg-emerald-600 text-white text-xs font-semibold text-center"
                >
                  {t.register}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
