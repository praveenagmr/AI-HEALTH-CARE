/**
 * Standard 11-Step AI Health Screening Wizard
 * 100% Strict Language Isolation for Kannada, Hindi, and English.
 * Strictly adheres to Steps 5 to 11 with clear data validation,
 * explainable AI analysis, and referral recommendations.
 */
import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  Stethoscope,
  Printer,
  ShoppingBag,
  ArrowRight,
  ShieldAlert,
  Info,
  MapPin,
  Heart,
  Thermometer,
  RotateCcw,
} from 'lucide-react';

interface ScreeningWizardProps {
  onOrderMedicinesForScreening?: (medicines: string[], houseId: string) => void;
  onNavigateToHospitals?: () => void;
}

export const HealthScreeningWizard: React.FC<ScreeningWizardProps> = ({
  onOrderMedicinesForScreening,
  onNavigateToHospitals,
}) => {
  const { language, t } = useLanguage();
  const { user, token } = useAuth();

  // Wizard state: 'form' (Step 5 & 6) -> 'processing' (Step 7) -> 'result' (Step 8, 9, 10, 11)
  const [currentStep, setCurrentStep] = useState<'form' | 'processing' | 'result'>('form');

  // Form Inputs
  const [patientName, setPatientName] = useState(user?.name || '');
  const [patientMobile, setPatientMobile] = useState(user?.mobile || '');
  const [houseId, setHouseId] = useState(user?.houseId || 'VRR-H01');
  const [age, setAge] = useState<string>(user?.age ? String(user.age) : '28');
  const [gender, setGender] = useState<'male' | 'female' | 'other'>(
    (user?.gender as any) || 'male'
  );

  // Symptoms Selection
  const commonSymptoms = [
    { id: 'Fever', label: t.fever },
    { id: 'Cough', label: t.cough },
    { id: 'Headache', label: t.headache },
    { id: 'Fatigue', label: t.fatigue },
    { id: 'Difficulty breathing', label: t.difficultyBreathing, redFlag: true },
    { id: 'Vomiting', label: t.vomiting },
    { id: 'Body pain', label: t.bodyPain },
    { id: 'Chest pain', label: t.chestPain, redFlag: true },
    { id: 'Diarrhea', label: t.diarrhea },
    { id: 'Throat pain', label: t.throatPain },
    { id: 'Loss of smell or taste', label: t.lossOfSmellTaste },
  ];

  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>(['Fever', 'Cough']);
  const [customSymptomInput, setCustomSymptomInput] = useState('');
  const [durationDays, setDurationDays] = useState<number>(2);

  // Vitals
  const [tempF, setTempF] = useState<string>('99.4');
  const [bp, setBp] = useState<string>('120/80');
  const [pulse, setPulse] = useState<string>('78');
  const [spo2, setSpo2] = useState<string>('98');

  // Pre-existing conditions
  const [preExisting, setPreExisting] = useState<string[]>([]);
  const [notes, setNotes] = useState<string>('');

  // Step 6: Validation Message
  const [validationError, setValidationError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Screening Output
  const [screeningResult, setScreeningResult] = useState<any>(null);

  const toggleSymptom = (symId: string) => {
    setSelectedSymptoms((prev) =>
      prev.includes(symId) ? prev.filter((s) => s !== symId) : [...prev, symId]
    );
    setValidationError(null);
  };

  const addCustomSymptom = () => {
    if (customSymptomInput.trim() && !selectedSymptoms.includes(customSymptomInput.trim())) {
      setSelectedSymptoms((prev) => [...prev, customSymptomInput.trim()]);
      setCustomSymptomInput('');
    }
  };

  const togglePreExisting = (cond: string) => {
    setPreExisting((prev) =>
      prev.includes(cond) ? prev.filter((c) => c !== cond) : [...prev, cond]
    );
  };

  // STEP 6: Data Validation & Submission
  const handleProceedToScreening = async () => {
    setValidationError(null);

    const parsedAge = Number(age);
    if (!age || isNaN(parsedAge) || parsedAge < 1 || parsedAge > 120) {
      setValidationError(
        language === 'kannada'
          ? 'ದಯವಿಟ್ಟು ಸರಿಯಾದ ಆರೋಗ್ಯ ಮಾಹಿತಿಯನ್ನು ನಮೂದಿಸಿ: ವಯಸ್ಸು ೧ ರಿಂದ ೧೨೦ ರ ನಡುವೆ ಇರಬೇಕು.'
          : language === 'hindi'
          ? 'कृपया सही स्वास्थ्य जानकारी दर्ज करें: आयु 1 से 120 के बीच होनी चाहिए।'
          : 'Please enter the valid health information: Age must be a number between 1 and 120.'
      );
      return;
    }

    if (!gender) {
      setValidationError(
        language === 'kannada'
          ? 'ದಯವಿಟ್ಟು ಸರಿಯಾದ ಆರೋಗ್ಯ ಮಾಹಿತಿಯನ್ನು ನಮೂದಿಸಿ: ಲಿಂಗವನ್ನು ಆಯ್ಕೆಮಾಡಿ.'
          : language === 'hindi'
          ? 'कृपया सही स्वास्थ्य जानकारी दर्ज करें: लिंग का चयन करें।'
          : 'Please enter the valid health information: Please select patient gender.'
      );
      return;
    }

    if (selectedSymptoms.length === 0) {
      setValidationError(
        language === 'kannada'
          ? 'ದಯವಿಟ್ಟು ಸರಿಯಾದ ಆರೋಗ್ಯ ಮಾಹಿತಿಯನ್ನು ನಮೂದಿಸಿ: ಕನಿಷ್ಠ ಒಂದು ರೋಗಲಕ್ಷಣವನ್ನು ಆಯ್ಕೆಮಾಡಿ.'
          : language === 'hindi'
          ? 'कृपया सही स्वास्थ्य जानकारी दर्ज करें: कम से कम एक लक्षण चुनें।'
          : 'Please enter the valid health information: Please select at least one symptom.'
      );
      return;
    }

    if (durationDays < 1 || durationDays > 180) {
      setValidationError(
        language === 'kannada'
          ? 'ದಯವಿಟ್ಟು ಸರಿಯಾದ ಆರೋಗ್ಯ ಮಾಹಿತಿಯನ್ನು ನಮೂದಿಸಿ: ಲಕ್ಷಣಗಳ ದಿನಗಳ ಸಂಖ್ಯೆ ೧ ರಿಂದ ೧೮೦ ರೊಳಗೆ ಇರಬೇಕು.'
          : language === 'hindi'
          ? 'कृपया सही स्वास्थ्य जानकारी दर्ज करें: दिनों की संख्या 1 से 180 के बीच होनी चाहिए।'
          : 'Please enter the valid health information: Symptom duration must be between 1 and 180 days.'
      );
      return;
    }

    // Step 7: Transition to processing state
    setCurrentStep('processing');
    setIsSubmitting(true);

    try {
      const payload = {
        patientName: patientName || user?.name || (language === 'kannada' ? 'ವರೂರು ನಿವಾಸಿ' : 'Varur Resident'),
        patientMobile: patientMobile || user?.mobile || '9480000000',
        houseId: houseId || user?.houseId || 'VRR-H01',
        age: parsedAge,
        gender,
        symptoms: selectedSymptoms,
        durationDays,
        vitals: {
          temperatureF: tempF ? Number(tempF) : undefined,
          bloodPressure: bp || undefined,
          pulseRate: pulse ? Number(pulse) : undefined,
          oxygenSaturationSpO2: spo2 ? Number(spo2) : undefined,
        },
        preExistingConditions: preExisting,
        lifestyleNotes: notes,
        language,
      };

      const res = await fetch('/api/screening/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok) {
        setValidationError(data.error || t.validationPrompt);
        setCurrentStep('form');
        setIsSubmitting(false);
        return;
      }

      setScreeningResult(data.screening);
      setCurrentStep('result');
    } catch (err) {
      setValidationError(t.validationPrompt);
      setCurrentStep('form');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const resetForm = () => {
    setCurrentStep('form');
    setScreeningResult(null);
    setSelectedSymptoms(['Fever', 'Cough']);
    setValidationError(null);
  };

  // Purely translated step titles for the tracker bar
  const stepTrackerLabels = {
    kannada: {
      step1: 'ಹಂತ ೫: ಆರೋಗ್ಯ ಮಾಹಿತಿ',
      step2: 'ಹಂತ ೭: AI ಸಂಸ್ಕರಣೆ',
      step3: 'ಹಂತ ೮-೧೧: ವರದಿ',
      sec1: '೧. ರೋಗಿಯ ಮೂಲ ವಿವರ ಮತ್ತು ಮನೆ ಸಂಖ್ಯೆ',
      sec2: '೨. ರೋಗ ಲಕ್ಷಣಗಳನ್ನು ಆಯ್ಕೆಮಾಡಿ',
      sec3: '೩. ದೇಹದ ಅಳತೆಗಳು ಮತ್ತು ಹಿಂದಿನ ಇತಿಹಾಸ',
      sec3Conditions: 'ಹಿಂದಿನ ಕಾಯಿಲೆಗಳು',
      sec3Notes: 'ಇತರ ತೊಂದರೆಗಳು ಅಥವಾ ಟಿಪ್ಪಣಿಗಳು',
      notesPlaceholder: 'ಆಹಾರ ಅಲರ್ಜಿ, ಜ್ವರದ ರೀತಿ, ಅಥವಾ ನಿರ್ದಿಷ್ಟ ನೋವಿನ ಸ್ಥಳವನ್ನು ಬರೆಯಿರಿ...',
      customPlaceholder: 'ಇತರ ರೋಗಲಕ್ಷಣವನ್ನು ಸೇರಿಸಿ (ಉದಾಹರಣೆಗೆ ಮೈಮೇಲೆ ದದ್ದು, ತಲೆಸುತ್ತು)...',
      addBtn: '+ ಸೇರಿಸಿ',
      redFlagTag: '⚠️ ತುರ್ತು ಗಮನ',
      selectedCount: 'ಆಯ್ಕೆಯಾದ ಲಕ್ಷಣಗಳು:',
      daysUnit: 'ದಿನಗಳು',
      processingTitle: 'ಹಂತ ೭: ದತ್ತಾಂಶ ಸಂಸ್ಕರಣೆ ಮತ್ತು AI ಸ್ಕ್ರೀನಿಂಗ್ ವಿಶ್ಲೇಷಣೆ...',
      processingDesc: 'ರೋಗಲಕ್ಷಣಗಳು, ದೇಹದ ತಾಪಮಾನ ಮತ್ತು ವರೂರು ಪ್ರಾಥಮಿಕ ಕೇಂದ್ರದ ಪ್ರೋಟೋಕಾಲ್ ಪ್ರಕಾರ ವಿಶ್ಲೇಷಿಸಲಾಗುತ್ತಿದೆ...',
      officialReportTitle: 'ವರೂರು ಗ್ರಾಮೀಣ ಆರೋಗ್ಯ AI ಪ್ರಾಥಮಿಕ ತಪಾಸಣಾ ವರದಿ',
      triageRiskLevel: 'ಹಂತ ೮: ಅಪಾಯದ ಮಟ್ಟ',
      possibleCondition: 'ಶಂಕಿತ ಆರೋಗ್ಯ ಸಮಸ್ಯೆ:',
      explainableTitle: 'ಹಂತ ೯: ಫಲಿತಾಂಶದ ವೈಜ್ಞಾನಿಕ ವಿವರಣೆ',
      guidanceTitle: 'ಹಂತ ೧೦: ವೈದ್ಯಕೀಯ ಮಾರ್ಗದರ್ಶನ ಮತ್ತು ಸಲಹೆಗಳು',
      urgentBadge: 'ತಕ್ಷಣದ ಆಸ್ಪತ್ರೆ ಭೇಟಿ ಶಿಫಾರಸು ಮಾಡಲಾಗಿದೆ',
      urgentText:
        'ವರದಿ ಮಾಡಲಾದ ರೋಗಲಕ್ಷಣಗಳ ಆಧಾರದ ಮೇಲೆ ತಡಮಾಡಬೇಡಿ. ತಕ್ಷಣ ವರೂರು ಪ್ರಾಥಮಿಕ ಆರೋಗ್ಯ ಕೇಂದ್ರ ಅಥವಾ ಹುಬ್ಬಳ್ಳಿಯ ಕಿಮ್ಸ್ (KIMS) ಆಸ್ಪತ್ರೆಗೆ ಭೇಟಿ ನೀಡಿ. ಆಂಬ್ಯುಲೆನ್ಸ್‌ಗಾಗಿ ೧೦೮ ಗೆ ಕರೆ ಮಾಡಿ.',
      doorstepMedicinesTitle: 'ಮನೆ ಬಾಗಿಲಿಗೆ ಸೂಚಿಸಲಾದ ಔಷಧಿಗಳು (ಮನೆ ',
      viewHospDetailsBtn: 'ಆಸ್ಪತ್ರೆ ಮತ್ತು ಆಂಬ್ಯುಲೆನ್ಸ್ ವಿವರಗಳನ್ನು ನೋಡಿ →',
      orderDeliveryBtn: 'ಔಷಧ ತರಿಸಿಕೊಳ್ಳಿ (೩೦-೪೫ ನಿಮಿಷ)',
    },
    hindi: {
      step1: 'चरण 5: स्वास्थ्य जानकारी',
      step2: 'चरण 7: एआई प्रोसेसिंग',
      step3: 'चरण 8-11: रिपोर्ट',
      sec1: '1. मरीज का विवरण एवं घर संख्या',
      sec2: '2. बीमारी के लक्षण चुनें',
      sec3: '3. शरीर के माप एवं पूर्व इतिहास',
      sec3Conditions: 'पूर्व बीमारियां',
      sec3Notes: 'अन्य शिकायतें या विवरण',
      notesPlaceholder: 'दवा एलर्जी या विशेष दर्द के स्थान का उल्लेख करें...',
      customPlaceholder: 'अन्य लक्षण जोड़ें (जैसे चक्कर, त्वचा पर चकत्ते)...',
      addBtn: '+ जोड़ें',
      redFlagTag: '⚠️ गंभीर लक्षण',
      selectedCount: 'चुने गए लक्षण:',
      daysUnit: 'दिन',
      processingTitle: 'चरण 7: डेटा प्रोसेसिंग एवं एआई स्क्रीनिंग विश्लेषण...',
      processingDesc: 'लक्षणों, तापमान और वरूर पीएचसी नियमों के आधार पर विश्लेषण जारी है...',
      officialReportTitle: 'वरूर ग्रामीण स्वास्थ्य AI प्राथमिक जांच रिपोर्ट',
      triageRiskLevel: 'चरण 8: जोखिम स्तर',
      possibleCondition: 'संभावित स्वास्थ्य समस्या:',
      explainableTitle: 'चरण 9: परिणाम का वैज्ञानिक कारण',
      guidanceTitle: 'चरण 10: चिकित्सीय मार्गदर्शन एवं सलाह',
      urgentBadge: 'तत्काल अस्पताल जाने की सलाह',
      urgentText:
        'गंभीर लक्षणों के कारण कृपया तुरंत वरूर प्राथमिक स्वास्थ्य केंद्र या हुबली के किम्स अस्पताल जाएं। 108 एम्बुलेंस को कॉल करें।',
      doorstepMedicinesTitle: 'घर तक सुझाई गई दवाइयां (घर ',
      viewHospDetailsBtn: 'अस्पताल एवं एम्बुलेंस विवरण देखें →',
      orderDeliveryBtn: 'दवा मंगवाएं (30-45 मिनट)',
    },
    english: {
      step1: 'Step 5: Health Info',
      step2: 'Step 7: AI Processing',
      step3: 'Step 8-11: Report',
      sec1: '1. Basic Profile & Village House Information',
      sec2: '2. Select Symptoms',
      sec3: '3. Vitals & Medical History',
      sec3Conditions: 'Pre-existing Conditions',
      sec3Notes: 'Other Complaints or Notes',
      notesPlaceholder: 'Mention any food allergies, fever pattern, or specific pain location...',
      customPlaceholder: 'Add other symptom (e.g. skin rash, dizziness, joint swelling)...',
      addBtn: '+ Add',
      redFlagTag: '⚠️ Red Flag',
      selectedCount: 'Selected Symptoms:',
      daysUnit: 'days',
      processingTitle: 'Step 7: Processing Health Information & Running AI Clinical Screening...',
      processingDesc: 'Analyzing symptom patterns with clinical vitals and Varur PHC triage protocols...',
      officialReportTitle: 'Varur Rural Health AI Preliminary Assessment Report',
      triageRiskLevel: 'Step 8: Triage Risk Level',
      possibleCondition: 'Possible Preliminary Condition:',
      explainableTitle: 'Step 9: Explainable AI Logic',
      guidanceTitle: 'Step 10: Actionable Clinical Guidance',
      urgentBadge: 'Urgent Clinical Action Recommended',
      urgentText:
        'Based on reported symptoms, do not delay. Please visit KIMS Hospital Hubballi or Varur PHC immediately. Dial 108 for emergency ambulance.',
      doorstepMedicinesTitle: 'Doorstep Medicines for House ',
      viewHospDetailsBtn: 'View Hospital & Ambulance Details →',
      orderDeliveryBtn: 'Order Medicines Now (30-45 mins)',
    },
  };

  const wiz = stepTrackerLabels[language] || stepTrackerLabels.english;

  const preExistingOptions = {
    kannada: ['ಮಧುಮೇಹ (ಸಕ್ಕರೆ ಕಾಯಿಲೆ)', 'ರಕ್ತದೊತ್ತಡ (ಬಿ.ಪಿ)', 'ಉಬ್ಬಸ (ಅಸ್ತಮಾ)', 'ಹೃದಯ ಸಂಬಂಧಿ ತೊಂದರೆ', 'ಗರ್ಭಾವಸ್ಥೆ', 'ಯಾವುದೂ ಇಲ್ಲ'],
    hindi: ['मधुमेह (शुगर)', 'रक्तचाप (बीपी)', 'दमा (अस्थमा)', 'हृदय रोग', 'गर्भावस्था', 'कोई नहीं'],
    english: ['Diabetes', 'Hypertension (BP)', 'Asthma', 'Heart condition', 'Pregnancy', 'None'],
  };

  const preList = preExistingOptions[language] || preExistingOptions.english;

  return (
    <div className="max-w-4xl mx-auto py-6 px-4 sm:px-6">
      {/* Title & Progress Tracker */}
      <div className="mb-6 bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="p-2.5 rounded-2xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                <Stethoscope className="w-5 h-5" />
              </span>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                {t.screening}
              </h2>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              {t.villageTag}
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-semibold">
            <span
              className={`px-3 py-1 rounded-full ${
                currentStep === 'form'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
              }`}
            >
              {wiz.step1}
            </span>
            <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
            <span
              className={`px-3 py-1 rounded-full ${
                currentStep === 'processing'
                  ? 'bg-emerald-600 text-white animate-pulse'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
              }`}
            >
              {wiz.step2}
            </span>
            <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
            <span
              className={`px-3 py-1 rounded-full ${
                currentStep === 'result'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
              }`}
            >
              {wiz.step3}
            </span>
          </div>
        </div>

        {/* Doctor Disclaimer Notice */}
        <div className="mt-3 p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 flex items-start gap-2.5 text-xs text-amber-900 dark:text-amber-200">
          <Info className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
          <p className="leading-relaxed font-medium">{t.disclaimerNotice}</p>
        </div>
      </div>

      {/* STEP 5 & 6: ENTER HEALTH INFORMATION & VALIDATION */}
      {currentStep === 'form' && (
        <div className="space-y-6 animate-in fade-in">
          {/* STEP 6 VALIDATION ERROR BANNER */}
          {validationError && (
            <div className="p-4 rounded-2xl bg-red-50 dark:bg-red-950/70 border-2 border-red-400 text-red-800 dark:text-red-200 flex items-start gap-3 shadow-md animate-shake">
              <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-sm">{t.validationErrorTitle}</p>
                <p className="text-xs sm:text-sm font-medium mt-0.5">{validationError}</p>
              </div>
            </div>
          )}

          {/* Section 1: Basic Patient Info */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              {wiz.sec1}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {t.patientNameLabel}
                </label>
                <input
                  type="text"
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  placeholder={language === 'kannada' ? 'ಉದಾ: ಸುರೇಶ್ ಪಾಟೀಲ' : 'e.g. Suresh Patil'}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {t.houseSelectLabel}
                </label>
                <select
                  value={houseId}
                  onChange={(e) => setHouseId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm font-medium focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="VRR-H01">VRR-H01 (Main Bazaar Road)</option>
                  <option value="VRR-H02">VRR-H02 (Navagraha Teertha Road)</option>
                  <option value="VRR-H03">VRR-H03 (Gram Panchayat Galli)</option>
                  <option value="VRR-H04">VRR-H04 (Temple Street)</option>
                  <option value="VRR-H05">VRR-H05 (Agasanakatte Road)</option>
                  <option value="VRR-H06">VRR-H06 (Kabbur Road)</option>
                  <option value="VRR-H07">VRR-H07 (Maruthi Galli)</option>
                  <option value="VRR-H08">VRR-H08 (School Road)</option>
                  <option value="VRR-H09">VRR-H09 (NH-48 Service Road)</option>
                  <option value="VRR-H10">VRR-H10 (Post Office Road)</option>
                  <option value="VRR-H11">VRR-H11 (Kere Oni / Lake Road)</option>
                  <option value="VRR-H12">VRR-H12 (Shanti Nagar)</option>
                  <option value="VRR-H13">VRR-H13 (Bazaar Cross)</option>
                  <option value="VRR-H14">VRR-H14 (Grama Chavadi Road)</option>
                  <option value="VRR-H15">VRR-H15 (Kabbur Cross West)</option>
                  <option value="VRR-NEW">VRR-NEW</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {t.mobileNumberLabel}
                </label>
                <input
                  type="text"
                  value={patientMobile}
                  onChange={(e) => setPatientMobile(e.target.value)}
                  placeholder="10 digits"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {t.ageLabel} *
                </label>
                <input
                  type="number"
                  min="1"
                  max="120"
                  value={age}
                  onChange={(e) => {
                    setAge(e.target.value);
                    setValidationError(null);
                  }}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {t.genderLabel} *
                </label>
                <div className="flex gap-2">
                  {(['male', 'female', 'other'] as const).map((g) => (
                    <button
                      key={g}
                      type="button"
                      onClick={() => setGender(g)}
                      className={`flex-1 py-2 text-xs font-semibold capitalize rounded-xl border transition-all ${
                        gender === g
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                          : 'bg-slate-50 dark:bg-slate-800 border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {g === 'male' ? t.male : g === 'female' ? t.female : t.other}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {t.durationLabel}
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="range"
                    min="1"
                    max="14"
                    value={durationDays}
                    onChange={(e) => setDurationDays(Number(e.target.value))}
                    className="flex-1 accent-emerald-600"
                  />
                  <span className="w-16 text-center text-xs font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950 px-2 py-1 rounded-lg">
                    {durationDays} {wiz.daysUnit}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Section 2: Symptoms Selection */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                {wiz.sec2} *
              </h3>
              <span className="text-xs text-slate-400">
                {wiz.selectedCount} {selectedSymptoms.length}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
              {commonSymptoms.map((sym) => {
                const isSelected = selectedSymptoms.includes(sym.id);
                return (
                  <button
                    key={sym.id}
                    type="button"
                    onClick={() => toggleSymptom(sym.id)}
                    className={`p-3 rounded-2xl border text-left transition-all flex items-start justify-between gap-1.5 ${
                      isSelected
                        ? sym.redFlag
                          ? 'bg-red-50 dark:bg-red-950/50 border-red-500 text-red-900 dark:text-red-200 shadow-xs'
                          : 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500 text-emerald-900 dark:text-emerald-200 shadow-xs'
                        : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                    }`}
                  >
                    <div>
                      <p className="text-xs font-bold leading-snug">{sym.label}</p>
                      {sym.redFlag && (
                        <span className="text-[9px] text-red-600 font-bold uppercase block mt-0.5">
                          {wiz.redFlagTag}
                        </span>
                      )}
                    </div>
                    {isSelected && (
                      <CheckCircle2
                        className={`w-4 h-4 shrink-0 ${
                          sym.redFlag ? 'text-red-600' : 'text-emerald-600'
                        }`}
                      />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Custom Additional Symptom */}
            <div className="flex gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <input
                type="text"
                value={customSymptomInput}
                onChange={(e) => setCustomSymptomInput(e.target.value)}
                placeholder={wiz.customPlaceholder}
                className="flex-1 px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs focus:ring-2 focus:ring-emerald-500"
              />
              <button
                type="button"
                onClick={addCustomSymptom}
                className="px-4 py-2 bg-slate-800 dark:bg-slate-700 hover:bg-slate-900 text-white rounded-xl text-xs font-semibold"
              >
                {wiz.addBtn}
              </button>
            </div>
          </div>

          {/* Section 3: Vitals & Medical History */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              {wiz.sec3}
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1 flex items-center gap-1">
                  <Thermometer className="w-3.5 h-3.5 text-amber-500" />
                  {t.temperatureLabel}
                </label>
                <input
                  type="text"
                  value={tempF}
                  onChange={(e) => setTempF(e.target.value)}
                  placeholder="99.4"
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1 flex items-center gap-1">
                  <Heart className="w-3.5 h-3.5 text-red-500" />
                  {t.bpLabel}
                </label>
                <input
                  type="text"
                  value={bp}
                  onChange={(e) => setBp(e.target.value)}
                  placeholder="120/80"
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1 flex items-center gap-1">
                  <Activity className="w-3.5 h-3.5 text-blue-500" />
                  {t.pulseLabel}
                </label>
                <input
                  type="text"
                  value={pulse}
                  onChange={(e) => setPulse(e.target.value)}
                  placeholder="78"
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1 flex items-center gap-1">
                  <Activity className="w-3.5 h-3.5 text-teal-500" />
                  {t.spo2Label}
                </label>
                <input
                  type="text"
                  value={spo2}
                  onChange={(e) => setSpo2(e.target.value)}
                  placeholder="98"
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm"
                />
              </div>
            </div>

            {/* Pre-existing tags */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {wiz.sec3Conditions}
              </label>
              <div className="flex flex-wrap gap-2">
                {preList.map((cond) => {
                  const active = preExisting.includes(cond);
                  return (
                    <button
                      key={cond}
                      type="button"
                      onClick={() => togglePreExisting(cond)}
                      className={`px-3 py-1 rounded-full text-xs font-medium border transition-colors ${
                        active
                          ? 'bg-blue-100 text-blue-800 border-blue-400 dark:bg-blue-950 dark:text-blue-300'
                          : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {cond}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {wiz.sec3Notes}
              </label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder={wiz.notesPlaceholder}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Action Trigger */}
          <div className="flex items-center justify-between pt-2">
            <p className="text-xs text-slate-500">
              {t.villageTag}
            </p>
            <button
              type="button"
              onClick={handleProceedToScreening}
              className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-linear-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-sm shadow-md shadow-emerald-600/30 transition-all hover:scale-102"
            >
              <span>{t.startScreeningBtn}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 7: DATA PROCESSING ANIMATION */}
      {currentStep === 'processing' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-10 border border-slate-200 dark:border-slate-800 shadow-lg text-center space-y-5 animate-in zoom-in-95">
          <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center mx-auto animate-pulse">
            <Activity className="w-8 h-8 animate-spin" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              {wiz.processingTitle}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 max-w-md mx-auto">
              {wiz.processingDesc}
            </p>
          </div>
        </div>
      )}

      {/* STEP 8, 9, 10, 11: DISPLAY SCREENING REPORT */}
      {currentStep === 'result' && screeningResult && (
        <div className="space-y-6 animate-in fade-in" id="screening-printable-report">
          {/* Main Result Card */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-md overflow-hidden">
            {/* Report Header */}
            <div className="p-5 sm:p-6 bg-gradient-to-r from-slate-900 to-slate-800 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-emerald-500 text-white">
                  {wiz.step3}
                </span>
                <h3 className="text-lg font-bold mt-1.5">{wiz.officialReportTitle}</h3>
                <p className="text-xs text-slate-300">
                  {t.reportId}: {screeningResult.screeningId} • {t.householdIdLabel}: {screeningResult.houseId} • {t.dateLabel}: {new Date(screeningResult.createdAt).toLocaleDateString()}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrint}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-medium transition-colors"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>{t.printReport}</span>
                </button>
                <button
                  onClick={resetForm}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>{t.newScreening}</span>
                </button>
              </div>
            </div>

            {/* Risk Gauge Bar */}
            <div className="p-5 sm:p-6 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  {wiz.triageRiskLevel}
                </span>
                <span
                  className={`text-xs font-extrabold px-3 py-1 rounded-full ${
                    screeningResult.riskLevel === 'High'
                      ? 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-200 border border-red-300'
                      : screeningResult.riskLevel === 'Moderate'
                      ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-200 border border-amber-300'
                      : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-200 border border-emerald-300'
                  }`}
                >
                  {screeningResult.riskLevel === 'High'
                    ? t.riskHigh
                    : screeningResult.riskLevel === 'Moderate'
                    ? t.riskModerate
                    : t.riskLow}
                </span>
              </div>

              <div className="w-full bg-slate-100 dark:bg-slate-800 h-3 rounded-full overflow-hidden flex">
                <div
                  className={`h-full transition-all duration-700 ${
                    screeningResult.riskLevel === 'High'
                      ? 'w-full bg-red-600'
                      : screeningResult.riskLevel === 'Moderate'
                      ? 'w-2/3 bg-amber-500'
                      : 'w-1/3 bg-emerald-500'
                  }`}
                />
              </div>

              {/* Suspected Health Problem */}
              <div className="mt-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <span className="text-[11px] font-bold uppercase text-slate-400">
                  {wiz.possibleCondition}
                </span>
                <h4 className="text-base font-bold text-slate-900 dark:text-white mt-0.5 text-emerald-700 dark:text-emerald-400">
                  {screeningResult.preliminaryCondition}
                </h4>
              </div>
            </div>

            {/* STEP 9: EXPLAINABLE RESULT */}
            <div className="p-5 sm:p-6 border-b border-slate-100 dark:border-slate-800 space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <Info className="w-4 h-4 text-emerald-600" />
                {wiz.explainableTitle}
              </h4>
              <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-200 leading-relaxed bg-emerald-50/50 dark:bg-emerald-950/20 p-4 rounded-2xl border border-emerald-100 dark:border-emerald-900/40">
                {screeningResult.explanation}
              </p>
            </div>

            {/* STEP 10: ACTIONABLE RECOMMENDATIONS & HOME CARE */}
            <div className="p-5 sm:p-6 space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                {wiz.guidanceTitle}
              </h4>

              <ul className="space-y-2">
                {screeningResult.recommendations?.map((rec: string, idx: number) => (
                  <li
                    key={idx}
                    className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl border border-slate-100 dark:border-slate-800"
                  >
                    <span className="w-5 h-5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <span className="leading-snug">{rec}</span>
                  </li>
                ))}
              </ul>

              {/* Red Flag Warning if High Risk */}
              {screeningResult.urgentActionRequired && (
                <div className="p-4 rounded-2xl bg-red-50 dark:bg-red-950/80 border-2 border-red-500 text-red-900 dark:text-red-200 space-y-2">
                  <div className="flex items-center gap-2">
                    <ShieldAlert className="w-5 h-5 text-red-600" />
                    <span className="font-bold text-sm uppercase">{wiz.urgentBadge}</span>
                  </div>
                  <p className="text-xs leading-relaxed">{wiz.urgentText}</p>
                </div>
              )}

              {/* Nearest Referral Hospital & Local Medicals */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3">
                <div className="p-4 rounded-2xl bg-blue-50 dark:bg-blue-950/50 border border-blue-200 dark:border-blue-900 space-y-1">
                  <span className="text-[10px] font-bold uppercase text-blue-700 dark:text-blue-300 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5" />
                    {t.nearestFacility}:
                  </span>
                  <p className="text-xs font-bold text-slate-900 dark:text-white">
                    {screeningResult.nearestHospitalReferral}
                  </p>
                  <p className="text-[11px] text-slate-500">
                    {t.ambulanceCall}
                  </p>
                  {onNavigateToHospitals && (
                    <button
                      onClick={onNavigateToHospitals}
                      className="mt-2 text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
                    >
                      {wiz.viewHospDetailsBtn}
                    </button>
                  )}
                </div>

                <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900 space-y-1">
                  <span className="text-[10px] font-bold uppercase text-emerald-700 dark:text-emerald-300 flex items-center gap-1">
                    <ShoppingBag className="w-3.5 h-3.5" />
                    {wiz.doorstepMedicinesTitle} {screeningResult.houseId}):
                  </span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {screeningResult.prescribedOtcMedicines?.map((m: string, idx: number) => (
                      <span
                        key={idx}
                        className="text-[10px] bg-white dark:bg-slate-800 text-emerald-800 dark:text-emerald-300 px-2 py-0.5 rounded border border-emerald-200 dark:border-emerald-800 font-medium"
                      >
                        {m}
                      </span>
                    ))}
                  </div>
                  {onOrderMedicinesForScreening && (
                    <button
                      onClick={() =>
                        onOrderMedicinesForScreening(
                          screeningResult.prescribedOtcMedicines || [],
                          screeningResult.houseId
                        )
                      }
                      className="mt-2 w-full py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-sm"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>{wiz.orderDeliveryBtn}</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
