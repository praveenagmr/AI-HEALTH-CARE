/**
 * User Profile & Personal Health Dashboard (Step 4)
 * Displays user's Varur household details, personal screening history,
 * active medicine orders, and local health guidelines.
 * 100% Language Isolation: Strictly displays only Kannada when Kannada is selected,
 * only Hindi when Hindi is selected, and only English when English is selected.
 */
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { useLanguage } from '../context/LanguageContext.tsx';
import {
  User,
  Home,
  Activity,
  ShoppingBag,
  FileText,
  Clock,
  ArrowRight,
  Phone,
} from 'lucide-react';

interface DashboardProps {
  onStartScreening: () => void;
  onNavigateToOrders: () => void;
}

export const UserProfileDashboard: React.FC<DashboardProps> = ({
  onStartScreening,
  onNavigateToOrders,
}) => {
  const { user, token, logout } = useAuth();
  const { language, t } = useLanguage();

  const [screenings, setScreenings] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    async function loadUserData() {
      if (!token) return;
      setIsLoading(true);
      try {
        const [sRes, oRes] = await Promise.all([
          fetch('/api/screening/history', { headers: { Authorization: `Bearer ${token}` } }),
          fetch('/api/orders/my', { headers: { Authorization: `Bearer ${token}` } }),
        ]);
        const sData = await sRes.json();
        const oData = await oRes.json();
        setScreenings(sData.screenings || []);
        setOrders(oData.orders || []);
      } catch (err) {
        console.warn('Failed to load user history:', err);
      } finally {
        setIsLoading(false);
      }
    }

    loadUserData();
  }, [token]);

  if (!user) return null;

  const dashboardTexts = {
    kannada: {
      screeningsTitle: 'ನಿಮ್ಮ ಆರೋಗ್ಯ ತಪಾಸಣೆಗಳು',
      ordersTitle: 'ವರೂರು ಔಷಧ ವಿತರಣೆಗಳು',
      noScreenings: 'ಯಾವುದೇ ತಪಾಸಣಾ ದಾಖಲೆಗಳು ಇನ್ನೂ ದಾಖಲಾಗಿಲ್ಲ.',
      startFirst: 'ನಿಮ್ಮ ಮೊದಲ ತಪಾಸಣೆ ಆರಂಭಿಸಿ →',
      noOrders: 'ಯಾವುದೇ ಸಕ್ರಿಯ ಔಷಧ ಆರ್ಡರ್‌ಗಳು ಇಲ್ಲ.',
      orderFirst: 'ವರೂರು ಮನೆ ಬಾಗಿಲಿಗೆ ಔಷಧ ತರಿಸಿಕೊಳ್ಳಿ →',
      symptomsLabel: 'ಲಕ್ಷಣಗಳು:',
      newTriageBtn: '+ ಹೊಸ ತಪಾಸಣೆ',
      newOrderBtn: '+ ಔಷಧ ಆರ್ಡರ್',
      ageUnit: 'ವರ್ಷಗಳು',
      deliveryToLabel: 'ವಿತರಿಸುವ ವಿಳಾಸ:',
    },
    hindi: {
      screeningsTitle: 'आपकी स्वास्थ्य जांच',
      ordersTitle: 'वरूर दवा होम डिलीवरी',
      noScreenings: 'अभी तक कोई जांच रिकॉर्ड दर्ज नहीं है।',
      startFirst: 'अपनी पहली स्वास्थ्य जांच शुरू करें →',
      noOrders: 'कोई सक्रिय दवा डिलीवरी नहीं है।',
      orderFirst: 'घर तक आवश्यक दवा मंगाएं →',
      symptomsLabel: 'लक्षण:',
      newTriageBtn: '+ नई जांच',
      newOrderBtn: '+ दवा ऑर्डर',
      ageUnit: 'वर्ष',
      deliveryToLabel: 'पहुंचाने का पता:',
    },
    english: {
      screeningsTitle: 'Your Health Screenings',
      ordersTitle: 'Varur Medicine Deliveries',
      noScreenings: 'No health screenings recorded yet.',
      startFirst: 'Start your first health screening →',
      noOrders: 'No active medicine deliveries.',
      orderFirst: 'Order medicines to Varur home →',
      symptomsLabel: 'Symptoms:',
      newTriageBtn: '+ New Screening',
      newOrderBtn: '+ Order Medicines',
      ageUnit: 'yrs',
      deliveryToLabel: 'Delivery Landmark:',
    },
  };

  const d = dashboardTexts[language] || dashboardTexts.english;

  const getRiskLabel = (risk: string) => {
    if (risk === 'High') return t.riskHigh;
    if (risk === 'Moderate') return t.riskModerate;
    return t.riskLow;
  };

  const getOrderStatusLabel = (status: string) => {
    if (status === 'Delivered') return t.statusDelivered;
    if (status === 'Out for Village Delivery') return t.statusOutForDelivery;
    if (status === 'Confirmed') return t.statusConfirmed;
    return t.statusPlaced;
  };

  return (
    <div className="max-w-6xl mx-auto py-6 px-4 sm:px-6 space-y-6">
      {/* Profile Header Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-600 text-white flex items-center justify-center font-bold text-xl shadow-md">
            {user.name.charAt(0)}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">{user.name}</h2>
            </div>
            <p className="text-xs text-slate-500 mt-0.5 flex flex-wrap items-center gap-2">
              <span className="flex items-center gap-1">
                <Home className="w-3.5 h-3.5 text-emerald-600" />
                {t.houseLabel}: <strong>{user.houseId}</strong>
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Phone className="w-3.5 h-3.5 text-slate-400" />
                {user.mobile}
              </span>
              <span>•</span>
              <span>
                {t.ageLabel}: {user.age} {d.ageUnit}
              </span>
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onStartScreening}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-all hover:scale-102"
          >
            <Activity className="w-4 h-4" />
            <span>{t.startScreeningBtn}</span>
          </button>
          <button
            onClick={logout}
            className="px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold transition-colors"
          >
            {t.logout}
          </button>
        </div>
      </div>

      {/* Grid: Screenings history & Active deliveries */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Previous Screenings */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
              <Activity className="w-4 h-4 text-emerald-600" />
              {d.screeningsTitle} ({screenings.length})
            </h3>
            <button
              onClick={onStartScreening}
              className="text-xs font-semibold text-emerald-600 hover:underline flex items-center gap-1"
            >
              <span>{d.newTriageBtn}</span>
            </button>
          </div>

          {screenings.length === 0 ? (
            <div className="text-center py-8 text-slate-400 space-y-2">
              <FileText className="w-8 h-8 mx-auto stroke-1" />
              <p className="text-xs">{d.noScreenings}</p>
              <button
                onClick={onStartScreening}
                className="mt-2 text-xs font-bold text-emerald-600 hover:underline"
              >
                {d.startFirst}
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {screenings.slice(0, 5).map((s) => (
                <div
                  key={s.screeningId}
                  className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/60 dark:bg-slate-800/40 space-y-2"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="font-mono text-[11px] text-slate-400">
                        {s.screeningId} • {new Date(s.createdAt).toLocaleDateString()}
                      </span>
                      <h4 className="text-xs font-bold text-slate-900 dark:text-white mt-0.5">
                        {s.preliminaryCondition}
                      </h4>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        s.riskLevel === 'High'
                          ? 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                          : s.riskLevel === 'Moderate'
                          ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                          : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                      }`}
                    >
                      {getRiskLabel(s.riskLevel)}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2">
                    {s.explanation}
                  </p>

                  <div className="text-[11px] text-slate-500 pt-1 border-t border-slate-200 dark:border-slate-700 flex justify-between">
                    <span>{d.symptomsLabel} {s.symptoms?.join(', ')}</span>
                    <span className="font-semibold text-emerald-600">{s.nearestHospitalReferral}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Active Medicine Orders */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-emerald-600" />
              {d.ordersTitle} ({orders.length})
            </h3>
            <button
              onClick={onNavigateToOrders}
              className="text-xs font-semibold text-emerald-600 hover:underline flex items-center gap-1"
            >
              <span>{d.newOrderBtn}</span>
            </button>
          </div>

          {orders.length === 0 ? (
            <div className="text-center py-8 text-slate-400 space-y-2">
              <ShoppingBag className="w-8 h-8 mx-auto stroke-1" />
              <p className="text-xs">{d.noOrders}</p>
              <button
                onClick={onNavigateToOrders}
                className="mt-2 text-xs font-bold text-emerald-600 hover:underline"
              >
                {d.orderFirst}
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {orders.slice(0, 5).map((o) => (
                <div
                  key={o.orderId}
                  className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/60 dark:bg-slate-800/40 space-y-2"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="font-mono text-[11px] text-slate-400">{o.orderId}</span>
                      <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                        {o.pharmacyName}
                      </h4>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300">
                      {getOrderStatusLabel(o.status)}
                    </span>
                  </div>

                  <div className="text-xs text-slate-600 dark:text-slate-300">
                    <p>{(o.items || []).map((i: any) => `${i.quantity}x ${i.name}`).join(', ')}</p>
                    <p className="font-bold text-slate-900 dark:text-white mt-1">
                      {t.totalAmount} ₹{o.totalAmount}
                    </p>
                  </div>

                  <div className="text-[11px] text-slate-400 pt-1 border-t border-slate-200 dark:border-slate-700 flex justify-between">
                    <span>{d.deliveryToLabel} {o.landmark || o.houseId}</span>
                    <span>{new Date(o.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
