/**
 * Home & About Page Component (Step 1)
 * 100% Language Isolation: Strictly displays only Kannada when Kannada is selected,
 * only Hindi when Hindi is selected, and only English when English is selected.
 */
import React from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import {
  HeartPulse,
  Activity,
  Building2,
  Truck,
  Mic,
  ArrowRight,
  Phone,
  AlertTriangle,
  MapPin,
  Sparkles,
  LogIn,
  UserPlus,
} from 'lucide-react';

interface HomePageProps {
  onStartScreening: () => void;
  openVoiceAssistant: () => void;
  onNavigateToTab: (tab: string) => void;
  openLoginModal: () => void;
  openRegisterModal: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onStartScreening,
  openVoiceAssistant,
  onNavigateToTab,
  openLoginModal,
  openRegisterModal,
}) => {
  const { language, t } = useLanguage();
  const { user } = useAuth();

  // 11 Steps in 100% isolated language
  const screeningStepsByLang = {
    kannada: [
      { num: '೧', title: 'ಹಂತ ೧: ಪೋರ್ಟಲ್ ತೆರೆಯುವುದು', desc: 'ಗ್ರಾಮದ ಸೌಲಭ್ಯಗಳ ಮಾಹಿತಿ, ತಪಾಸಣೆ ಮತ್ತು ಲಾಗಿನ್/ನೋಂದಣಿ.' },
      { num: '೨', title: 'ಹಂತ ೨: ಬಳಕೆದಾರರ ನೋಂದಣಿ', desc: 'ಹೆಸರು, ಮೊಬೈಲ್ ಸಂಖ್ಯೆ, ವಯಸ್ಸು ಮತ್ತು ವರೂರು ಮನೆ ಸಂಖ್ಯೆ ನಮೂದಿಸಿ.' },
      { num: '೩', title: 'ಹಂತ ೩: ಬಳಕೆದಾರರ ಲಾಗಿನ್', desc: 'ಸುರಕ್ಷಿತ ಸೆಷನ್‌ನೊಂದಿಗೆ ವೈಯಕ್ತಿಕ ಕುಟುಂಬದ ತಪಾಸಣೆ ಆರಂಭಿಸಿ.' },
      { num: '೪', title: 'ಹಂತ ೪: ಗ್ರಾಮ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್', desc: 'ತಪಾಸಣೆ, ಆರೋಗ್ಯ ದಾಖಲೆಗಳು ಮತ್ತು ಔಷಧ ಆರ್ಡರ್ ಸೌಲಭ್ಯ.' },
      { num: '೫', title: 'ಹಂತ ೫: ಆರೋಗ್ಯ ಮಾಹಿತಿ ನಮೂದು', desc: 'ವಯಸ್ಸು, ಲಿಂಗ, ರೋಗಲಕ್ಷಣಗಳು ಮತ್ತು ದೇಹದ ತಾಪಮಾನ, ಬಿ.ಪಿ.' },
      { num: '೬', title: 'ಹಂತ ೬: ದತ್ತಾಂಶ ಮೌಲ್ಯಮಾಪನ', desc: 'ತಪ್ಪಾದ ಅಥವಾ ಅಸ್ಪಷ್ಟ ಮಾಹಿತಿ ತಡೆಗಟ್ಟುವ ಪರಿಶೀಲನೆ.' },
      { num: '೭', title: 'ಹಂತ ೭: AI ಸಂಸ್ಕರಣೆ', desc: 'ಜೆಮಿನಿ ಕೃತಕ ಬುದ್ಧಿಮತ್ತೆ ಮಾದರಿಗೆ ಕ್ಲಿನಿಕಲ್ ವಿಶ್ಲೇಷಣೆ ಸಿದ್ಧತೆ.' },
      { num: '೮', title: 'ಹಂತ ೮: ಅಪಾಯದ ಮಟ್ಟ ನಿರ್ಧಾರ', desc: 'ಕಡಿಮೆ, ಮಧ್ಯಮ ಅಥವಾ ಹೆಚ್ಚಿನ ಅಪಾಯದ ಶ್ರೇಣೀಕರಣ.' },
      { num: '೯', title: 'ಹಂತ ೯: ಫಲಿತಾಂಶದ ವಿವರಣೆ', desc: 'AI ಈ ತೀರ್ಮಾನಕ್ಕೆ ಬರಲು ಮುಖ್ಯವಾದ ವೈಜ್ಞಾನಿಕ ಕಾರಣಗಳು.' },
      { num: '೧೦', title: 'ಹಂತ ೧೦: ಚಿಕಿತ್ಸಾ ಮಾರ್ಗದರ್ಶನ', desc: 'ಮನೆಮದ್ದು, ಸುರಕ್ಷಿತ ಪ್ರಾಥಮಿಕ ಔಷಧ ಮತ್ತು ವೈದ್ಯರ ಸಲಹೆ.' },
      { num: '೧೧', title: 'ಹಂತ ೧೧: ತಪಾಸಣಾ ವರದಿ', desc: 'ಅಧಿಕೃತ ವರದಿ ಕಾರ್ಡ್ ಮತ್ತು ವರೂರು ಪ್ರಾಥಮಿಕ ಕೇಂದ್ರ/ಕಿಮ್ಸ್ ಶಿಫಾರಸು.' },
    ],
    hindi: [
      { num: '1', title: 'चरण 1: पोर्टल खोलना', desc: 'गांव की स्वास्थ्य सुविधाएं, प्रणाली विवरण और लॉगिन/पंजीकरण।' },
      { num: '2', title: 'चरण 2: उपयोगकर्ता पंजीकरण', desc: 'नाम, मोबाइल, आयु एवं वरूर घर संख्या के साथ सुरक्षित खाता।' },
      { num: '3', title: 'चरण 3: उपयोगकर्ता लॉगिन', desc: 'सुरक्षित सत्र के साथ पारिवारिक स्वास्थ्य जांच शुरू करें।' },
      { num: '4', title: 'चरण 4: ग्राम डैशबोर्ड', desc: 'जांच, स्वास्थ्य रिकॉर्ड और दवा होम डिलीवरी की सुविधा।' },
      { num: '5', title: 'चरण 5: स्वास्थ्य जानकारी', desc: 'आयु, लिंग, बीमारी के लक्षण और तापमान/रक्तचाप दर्ज करें।' },
      { num: '6', title: 'चरण 6: डेटा सत्यापन', desc: 'गलत या अधूरी जानकारी रोकने के लिए सख्त जांच।' },
      { num: '7', title: 'चरण 7: एआई प्रोसेसिंग', desc: 'जेमिनी एआई मॉडल द्वारा क्लिनिकल डेटा का विश्लेषण।' },
      { num: '8', title: 'चरण 8: जोखिम स्तर', desc: 'कम, मध्यम अथवा उच्च जोखिम स्तर का निर्धारण।' },
      { num: '9', title: 'चरण 9: परिणाम का कारण', desc: 'एआई द्वारा इस नतीजे पर पहुंचने का वैज्ञानिक कारण।' },
      { num: '10', title: 'चरण 10: उपचार सलाह', desc: 'घरेलू नुस्खे, सुरक्षित सामान्य दवाइयां और डॉक्टर सलाह।' },
      { num: '11', title: 'चरण 11: जांच रिपोर्ट', desc: 'अधिकारिक रिपोर्ट सारांश और वरूर अस्पताल रेफरल।' },
    ],
    english: [
      { num: 1, title: 'Step 1: Open Portal', desc: 'Browse village facilities, about system, login or register.' },
      { num: 2, title: 'Step 2: User Registration', desc: 'Secure signup with name, mobile, age, and Varur house ID.' },
      { num: 3, title: 'Step 3: User Login', desc: 'Verified session for personalized family screening.' },
      { num: 4, title: 'Step 4: Village Dashboard', desc: 'Access screening wizard, health records, and pharmacy dispatch.' },
      { num: 5, title: 'Step 5: Health Info Entry', desc: 'Enter age, gender, symptoms, vitals (temp, SpO2, BP).' },
      { num: 6, title: 'Step 6: Data Validation', desc: 'Strict verification preventing faulty medical input.' },
      { num: 7, title: 'Step 7: Data Processing', desc: 'Formatting clinical measurements for Gemini 3.8 Flash model.' },
      { num: 8, title: 'Step 8: AI/ML Triage', desc: 'Calculates Low / Moderate / High Risk and condition.' },
      { num: 9, title: 'Step 9: Explainable Result', desc: 'Clear clinical reasoning why the AI generated this result.' },
      { num: 10, title: 'Step 10: Guidance & Care', desc: 'Home remedies, safe OTC medicines, and doctor consultation.' },
      { num: 11, title: 'Step 11: Screening Report', desc: 'Official triage summary card & referral to Varur PHC / KIMS.' },
    ],
  };

  const stepsList = screeningStepsByLang[language] || screeningStepsByLang.english;

  // Village Network Card texts
  const networkCardTexts = {
    kannada: {
      title: 'ವರೂರು ಗ್ರಾಮ ಆರೋಗ್ಯ ಜಾಲ',
      region: 'ಹುಬ್ಬಳ್ಳಿ ತಾಲ್ಲೂಕು, ಕರ್ನಾಟಕ',
      phcName: 'ವರೂರು ಪ್ರಾಥಮಿಕ ಆರೋಗ್ಯ ಕೇಂದ್ರ (PHC)',
      phcDesc: '೨೪/೭ ಹೆರಿಗೆ, ಜ್ವರ ಕ್ಲಿನಿಕ್ ಮತ್ತು ಪ್ರಯೋಗಾಲಯ',
      phcDist: 'ದೂರ: ೦.೮ ಕಿ.ಮೀ (ವರೂರಿನ ಒಳಗೆ)',
      callBtn: 'ಕರೆ',
      kimsName: 'ಕಿಮ್ಸ್ (KIMS) ಆಸ್ಪತ್ರೆ, ಹುಬ್ಬಳ್ಳಿ',
      kimsDesc: '೧೨೦೦+ ಹಾಸಿಗೆಗಳ ಸೂಪರ್ ಸ್ಪೆಷಾಲಿಟಿ ಆಸ್ಪತ್ರೆ',
      kimsDist: '೧೬.೫ ಕಿ.ಮೀ (೨೦ ನಿಮಿಷ)',
      chemistTitle: 'ವರೂರು ಔಷಧ ಅಂಗಡಿಗಳ ಹೋಮ್ ಡೆಲಿವರಿ',
      chemistTime: '೩೦-೪೫ ನಿಮಿಷ',
      chemistList: 'ಶ್ರೀ ಬಸವೇಶ್ವರ ಮೆಡಿಕಲ್ಸ್ • ಜೈನ್ ಮೆಡಿಕಲ್ಸ್ • ಸಂಜೀವನಿ ಮೆಡಿಕಲ್ಸ್',
      housesCount: '೧೫ ಮನೆಗಳು ನೋಂದಾಯಿತ',
      status: 'ಗ್ರಾಮೀಣ ಆರೋಗ್ಯ ನೆಟ್‌ವರ್ಕ್',
      aboutHeading: 'ಗ್ರಾಮೀಣ ಆರೋಗ್ಯ ವ್ಯವಸ್ಥೆಯ ಬಗ್ಗೆ',
      aboutText:
        'ವರೂರಿನಂತಹ ಗ್ರಾಮೀಣ ಪ್ರದೇಶದಲ್ಲಿ ತುರ್ತು ಸಂದರ್ಭದಲ್ಲಿ ಹುಬ್ಬಳ್ಳಿಗೆ ಹೋಗಲು ಸಮಯ ಬೇಕಾಗುತ್ತದೆ. ನಮ್ಮ ಕೃತಕ ಬುದ್ಧಿಮತ್ತೆ ವ್ಯವಸ್ಥೆಯು ರೋಗಲಕ್ಷಣಗಳ ತಕ್ಷಣದ ತಪಾಸಣೆ, ಅಪಾಯದ ಮಟ್ಟ ಮತ್ತು ಮನೆ ಬಾಗಿಲಿಗೆ ಔಷಧ ತರಿಸಲು ನೆರವಾಗುತ್ತದೆ.',
      realityTitle: 'ವರೂರು ಗ್ರಾಮದ ಭೌಗೋಳಿಕ ಹಿನ್ನೆಲೆ',
      realityDesc:
        'ರಾಷ್ಟ್ರೀಯ ಹೆದ್ದಾರಿ ೪೮ (ಪುಣೆ-ಬೆಂಗಳೂರು ಹೆದ್ದಾರಿ) ಪಕ್ಕದಲ್ಲಿದ್ದು, ಹುಬ್ಬಳ್ಳಿ ನಗರದಿಂದ ೧೬ ಕಿ.ಮೀ ದೂರದಲ್ಲಿದೆ. ಪ್ರಸಿದ್ಧ ನವಗ್ರಹ ತೀರ್ಥ, ಕೃಷಿಕ ಕುಟುಂಬಗಳು ಮತ್ತು ಪ್ರಾಥಮಿಕ ಆರೋಗ್ಯ ಕೇಂದ್ರವನ್ನು ಹೊಂದಿದೆ.',
    },
    hindi: {
      title: 'वरूर ग्राम स्वास्थ्य नेटवर्क',
      region: 'हुबली तालुका, कर्नाटक',
      phcName: 'वरूर प्राथमिक स्वास्थ्य केंद्र (PHC)',
      phcDesc: '24/7 प्रसूति, बुखार क्लिनिक व लैब',
      phcDist: 'दूरी: 0.8 किमी (वरूर में)',
      callBtn: 'कॉल',
      kimsName: 'किम्स (KIMS) अस्पताल, हुबली',
      kimsDesc: '1200+ बिस्तर सुपर स्पेशलिटी अस्पताल',
      kimsDist: '16.5 किमी (20 मिनट)',
      chemistTitle: 'वरूर दवा दुकानों से होम डिलीवरी',
      chemistTime: '30-45 मिनट',
      chemistList: 'श्री बसवेश्वर मेडिकल्स • जैन मेडिकल्स • संजीवनी मेडिकल्स',
      housesCount: '15 घर पंजीकृत',
      status: 'ग्रामीण स्वास्थ्य तंत्र',
      aboutHeading: 'ग्रामीण स्वास्थ्य प्रणाली के बारे में',
      aboutText:
        'वरूर जैसे ग्रामीण क्षेत्र में आपात स्थिति में हुबली शहर जाने में समय लगता है। हमारा एआई पोर्टल बीमारी की तुरंत प्रारंभिक जांच, जोखिम स्तर और घर तक दवा पहुंचाने में मदद करता है।',
      realityTitle: 'वरूर गांव की भौगोलिक पृष्ठभूमि',
      realityDesc:
        'राष्ट्रीय राजमार्ग 48 (पुणे-बेंगलुरु) पर स्थित, हुबली शहर से 16 किमी दक्षिण। प्रसिद्ध नवग्रह तीर्थ, किसान परिवार और प्राथमिक स्वास्थ्य केंद्र यहां स्थित हैं।',
    },
    english: {
      title: 'Varur Village Health Network',
      region: 'Hubballi Taluk, Karnataka',
      phcName: 'Varur Primary Health Centre (PHC)',
      phcDesc: '24x7 Maternity, Fever Clinic & Lab',
      phcDist: 'Distance: 0.8 km (Inside Varur)',
      callBtn: 'Call',
      kimsName: 'KIMS Hospital Hubballi',
      kimsDesc: '1200+ Beds Tertiary Super Speciality Hospital',
      kimsDist: '16.5 km via NH-48 (20 mins)',
      chemistTitle: 'Varur Chemist Home Delivery',
      chemistTime: '30-45 mins',
      chemistList: 'Shri Basaveshwara Medicals • Jain Medicals • Sanjeevani Medicals',
      housesCount: '15 Houses Registered',
      status: 'Rural Triage Network',
      aboutHeading: 'About The Rural Healthcare System',
      aboutText:
        'In rural areas like Varur, access to specialized physicians can take hours of travel to Hubballi. Our AI health screening portal enables immediate triage, symptom correlation, and doorstep medicine dispatch.',
      realityTitle: 'Geographical Background of Varur Village',
      realityDesc:
        'Located along National Highway 48 (Pune-Bengaluru Highway), 16 km south of Hubballi. Home to agricultural families, famous Navagraha Teertha, and Primary Health Centre.',
    },
  };

  const net = networkCardTexts[language] || networkCardTexts.english;

  return (
    <div className="space-y-12 pb-12">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-emerald-50/80 via-white to-slate-50 dark:from-slate-900 dark:via-slate-900 dark:to-slate-950 border-b border-slate-200 dark:border-slate-800 pt-8 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs font-bold">
                <MapPin className="w-3.5 h-3.5" />
                <span>{t.villageTag}</span>
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 dark:text-white tracking-tight leading-tight">
                {t.heroMainTitlePre}{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-teal-600">
                  {t.heroMainTitleHighlight}
                </span>
              </h1>

              <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl">
                {t.appSubtitle}
              </p>

              {/* Crucial Medical Disclaimer Banner */}
              <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/50 border border-amber-300 dark:border-amber-800/80 text-amber-900 dark:text-amber-200 text-xs leading-relaxed flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <p className="font-medium">{t.disclaimerNotice}</p>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={onStartScreening}
                  className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-linear-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-sm shadow-lg shadow-emerald-600/30 transition-all hover:scale-102"
                >
                  <Activity className="w-5 h-5" />
                  <span>{t.startScreeningBtn}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={openVoiceAssistant}
                  className="flex items-center gap-2 px-5 py-3.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-100 font-bold text-sm hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors shadow-xs"
                >
                  <Mic className="w-5 h-5 text-emerald-600" />
                  <span>{t.voiceAssistant}</span>
                </button>

                <button
                  onClick={() => onNavigateToTab('orders')}
                  className="flex items-center gap-2 px-5 py-3.5 rounded-xl bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800 text-teal-800 dark:text-teal-200 font-bold text-sm hover:bg-teal-100 transition-colors"
                >
                  <Truck className="w-4 h-4" />
                  <span>{t.medicineOrder}</span>
                </button>
              </div>

              {/* Guest Login/Register Prompts */}
              {!user && (
                <div className="pt-2 flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
                  <span>{t.residentAccountLabel}</span>
                  <button
                    onClick={openLoginModal}
                    className="font-bold text-emerald-600 hover:underline flex items-center gap-1"
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    <span>{t.login}</span>
                  </button>
                  <span>•</span>
                  <button
                    onClick={openRegisterModal}
                    className="font-bold text-emerald-600 hover:underline flex items-center gap-1"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>{t.register}</span>
                  </button>
                </div>
              )}
            </div>

            {/* Right Card: Varur Live Healthcare Card */}
            <div className="lg:col-span-5">
              <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4 relative">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                  <div>
                    <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                      {net.title}
                    </h3>
                    <p className="text-xs text-slate-400">{net.region}</p>
                  </div>
                  <span className="w-3 h-3 rounded-full bg-emerald-500 animate-ping"></span>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex items-start justify-between">
                    <div>
                      <p className="font-bold text-slate-900 dark:text-white">
                        {net.phcName}
                      </p>
                      <p className="text-slate-500 mt-0.5">{net.phcDesc}</p>
                      <p className="text-emerald-600 font-bold mt-1">{net.phcDist}</p>
                    </div>
                    <a
                      href="tel:08362310108"
                      className="p-2.5 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold text-xs"
                    >
                      {net.callBtn}
                    </a>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex items-start justify-between">
                    <div>
                      <p className="font-bold text-slate-900 dark:text-white">
                        {net.kimsName}
                      </p>
                      <p className="text-slate-500 mt-0.5">{net.kimsDesc}</p>
                      <p className="text-blue-600 font-bold mt-1">{net.kimsDist}</p>
                    </div>
                    <a
                      href="tel:108"
                      className="p-2.5 rounded-xl bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300 font-bold text-xs"
                    >
                      108
                    </a>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                    <div className="flex items-center justify-between mb-1">
                      <p className="font-bold text-slate-900 dark:text-white">
                        {net.chemistTitle}
                      </p>
                      <span className="text-[10px] font-bold text-emerald-600">
                        {net.chemistTime}
                      </span>
                    </div>
                    <p className="text-slate-500 leading-snug">{net.chemistList}</p>
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between text-[11px] text-slate-400">
                  <span>{net.housesCount}</span>
                  <span>{net.status}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About The System Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="text-center max-w-3xl mx-auto space-y-2">
          <span className="text-xs uppercase font-extrabold tracking-wider text-emerald-600 dark:text-emerald-400">
            {net.aboutHeading}
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            {t.featuresTitle}
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
            {net.aboutText}
          </p>
        </div>

        {/* 4 Core Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-2.5">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center font-bold">
              <Activity className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              {t.pillar1Title}
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              {t.pillar1Desc}
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-2.5">
            <div className="w-10 h-10 rounded-2xl bg-teal-100 dark:bg-teal-950 text-teal-600 flex items-center justify-center font-bold">
              <Mic className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              {t.pillar2Title}
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              {t.pillar2Desc}
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-2.5">
            <div className="w-10 h-10 rounded-2xl bg-blue-100 dark:bg-blue-950 text-blue-600 flex items-center justify-center font-bold">
              <Truck className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              {t.pillar3Title}
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              {t.pillar3Desc}
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-100 dark:bg-amber-950 text-amber-600 flex items-center justify-center font-bold">
              <Building2 className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              {t.pillar4Title}
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              {t.pillar4Desc}
            </p>
          </div>
        </div>

        {/* 11 Steps Workflow Grid */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                {t.stepTitle}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                {language === 'kannada'
                  ? 'ಲಕ್ಷಣಗಳ ನಮೂದಿನಿಂದ ಹಿಡಿದು ವರದಿಯವರೆಗೆ ಸಂಪೂರ್ಣ ಕ್ಲಿನಿಕಲ್ ಹಂತಗಳು'
                  : language === 'hindi'
                  ? 'शुरुआती लक्षणों से लेकर अंतिम रिपोर्ट तक संपूर्ण प्रक्रिया'
                  : 'End-to-end clinical workflow from initial symptom entry to explainable report'}
              </p>
            </div>
            <button
              onClick={onStartScreening}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors self-start sm:self-auto"
            >
              {t.startScreeningBtn} →
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {stepsList.map((s: any, idx: number) => (
              <div
                key={idx}
                className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 space-y-1"
              >
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-emerald-600 text-white text-[11px] font-bold flex items-center justify-center shrink-0">
                    {s.num}
                  </span>
                  <p className="font-bold text-xs text-slate-900 dark:text-white">{s.title}</p>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 pl-7">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Varur Village Reality Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-emerald-800 via-teal-800 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <span className="text-[11px] uppercase font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-emerald-500 text-white">
                {t.villageTag}
              </span>
              <h3 className="text-xl sm:text-2xl font-bold mt-2">{net.realityTitle}</h3>
              <p className="text-xs sm:text-sm text-emerald-100 mt-1 max-w-2xl leading-relaxed">
                {net.realityDesc}
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => onNavigateToTab('hospitals')}
                className="px-4 py-2.5 rounded-xl bg-white text-emerald-900 font-bold text-xs hover:bg-emerald-50 transition-colors"
              >
                {t.exploreHospitalsBtn}
              </button>
              <button
                onClick={() => onNavigateToTab('orders')}
                className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors"
              >
                {t.exploreMedicalsBtn}
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
