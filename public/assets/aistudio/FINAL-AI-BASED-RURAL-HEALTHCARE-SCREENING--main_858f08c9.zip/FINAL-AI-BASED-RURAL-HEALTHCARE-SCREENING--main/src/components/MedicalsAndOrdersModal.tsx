/**
 * Medicine Ordering & Home Delivery Interface for Varur Village
 * Allows residents to select medicines, pick their Varur House ID,
 * and track doorstep delivery from local village medical stores.
 */
import React, { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import {
  ShoppingBag,
  Truck,
  CheckCircle,
  Phone,
  Clock,
  MapPin,
  Plus,
  Minus,
  Trash2,
  FileCheck,
  AlertCircle,
} from 'lucide-react';

interface MedicineItem {
  id: string;
  name: string;
  category: string;
  price: number;
  unit: string;
  otc: boolean;
  description: string;
}

interface OrderProps {
  initialMedicines?: string[];
  initialHouseId?: string;
  onClose?: () => void;
}

export const MedicalsAndOrdersModal: React.FC<OrderProps> = ({
  initialMedicines = [],
  initialHouseId,
}) => {
  const { language, t } = useLanguage();
  const { user, token } = useAuth();

  const [catalog, setCatalog] = useState<MedicineItem[]>([]);
  const [medicalStores, setMedicalStores] = useState<any[]>([]);
  const [selectedStore, setSelectedStore] = useState<string>('MED-VRR-01');
  const [cart, setCart] = useState<{ item: MedicineItem; quantity: number }[]>([]);
  const [houseId, setHouseId] = useState<string>(initialHouseId || user?.houseId || 'VRR-H01');
  const [deliveryAddress, setDeliveryAddress] = useState<string>(
    user?.address || 'Near Banyan Tree, Main Bazaar, House VRR-H01, Varur'
  );
  const [contactPhone, setContactPhone] = useState<string>(user?.mobile || '9480112340');
  const [paymentMode, setPaymentMode] = useState<string>('Cash on Delivery');
  const [orderNotes, setOrderNotes] = useState<string>('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [orderSuccessMessage, setOrderSuccessMessage] = useState<string | null>(null);
  const [userOrders, setUserOrders] = useState<any[]>([]);

  // Fetch medicines catalog & medical stores
  useEffect(() => {
    async function loadData() {
      try {
        const [medRes, storeRes] = await Promise.all([
          fetch('/api/healthcare/medicines-catalog'),
          fetch('/api/healthcare/medicals'),
        ]);
        const medData = await medRes.json();
        const storeData = await storeRes.json();

        setCatalog(medData.medicines || []);
        setMedicalStores(storeData.medicals || []);

        // Pre-fill initial suggested medicines if any
        if (initialMedicines.length > 0 && medData.medicines) {
          const matchedItems = medData.medicines.filter((m: MedicineItem) =>
            initialMedicines.some((im) => m.name.toLowerCase().includes(im.toLowerCase()))
          );
          if (matchedItems.length > 0) {
            setCart(matchedItems.map((item: MedicineItem) => ({ item, quantity: 1 })));
          }
        }
      } catch (err) {
        console.warn('Failed to load healthcare data:', err);
      }
    }

    loadData();
  }, [initialMedicines]);

  // Load user orders
  useEffect(() => {
    async function loadOrders() {
      if (!token) return;
      try {
        const res = await fetch('/api/orders/my', {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = await res.json();
        setUserOrders(data.orders || []);
      } catch (err) {
        console.warn('Failed to load orders:', err);
      }
    }

    loadOrders();
  }, [token, orderSuccessMessage]);

  const addToCart = (item: MedicineItem) => {
    setCart((prev) => {
      const existing = prev.find((c) => c.item.id === item.id);
      if (existing) {
        return prev.map((c) => (c.item.id === item.id ? { ...c, quantity: c.quantity + 1 } : c));
      }
      return [...prev, { item, quantity: 1 }];
    });
  };

  const updateQuantity = (itemId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((c) => {
          if (c.item.id === itemId) {
            const newQty = c.quantity + delta;
            return newQty > 0 ? { ...c, quantity: newQty } : null;
          }
          return c;
        })
        .filter(Boolean) as any
    );
  };

  const totalCartAmount = cart.reduce((acc, curr) => acc + curr.item.price * curr.quantity, 0);

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) {
      alert('Please add at least one medicine to cart.');
      return;
    }

    setIsSubmitting(true);
    setOrderSuccessMessage(null);

    const storeObj = medicalStores.find((s) => s.storeId === selectedStore) || medicalStores[0];

    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          pharmacyId: storeObj?.storeId || 'MED-VRR-01',
          pharmacyName: storeObj?.name || 'Shri Basaveshwara Medicals, Varur',
          items: cart.map((c) => ({
            name: c.item.name,
            quantity: c.quantity,
            price: c.item.price,
          })),
          deliveryAddress,
          houseId,
          paymentMode,
          notes: orderNotes,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.error || 'Failed to place order');
        setIsSubmitting(false);
        return;
      }

      setOrderSuccessMessage(
        data.message || `Order placed successfully! Delivery on way to House ${houseId} in Varur.`
      );
      setCart([]);
    } catch (err) {
      alert('Connection error placing order. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto py-6 px-4 sm:px-6 space-y-8">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-700 via-teal-700 to-cyan-800 text-white rounded-2xl p-6 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-white/20">
              <ShoppingBag className="w-6 h-6 text-white" />
            </span>
            <h2 className="text-xl sm:text-2xl font-bold">
              {language === 'kannada'
                ? 'ವರೂರು ಗ್ರಾಮ ಔಷಧ ವಿತರಣಾ ಸೇವೆ'
                : language === 'hindi'
                ? 'वरूर गांव दवा होम डिलीवरी सेवा'
                : 'Varur Village Doorstep Medicine Delivery'}
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-emerald-100 mt-2 max-w-xl">
            {t.deliveryTimeNotice}. Order essential OTC & prescription medicines directly from trusted
            local chemists in Varur.
          </p>
        </div>

        <div className="flex items-center gap-3 bg-white/10 backdrop-blur-xs px-4 py-2.5 rounded-xl border border-white/20 text-xs font-semibold">
          <Truck className="w-5 h-5 text-emerald-300 animate-pulse" />
          <div>
            <p className="text-emerald-200">Delivery Guarantee:</p>
            <p className="font-bold text-white">30 - 45 mins inside Varur</p>
          </div>
        </div>
      </div>

      {orderSuccessMessage && (
        <div className="p-5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/80 border-2 border-emerald-500 text-emerald-900 dark:text-emerald-200 flex items-start gap-3 shadow-md animate-in zoom-in-95">
          <CheckCircle className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
          <div>
            <h4 className="font-bold text-base">Order Placed Successfully! (ಆರ್ಡರ್ ಸ್ವೀಕರಿಸಲಾಗಿದೆ)</h4>
            <p className="text-xs sm:text-sm mt-1">{orderSuccessMessage}</p>
            <p className="text-[11px] text-emerald-700 dark:text-emerald-400 mt-2">
              The pharmacy is packaging your medicines. You will receive doorstep delivery at House {houseId}.
            </p>
          </div>
        </div>
      )}

      {/* Main Grid: Medicine Catalog on left, Order Summary / Cart on right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Medicines Catalog */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="font-bold text-slate-900 dark:text-white text-base">
                  Varur Essential Medicines Catalog (ಅಗತ್ಯ ಔಷಧಗಳು)
                </h3>
                <p className="text-xs text-slate-500">
                  Select recommended remedies for your household
                </p>
              </div>

              {/* Local Pharmacy Selector */}
              <div className="text-right">
                <label className="block text-[10px] font-bold uppercase text-slate-400">
                  Select Local Pharmacy
                </label>
                <select
                  value={selectedStore}
                  onChange={(e) => setSelectedStore(e.target.value)}
                  className="mt-0.5 text-xs font-semibold px-2 py-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200"
                >
                  {medicalStores.map((s) => (
                    <option key={s.storeId} value={s.storeId}>
                      {s.name} ({s.deliveryTimeMins} mins)
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Medicine Items List */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {catalog.map((med) => {
                const inCart = cart.find((c) => c.item.id === med.id);
                return (
                  <div
                    key={med.id}
                    className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-emerald-300 dark:hover:border-emerald-700 bg-slate-50/50 dark:bg-slate-800/40 transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-1">
                        <h4 className="text-xs font-bold text-slate-900 dark:text-white leading-snug">
                          {med.name}
                        </h4>
                        <span className="text-xs font-extrabold text-emerald-600 dark:text-emerald-400 shrink-0">
                          ₹{med.price}
                        </span>
                      </div>
                      <span className="inline-block text-[10px] text-slate-500 dark:text-slate-400 font-medium">
                        {med.unit}
                      </span>
                      <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-1 line-clamp-2">
                        {med.description}
                      </p>
                    </div>

                    <div className="mt-3 pt-2 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between">
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-semibold">
                        OTC Safe
                      </span>

                      {inCart ? (
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => updateQuantity(med.id, -1)}
                            className="p-1 rounded-md bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 text-slate-800 dark:text-slate-200"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-xs font-bold w-4 text-center">{inCart.quantity}</span>
                          <button
                            onClick={() => updateQuantity(med.id, 1)}
                            className="p-1 rounded-md bg-emerald-600 text-white hover:bg-emerald-700"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => addToCart(med)}
                          className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold transition-colors flex items-center gap-1"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>Add</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Checkout & House Address Form */}
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4 sticky top-20">
            <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <ShoppingBag className="w-4 h-4 text-emerald-600" />
              Order Summary & Village Delivery
            </h3>

            {/* Cart Items */}
            {cart.length === 0 ? (
              <div className="text-center py-6 text-slate-400 space-y-2">
                <ShoppingBag className="w-8 h-8 mx-auto stroke-1" />
                <p className="text-xs">Your delivery bag is empty.</p>
                <p className="text-[11px]">Select medicines from the catalog to order to your Varur home.</p>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-48 overflow-y-auto pr-1">
                {cart.map(({ item, quantity }) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between text-xs p-2 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                  >
                    <div className="truncate max-w-[150px]">
                      <p className="font-bold text-slate-900 dark:text-white truncate">{item.name}</p>
                      <p className="text-[10px] text-slate-500">₹{item.price} each</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold">Qty: {quantity}</span>
                      <span className="font-bold text-emerald-600">₹{item.price * quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.id, -quantity)}
                        className="text-slate-400 hover:text-red-500"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Total */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-sm">
              <span className="font-semibold text-slate-600 dark:text-slate-400">Total Amount:</span>
              <span className="font-extrabold text-base text-emerald-600 dark:text-emerald-400">
                ₹{totalCartAmount}
              </span>
            </div>

            {/* Delivery Inputs */}
            <form onSubmit={handlePlaceOrder} className="space-y-3 pt-2">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Deliver to Varur House ID *
                </label>
                <select
                  value={houseId}
                  onChange={(e) => setHouseId(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold"
                >
                  <option value="VRR-H01">VRR-H01 (Main Bazaar Road - Patil)</option>
                  <option value="VRR-H02">VRR-H02 (Navagraha Teertha - Kulkarni)</option>
                  <option value="VRR-H03">VRR-H03 (Gram Panchayat Galli - Shettar)</option>
                  <option value="VRR-H04">VRR-H04 (Temple Street - Angadi)</option>
                  <option value="VRR-H05">VRR-H05 (Agasanakatte Road - Hiremath)</option>
                  <option value="VRR-H06">VRR-H06 (Kabbur Road - Gouder)</option>
                  <option value="VRR-H07">VRR-H07 (Maruthi Galli - Pujar)</option>
                  <option value="VRR-H08">VRR-H08 (School Road - Doddamani)</option>
                  <option value="VRR-H09">VRR-H09 (NH-48 Service Road - Kamatar)</option>
                  <option value="VRR-H10">VRR-H10 (Post Office Road - Madivalar)</option>
                  <option value="VRR-H11">VRR-H11 (Kere Oni - Badiger)</option>
                  <option value="VRR-H12">VRR-H12 (Shanti Nagar - Kurahatti)</option>
                  <option value="VRR-H13">VRR-H13 (Bazaar Cross - Javali)</option>
                  <option value="VRR-H14">VRR-H14 (Grama Chavadi Road - Hottiholi)</option>
                  <option value="VRR-H15">VRR-H15 (Kabbur Cross West - Banakar)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Delivery Address / Landmark
                </label>
                <input
                  type="text"
                  value={deliveryAddress}
                  onChange={(e) => setDeliveryAddress(e.target.value)}
                  placeholder="e.g. Near Old Banyan Tree, House VRR-H01"
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Contact Phone
                </label>
                <input
                  type="text"
                  value={contactPhone}
                  onChange={(e) => setContactPhone(e.target.value)}
                  placeholder="10-digit mobile"
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Payment Mode
                </label>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setPaymentMode('Cash on Delivery')}
                    className={`py-1.5 px-2 rounded-lg border font-medium ${
                      paymentMode === 'Cash on Delivery'
                        ? 'bg-emerald-50 dark:bg-emerald-950 border-emerald-500 text-emerald-800 dark:text-emerald-300'
                        : 'border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    Cash on Delivery
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMode('UPI at Doorstep')}
                    className={`py-1.5 px-2 rounded-lg border font-medium ${
                      paymentMode === 'UPI at Doorstep'
                        ? 'bg-emerald-50 dark:bg-emerald-950 border-emerald-500 text-emerald-800 dark:text-emerald-300'
                        : 'border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    UPI at Doorstep
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={cart.length === 0 || isSubmitting}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-xs sm:text-sm shadow-md transition-all flex items-center justify-center gap-1.5"
              >
                <Truck className="w-4 h-4" />
                <span>Confirm Varur Village Delivery (₹{totalCartAmount})</span>
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* User's Previous Medicine Delivery Orders */}
      {userOrders.length > 0 && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-600" />
            Your Village Medicine Deliveries ({userOrders.length})
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {userOrders.map((ord: any) => (
              <div
                key={ord.orderId}
                className="p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-slate-900 dark:text-white">
                    Order {ord.orderId}
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                      ord.orderStatus === 'Delivered'
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        : ord.orderStatus === 'Out for Village Delivery'
                        ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 animate-pulse'
                        : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                    }`}
                  >
                    ● {ord.orderStatus}
                  </span>
                </div>

                <div className="text-xs text-slate-600 dark:text-slate-300">
                  <p className="font-semibold text-emerald-600">{ord.pharmacyName}</p>
                  <p>Destination: House {ord.houseId}, {ord.deliveryAddress}</p>
                </div>

                <div className="text-[11px] text-slate-500 pt-1 border-t border-slate-200 dark:border-slate-700 flex justify-between">
                  <span>
                    Items: {ord.items?.map((i: any) => `${i.name} (${i.quantity})`).join(', ')}
                  </span>
                  <span className="font-bold text-slate-900 dark:text-white">₹{ord.totalAmount}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
