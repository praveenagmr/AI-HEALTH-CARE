/**
 * Varur Healthcare Directory
 * Displays accurate real-time data for:
 * 1. Local Medical Stores in Varur with Home Delivery
 * 2. Nearby Major Referral Hospitals & Emergency Ambulance Contacts
 */
import React, { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import {
  Building2,
  Phone,
  Truck,
  MapPin,
  Clock,
  ShieldAlert,
  Navigation,
  CheckCircle2,
  ExternalLink,
  Flame,
  Activity,
} from 'lucide-react';

interface DirectoryProps {
  onOrderMedicinesFromStore?: (storeId: string) => void;
}

export const VarurVillageDirectory: React.FC<DirectoryProps> = ({ onOrderMedicinesFromStore }) => {
  const { language, t } = useLanguage();
  const [medicals, setMedicals] = useState<any[]>([]);
  const [hospitals, setHospitals] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'hospitals' | 'medicals'>('hospitals');

  useEffect(() => {
    async function loadDirectory() {
      try {
        const [medRes, hospRes] = await Promise.all([
          fetch('/api/healthcare/medicals'),
          fetch('/api/healthcare/hospitals'),
        ]);
        const medData = await medRes.json();
        const hospData = await hospRes.json();
        setMedicals(medData.medicals || []);
        setHospitals(hospData.hospitals || []);
      } catch (err) {
        console.warn('Failed to load directory:', err);
      }
    }
    loadDirectory();
  }, []);

  return (
    <div className="max-w-6xl mx-auto py-6 px-4 sm:px-6 space-y-6">
      {/* Top Banner with Emergency 108 Hotline */}
      <div className="bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 text-white rounded-2xl p-5 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-white/20">
              <ShieldAlert className="w-6 h-6 text-white animate-pulse" />
            </span>
            <h3 className="font-extrabold text-lg sm:text-xl">
              Varur Emergency Health Hotline (ತುರ್ತು ವೈದ್ಯಕೀಯ ಸೇವೆ)
            </h3>
          </div>
          <p className="text-xs sm:text-sm text-red-100 max-w-xl">
            In case of severe difficulty breathing, sudden chest pain, snakebite, or accident on NH-48:
            Call State Emergency Ambulance 108 or Varur PHC Emergency immediately.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <a
            href="tel:108"
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white text-red-600 font-extrabold text-sm shadow-md hover:bg-red-50 transition-all hover:scale-105"
          >
            <Phone className="w-4 h-4 fill-current" />
            <span>Call 108 (Ambulance)</span>
          </a>
          <a
            href="tel:08362310108"
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-red-900/60 text-white font-bold text-xs border border-white/30 hover:bg-red-900 transition-colors"
          >
            <span>PHC Varur: 0836-2310108</span>
          </a>
        </div>
      </div>

      {/* Navigation Switcher: Hospitals vs Medical Stores */}
      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-2">
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab('hospitals')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
              activeTab === 'hospitals'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <Building2 className="w-4 h-4" />
            <span>Hospitals & PHC ({hospitals.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('medicals')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
              activeTab === 'medicals'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <Truck className="w-4 h-4" />
            <span>Varur Medicals & Home Delivery ({medicals.length})</span>
          </button>
        </div>

        <span className="text-xs text-slate-400 hidden sm:block">
          Location: NH-48 Corridor, Hubballi Taluk
        </span>
      </div>

      {/* HOSPITALS VIEW */}
      {activeTab === 'hospitals' && (
        <div className="space-y-4">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Showing nearest government and tertiary multi-speciality hospitals serving Varur residents,
            arranged by driving distance.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {hospitals.map((hosp: any) => (
              <div
                key={hosp.hospitalId}
                className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow space-y-3 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300">
                        {hosp.type}
                      </span>
                      <h4 className="text-base font-bold text-slate-900 dark:text-white mt-1">
                        {hosp.name}
                      </h4>
                    </div>
                    <span className="text-xs font-extrabold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950 px-2.5 py-1 rounded-lg shrink-0">
                      {hosp.distanceFromVarurKm} km from Varur
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 flex items-start gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                    <span>{hosp.address}</span>
                  </p>

                  {/* Specialities */}
                  <div className="mt-3 space-y-1">
                    <span className="text-[10px] font-bold uppercase text-slate-400">
                      Facilities & Emergency:
                    </span>
                    <ul className="text-xs text-slate-700 dark:text-slate-300 space-y-0.5">
                      {hosp.specialities?.slice(0, 3).map((spec: string, idx: number) => (
                        <li key={idx} className="flex items-center gap-1.5">
                          <CheckCircle2 className="w-3 h-3 text-emerald-500 shrink-0" />
                          <span>{spec}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Nearby Medicals to this Hospital */}
                  {hosp.nearbyMedicals && hosp.nearbyMedicals.length > 0 && (
                    <div className="mt-3 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 text-xs border border-slate-200 dark:border-slate-700">
                      <span className="text-[10px] font-bold text-slate-500 uppercase block mb-1">
                        24x7 Pharmacies Near Hospital:
                      </span>
                      <p className="text-[11px] text-slate-700 dark:text-slate-300 font-medium">
                        {hosp.nearbyMedicals.join(' • ')}
                      </p>
                    </div>
                  )}
                </div>

                {/* Contact & Directions */}
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                  <a
                    href={`tel:${hosp.phone.replace(/\D/g, '')}`}
                    className="flex-1 py-2 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Phone className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{hosp.phone}</span>
                  </a>

                  <a
                    href={`https://maps.google.com/?q=${encodeURIComponent(hosp.name + ' ' + hosp.location)}`}
                    target="_blank"
                    rel="noreferrer"
                    className="py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors flex items-center gap-1"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    <span>Directions</span>
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MEDICAL STORES VIEW */}
      {activeTab === 'medicals' && (
        <div className="space-y-4">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Registered village pharmacies providing 30-45 minutes home delivery directly to Varur house
            numbers (VRR-H01 to VRR-H15+).
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {medicals.map((store: any) => (
              <div
                key={store.storeId}
                className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow space-y-3 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                        {store.homeDeliveryAvailable ? 'Home Delivery Available' : 'Store Pickup'}
                      </span>
                      <h4 className="text-base font-bold text-slate-900 dark:text-white mt-1">
                        {store.name}
                      </h4>
                      <p className="text-xs text-slate-500">Pharmacist: {store.ownerName}</p>
                    </div>

                    <div className="text-right">
                      <span className="text-xs font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950 px-2 py-0.5 rounded">
                        {store.deliveryTimeMins} mins
                      </span>
                    </div>
                  </div>

                  <div className="mt-3 space-y-1.5 text-xs text-slate-600 dark:text-slate-400">
                    <p className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{store.location} ({store.landmark})</span>
                    </p>
                    <p className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>Hours: {store.openingHours}</span>
                    </p>
                  </div>

                  {/* Sample stocked medicines */}
                  <div className="mt-3">
                    <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
                      Available Key Medicines:
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {store.availableMedicines?.slice(0, 4).map((med: string, idx: number) => (
                        <span
                          key={idx}
                          className="text-[10px] px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium"
                        >
                          {med}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                  <a
                    href={`tel:${store.phone.replace(/\D/g, '')}`}
                    className="py-2 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-800 dark:text-slate-200 text-xs font-bold transition-colors flex items-center gap-1.5"
                  >
                    <Phone className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Call: {store.phone}</span>
                  </a>

                  {onOrderMedicinesFromStore && (
                    <button
                      onClick={() => onOrderMedicinesFromStore(store.storeId)}
                      className="py-2 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors flex items-center gap-1.5 shadow-xs"
                    >
                      <Truck className="w-3.5 h-3.5" />
                      <span>Order to Varur House</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
