/**
 * Admin Dashboard Component
 * Strictly protected for Admin (mobile: 8073370065, password: dj123456)
 * Manages all 15+ Varur village houses, patient health records,
 * epidemiological trends, and doorstep medicine orders.
 */
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { useLanguage } from '../context/LanguageContext.tsx';
import {
  ShieldCheck,
  Home,
  Users,
  Activity,
  ShoppingBag,
  Database,
  Plus,
  Edit2,
  CheckCircle,
  Truck,
  AlertTriangle,
  FileSpreadsheet,
  RefreshCw,
  Search,
  ExternalLink,
} from 'lucide-react';

export const AdminPanel: React.FC = () => {
  const { user, token, isAdmin } = useAuth();
  const { language } = useLanguage();

  const [activeTab, setActiveTab] = useState<'houses' | 'screenings' | 'orders'>('houses');
  const [houses, setHouses] = useState<any[]>([]);
  const [screenings, setScreenings] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  // House Modals
  const [isNewHouseModalOpen, setIsNewHouseModalOpen] = useState(false);
  const [editingHouse, setEditingHouse] = useState<any | null>(null);

  // New House Form State
  const [newHouseHead, setNewHouseHead] = useState('');
  const [newHouseMembers, setNewHouseMembers] = useState('4');
  const [newHousePhone, setNewHousePhone] = useState('');
  const [newHouseAddress, setNewHouseAddress] = useState('');
  const [newHouseLandmark, setNewHouseLandmark] = useState('');
  const [newHouseNotes, setNewHouseNotes] = useState('');

  const [isLoading, setIsLoading] = useState(false);

  const fetchData = async () => {
    if (!token) return;
    setIsLoading(true);
    try {
      const [hRes, sRes, oRes] = await Promise.all([
        fetch('/api/houses', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/screening/history', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/orders/all', { headers: { Authorization: `Bearer ${token}` } }),
      ]);

      const hData = await hRes.json();
      const sData = await sRes.json();
      const oData = await oRes.json();

      setHouses(hData.houses || []);
      setScreenings(sData.screenings || []);
      setOrders(oData.orders || []);
    } catch (err) {
      console.warn('Failed to load admin data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [token]);

  if (!isAdmin) {
    return (
      <div className="max-w-2xl mx-auto my-12 p-8 bg-red-50 dark:bg-red-950/40 rounded-2xl border-2 border-red-300 dark:border-red-900 text-center space-y-3">
        <ShieldCheck className="w-12 h-12 text-red-600 mx-auto" />
        <h3 className="text-lg font-bold text-red-900 dark:text-red-200">
          Admin Access Restricted
        </h3>
        <p className="text-xs text-red-700 dark:text-red-300">
          Only the authorized Varur Healthcare Administrator has permission to
          view and manage all 15 village houses and private records.
        </p>
      </div>
    );
  }

  const handleRegisterHouse = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/houses/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          headOfFamily: newHouseHead,
          familyMembersCount: Number(newHouseMembers),
          contactNumber: newHousePhone,
          addressLine: newHouseAddress,
          landmark: newHouseLandmark,
          notes: newHouseNotes,
        }),
      });

      if (res.ok) {
        setIsNewHouseModalOpen(false);
        setNewHouseHead('');
        setNewHousePhone('');
        setNewHouseAddress('');
        setNewHouseLandmark('');
        setNewHouseNotes('');
        fetchData();
      } else {
        const d = await res.json();
        alert(d.error || 'Failed to add house');
      }
    } catch (err) {
      alert('Error adding house');
    }
  };

  const handleUpdateHouse = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingHouse) return;

    try {
      const res = await fetch(`/api/houses/${editingHouse.houseId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(editingHouse),
      });

      if (res.ok) {
        setEditingHouse(null);
        fetchData();
      } else {
        alert('Failed to update house');
      }
    } catch (err) {
      alert('Error updating house');
    }
  };

  const handleUpdateOrderStatus = async (orderId: string, newStatus: string) => {
    try {
      const res = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status: newStatus }),
      });

      if (res.ok) {
        fetchData();
      }
    } catch (err) {
      alert('Failed to update order status');
    }
  };

  // Village Stats
  const totalPopulation = houses.reduce((acc, h) => acc + (Number(h.familyMembersCount) || 1), 0);
  const highRiskCases = screenings.filter((s) => s.riskLevel === 'High').length;
  const moderateRiskCases = screenings.filter((s) => s.riskLevel === 'Moderate').length;
  const lowRiskCases = screenings.filter((s) => s.riskLevel === 'Low').length;

  const filteredHouses = houses.filter(
    (h) =>
      h.headOfFamily?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      h.houseId?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      h.addressLine?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 space-y-6">
      {/* Admin Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 text-white rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="p-2 rounded-xl bg-red-600/30 border border-red-500/40 text-red-300">
              <ShieldCheck className="w-6 h-6 text-red-400" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-bold">
                  Varur Village Healthcare Management Console
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-600 text-white font-extrabold uppercase">
                  Official Console
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Village Registry • Household Directory & Clinical Records Management
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchData}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-white transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Sync Live Data</span>
          </button>
          <button
            onClick={() => setIsNewHouseModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-xs font-bold text-white transition-colors shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Add New House</span>
          </button>
        </div>
      </div>

      {/* Village Health Statistics Overview */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>Total Houses</span>
            <Home className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-2xl font-black text-slate-900 dark:text-white">{houses.length}</p>
          <p className="text-[11px] text-slate-500 mt-1">Village Population: ~{totalPopulation} persons</p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>Screenings Done</span>
            <Activity className="w-4 h-4 text-blue-600" />
          </div>
          <p className="text-2xl font-black text-slate-900 dark:text-white">{screenings.length}</p>
          <p className="text-[11px] text-slate-500 mt-1">AI Triage assessments filed</p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>High Risk Alerts</span>
            <AlertTriangle className="w-4 h-4 text-red-600" />
          </div>
          <p className="text-2xl font-black text-red-600">{highRiskCases}</p>
          <p className="text-[11px] text-slate-500 mt-1">Referred to KIMS / PHC</p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>Active Deliveries</span>
            <Truck className="w-4 h-4 text-amber-600" />
          </div>
          <p className="text-2xl font-black text-amber-600">{orders.length}</p>
          <p className="text-[11px] text-slate-500 mt-1">Varur doorstep medicine orders</p>
        </div>
      </div>

      {/* Tab Switcher */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('houses')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
            activeTab === 'houses'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
          }`}
        >
          <Home className="w-4 h-4" />
          <span>Village Houses ({houses.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('screenings')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
            activeTab === 'screenings'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Clinical Screenings ({screenings.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('orders')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
            activeTab === 'orders'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          <span>Medicine Orders ({orders.length})</span>
        </button>
      </div>

      {/* TAB 1: 15+ VILLAGE HOUSES MANAGEMENT */}
      {activeTab === 'houses' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by house ID, family head, or street..."
                className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs sm:text-sm focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <button
              onClick={() => setIsNewHouseModalOpen(true)}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors flex items-center gap-1.5 self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>Register New House in Varur</span>
            </button>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 text-slate-500 uppercase tracking-wider">
                  <tr>
                    <th className="px-4 py-3">House ID</th>
                    <th className="px-4 py-3">Head of Family</th>
                    <th className="px-4 py-3">Members</th>
                    <th className="px-4 py-3">Contact</th>
                    <th className="px-4 py-3">Street / Landmark</th>
                    <th className="px-4 py-3">Ration Card</th>
                    <th className="px-4 py-3">Health Notes</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredHouses.map((h) => (
                    <tr key={h.houseId} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                      <td className="px-4 py-3 font-mono font-bold text-emerald-600 dark:text-emerald-400">
                        {h.houseId}
                      </td>
                      <td className="px-4 py-3 font-bold text-slate-900 dark:text-white">
                        {h.headOfFamily}
                      </td>
                      <td className="px-4 py-3">{h.familyMembersCount} persons</td>
                      <td className="px-4 py-3">{h.contactNumber}</td>
                      <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                        {h.addressLine}, {h.landmark}
                      </td>
                      <td className="px-4 py-3 font-mono text-[11px] text-slate-500">
                        {h.rationCardNo || 'N/A'}
                      </td>
                      <td className="px-4 py-3 max-w-[200px] truncate text-slate-500">
                        {h.notes || 'None'}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button
                          onClick={() => setEditingHouse(h)}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-emerald-50 text-slate-700 dark:text-slate-200 hover:text-emerald-600 font-semibold transition-colors inline-flex items-center gap-1"
                        >
                          <Edit2 className="w-3 h-3" />
                          <span>Edit</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: CLINICAL SCREENINGS ACROSS VILLAGE */}
      {activeTab === 'screenings' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
          <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm">
              All Village Health Screening Records ({screenings.length})
            </h3>
            <span className="text-xs text-slate-400">Admin view of clinical triage</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 uppercase tracking-wider">
                <tr>
                  <th className="px-4 py-3">Screening ID</th>
                  <th className="px-4 py-3">Patient</th>
                  <th className="px-4 py-3">House ID</th>
                  <th className="px-4 py-3">Age/Gender</th>
                  <th className="px-4 py-3">Symptoms</th>
                  <th className="px-4 py-3">Risk Level</th>
                  <th className="px-4 py-3">Suspected Condition</th>
                  <th className="px-4 py-3">Referral</th>
                  <th className="px-4 py-3">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {screenings.map((s) => (
                  <tr key={s.screeningId} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                    <td className="px-4 py-3 font-mono font-bold text-emerald-600">
                      {s.screeningId}
                    </td>
                    <td className="px-4 py-3 font-semibold text-slate-900 dark:text-white">
                      {s.userName}
                    </td>
                    <td className="px-4 py-3 font-mono">{s.houseId}</td>
                    <td className="px-4 py-3">{s.age}y / {s.gender}</td>
                    <td className="px-4 py-3 max-w-[180px] truncate">
                      {s.symptoms?.join(', ')}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                          s.riskLevel === 'High'
                            ? 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                            : s.riskLevel === 'Moderate'
                            ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                            : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        }`}
                      >
                        {s.riskLevel}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-medium text-slate-800 dark:text-slate-200">
                      {s.preliminaryCondition}
                    </td>
                    <td className="px-4 py-3 text-slate-500">
                      {s.nearestHospitalReferral || 'Varur PHC'}
                    </td>
                    <td className="px-4 py-3 text-slate-400">
                      {new Date(s.createdAt).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: MEDICINE ORDERS MANAGEMENT */}
      {activeTab === 'orders' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
          <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm">
              All Village Medicine Orders & Doorstep Deliveries ({orders.length})
            </h3>
            <span className="text-xs text-slate-400">Manage pharmacy dispatch to Varur houses</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 uppercase tracking-wider">
                <tr>
                  <th className="px-4 py-3">Order ID</th>
                  <th className="px-4 py-3">Recipient</th>
                  <th className="px-4 py-3">House & Address</th>
                  <th className="px-4 py-3">Medicines</th>
                  <th className="px-4 py-3">Amount</th>
                  <th className="px-4 py-3">Current Status</th>
                  <th className="px-4 py-3 text-right">Update Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {orders.map((ord) => (
                  <tr key={ord.orderId} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                    <td className="px-4 py-3 font-mono font-bold text-emerald-600">{ord.orderId}</td>
                    <td className="px-4 py-3 font-semibold text-slate-900 dark:text-white">
                      {ord.userName} ({ord.userPhone})
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      House {ord.houseId} • {ord.deliveryAddress}
                    </td>
                    <td className="px-4 py-3 max-w-[200px] truncate">
                      {ord.items?.map((i: any) => `${i.name} (x${i.quantity})`).join(', ')}
                    </td>
                    <td className="px-4 py-3 font-bold text-slate-900 dark:text-white">
                      ₹{ord.totalAmount}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          ord.orderStatus === 'Delivered'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : ord.orderStatus === 'Out for Village Delivery'
                            ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                        }`}
                      >
                        {ord.orderStatus}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <select
                        value={ord.orderStatus}
                        onChange={(e) => handleUpdateOrderStatus(ord.orderId, e.target.value)}
                        className="text-xs px-2 py-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      >
                        <option value="Placed">Placed</option>
                        <option value="Confirmed">Confirmed</option>
                        <option value="Out for Village Delivery">Out for Village Delivery</option>
                        <option value="Delivered">Delivered</option>
                        <option value="Cancelled">Cancelled</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* EDIT HOUSE MODAL */}
      {editingHouse && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4">
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              Edit Household: {editingHouse.houseId}
            </h3>

            <form onSubmit={handleUpdateHouse} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Head of Family</label>
                <input
                  type="text"
                  value={editingHouse.headOfFamily}
                  onChange={(e) => setEditingHouse({ ...editingHouse, headOfFamily: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold mb-1">Family Members Count</label>
                  <input
                    type="number"
                    value={editingHouse.familyMembersCount}
                    onChange={(e) => setEditingHouse({ ...editingHouse, familyMembersCount: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Contact Phone</label>
                  <input
                    type="text"
                    value={editingHouse.contactNumber}
                    onChange={(e) => setEditingHouse({ ...editingHouse, contactNumber: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Street Address in Varur</label>
                <input
                  type="text"
                  value={editingHouse.addressLine}
                  onChange={(e) => setEditingHouse({ ...editingHouse, addressLine: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Health Notes / Risk Factors</label>
                <textarea
                  rows={2}
                  value={editingHouse.notes || ''}
                  onChange={(e) => setEditingHouse({ ...editingHouse, notes: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingHouse(null)}
                  className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 text-white font-bold"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* REGISTER NEW HOUSE MODAL */}
      {isNewHouseModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4">
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              Register New Household in Varur Village Registry
            </h3>

            <form onSubmit={handleRegisterHouse} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Head of Family *</label>
                <input
                  type="text"
                  required
                  value={newHouseHead}
                  onChange={(e) => setNewHouseHead(e.target.value)}
                  placeholder="e.g. Anand Hiremath"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold mb-1">Family Members Count *</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={newHouseMembers}
                    onChange={(e) => setNewHouseMembers(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Contact Phone *</label>
                  <input
                    type="text"
                    required
                    value={newHousePhone}
                    onChange={(e) => setNewHousePhone(e.target.value)}
                    placeholder="10-digit mobile"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Village Street Address *</label>
                <input
                  type="text"
                  required
                  value={newHouseAddress}
                  onChange={(e) => setNewHouseAddress(e.target.value)}
                  placeholder="e.g. Near Agasanakatte, Varur"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Prominent Landmark</label>
                <input
                  type="text"
                  value={newHouseLandmark}
                  onChange={(e) => setNewHouseLandmark(e.target.value)}
                  placeholder="e.g. Near Temple / Dairy Booth"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Health Notes / Pre-existing complaints</label>
                <textarea
                  rows={2}
                  value={newHouseNotes}
                  onChange={(e) => setNewHouseNotes(e.target.value)}
                  placeholder="Any senior citizens, pregnant women, or chronic illnesses..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsNewHouseModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 text-white font-bold"
                >
                  Register Household
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
