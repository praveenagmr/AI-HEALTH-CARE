/**
 * Authentication Modals (Login & Register)
 * Supports Step 2 (Registration) and Step 3 (Login) with JWT tokens.
 * Explicitly supports Admin credentials: 8073370065 / dj123456.
 */
import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { useLanguage } from '../context/LanguageContext.tsx';
import { LogIn, UserPlus, X, ShieldAlert, CheckCircle2, Lock, Phone, User, KeyRound } from 'lucide-react';

interface AuthModalProps {
  type: 'login' | 'register' | null;
  onClose: () => void;
  onSwitchType: (type: 'login' | 'register') => void;
}

export const AuthModals: React.FC<AuthModalProps> = ({ type, onClose, onSwitchType }) => {
  const { login, register } = useAuth();
  const { language, t } = useLanguage();

  // Login form state
  const [loginMobile, setLoginMobile] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Register form state
  const [regName, setRegName] = useState('');
  const [regMobile, setRegMobile] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regAge, setRegAge] = useState('28');
  const [regGender, setRegGender] = useState('male');
  const [regHouseId, setRegHouseId] = useState('VRR-H01');
  const [regAddress, setRegAddress] = useState('Varur Village, Hubballi Taluk');

  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  if (!type) return null;

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setIsLoading(true);

    const result = await login({
      mobile: loginMobile,
      password: loginPassword,
    });

    setIsLoading(false);
    if (result.success) {
      onClose();
    } else {
      setErrorMessage(result.error || 'Login failed. Please check credentials.');
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const parsedAge = Number(regAge);
    if (!regName.trim()) {
      setErrorMessage('Please enter your full name.');
      return;
    }
    if (!regMobile || regMobile.length < 10) {
      setErrorMessage('Please enter a valid 10-digit mobile number.');
      return;
    }
    if (!regPassword || regPassword.length < 6) {
      setErrorMessage('Password must be at least 6 characters.');
      return;
    }
    if (isNaN(parsedAge) || parsedAge < 1 || parsedAge > 120) {
      setErrorMessage('Please enter a valid age between 1 and 120.');
      return;
    }

    setIsLoading(true);

    const result = await register({
      name: regName.trim(),
      mobile: regMobile.trim(),
      email: regEmail.trim() || undefined,
      password: regPassword,
      age: parsedAge,
      gender: regGender,
      houseId: regHouseId,
      address: regAddress,
    });

    setIsLoading(false);
    if (result.success) {
      onClose();
    } else {
      setErrorMessage(result.error || 'Registration failed.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-emerald-600 to-teal-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            {type === 'login' ? <LogIn className="w-5 h-5" /> : <UserPlus className="w-5 h-5" />}
            <div>
              <h3 className="font-bold text-base">
                {type === 'login'
                  ? language === 'kannada'
                    ? 'ಹಂತ ೩: ಬಳಕೆದಾರರ ಲಾಗಿನ್'
                    : 'Step 3: User Login'
                  : language === 'kannada'
                  ? 'ಹಂತ ೨: ಬಳಕೆದಾರರ ನೋಂದಣಿ'
                  : 'Step 2: User Registration'}
              </h3>
              <p className="text-xs text-emerald-100">Varur Village Healthcare Portal</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded-lg hover:bg-white/20 text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {errorMessage && (
            <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/70 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 text-xs flex items-start gap-2">
              <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* LOGIN FORM */}
          {type === 'login' ? (
            <form onSubmit={handleLoginSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Mobile Number / Username *
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    required
                    value={loginMobile}
                    onChange={(e) => setLoginMobile(e.target.value)}
                    placeholder="Enter 10-digit mobile number"
                    className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Password *
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="password"
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="Enter your password"
                    className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md transition-colors flex items-center justify-center gap-1.5"
              >
                <LogIn className="w-4 h-4" />
                <span>{isLoading ? 'Verifying...' : 'Login with JWT Session'}</span>
              </button>

              <div className="text-center pt-2 border-t border-slate-100 dark:border-slate-800">
                <p className="text-slate-500">
                  New resident in Varur?{' '}
                  <button
                    type="button"
                    onClick={() => {
                      setErrorMessage(null);
                      onSwitchType('register');
                    }}
                    className="text-emerald-600 font-bold hover:underline"
                  >
                    Register here (ಹೊಸ ನೋಂದಣಿ)
                  </button>
                </p>
              </div>
            </form>
          ) : (
            /* REGISTER FORM */
            <form onSubmit={handleRegisterSubmit} className="space-y-3 text-xs max-h-[60vh] overflow-y-auto pr-1">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Full Name (ಹೆಸರು) *
                </label>
                <input
                  type="text"
                  required
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  placeholder="e.g. Suresh Patil"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Mobile Number *
                  </label>
                  <input
                    type="text"
                    required
                    value={regMobile}
                    onChange={(e) => setRegMobile(e.target.value)}
                    placeholder="10 digits"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Password *
                  </label>
                  <input
                    type="password"
                    required
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="Min 6 characters"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Age (ವಯಸ್ಸು) *
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="120"
                    required
                    value={regAge}
                    onChange={(e) => setRegAge(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Gender (ಲಿಂಗ) *
                  </label>
                  <select
                    value={regGender}
                    onChange={(e) => setRegGender(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-semibold"
                  >
                    <option value="male">Male (ಪುರುಷ)</option>
                    <option value="female">Female (ಮಹಿಳೆ)</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Varur House ID (15 Houses)
                </label>
                <select
                  value={regHouseId}
                  onChange={(e) => setRegHouseId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-semibold"
                >
                  <option value="VRR-H01">VRR-H01 (Main Bazaar Road)</option>
                  <option value="VRR-H02">VRR-H02 (Navagraha Teertha)</option>
                  <option value="VRR-H03">VRR-H03 (Gram Panchayat Galli)</option>
                  <option value="VRR-H04">VRR-H04 (Temple Street)</option>
                  <option value="VRR-H05">VRR-H05 (Agasanakatte Road)</option>
                  <option value="VRR-H06">VRR-H06 (Kabbur Road)</option>
                  <option value="VRR-H07">VRR-H07 (Maruthi Galli)</option>
                  <option value="VRR-H08">VRR-H08 (School Road)</option>
                  <option value="VRR-H09">VRR-H09 (NH-48 Service Road)</option>
                  <option value="VRR-H10">VRR-H10 (Post Office Road)</option>
                  <option value="VRR-H11">VRR-H11 (Kere Oni / Lake)</option>
                  <option value="VRR-H12">VRR-H12 (Shanti Nagar)</option>
                  <option value="VRR-H13">VRR-H13 (Bazaar Cross)</option>
                  <option value="VRR-H14">VRR-H14 (Grama Chavadi Road - Lead)</option>
                  <option value="VRR-H15">VRR-H15 (Kabbur Cross West)</option>
                  <option value="VRR-NEW">Other / New House</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Street Address in Varur
                </label>
                <input
                  type="text"
                  value={regAddress}
                  onChange={(e) => setRegAddress(e.target.value)}
                  placeholder="e.g. Near Panchayat Office, Varur"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md transition-colors flex items-center justify-center gap-1.5"
              >
                <UserPlus className="w-4 h-4" />
                <span>{isLoading ? 'Registering...' : 'Register Household Account'}</span>
              </button>

              <div className="text-center pt-2 border-t border-slate-100 dark:border-slate-800">
                <p className="text-slate-500">
                  Already registered?{' '}
                  <button
                    type="button"
                    onClick={() => {
                      setErrorMessage(null);
                      onSwitchType('login');
                    }}
                    className="text-emerald-600 font-bold hover:underline"
                  >
                    Login here (ಲಾಗಿನ್ ಮಾಡಿ)
                  </button>
                </p>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
