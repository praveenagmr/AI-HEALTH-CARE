/**
 * Dedicated History & Records Page
 * Allows viewing all past records in one place:
 * 1. Health Screening Triage Reports & Printable Assessment Cards
 * 2. Varur Village Doorstep Medicine Orders & Live Delivery Statuses
 * 3. AI Voice Assistant Consultations with Re-Listen Audio
 * 4. Unified All-Activity Timeline
 * Strictly adheres to 100% language isolation (Kannada, Hindi, English).
 */
import React, { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import {
  FileText,
  ShoppingBag,
  Activity,
  Calendar,
  MapPin,
  Search,
  Filter,
  Eye,
  Printer,
  X,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Truck,
  User,
  Phone,
  Mic,
  Volume2,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';

interface HistoryPageProps {
  onStartScreening?: () => void;
  onNavigateToOrders?: () => void;
}

export const HistoryPage: React.FC<HistoryPageProps> = ({
  onStartScreening,
  onNavigateToOrders,
}) => {
  const { language, t } = useLanguage();
  const { user, token } = useAuth();

  const [activeTab, setActiveTab] = useState<'screenings' | 'orders' | 'voice' | 'all'>('screenings');
  const [screenings, setScreenings] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [voiceConsultations, setVoiceConsultations] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterRisk, setFilterRisk] = useState<string>('all');
  const [selectedScreeningModal, setSelectedScreeningModal] = useState<any | null>(null);
  const [selectedOrderModal, setSelectedOrderModal] = useState<any | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    async function loadHistory() {
      setIsLoading(true);
      try {
        const headers: Record<string, string> = {};
        if (token) headers['Authorization'] = `Bearer ${token}`;

        const [sRes, oRes] = await Promise.all([
          fetch('/api/screening/history', { headers }),
          fetch('/api/orders/my', { headers }),
        ]);

        const sData = await sRes.json();
        const oData = await oRes.json();

        setScreenings(sData.screenings || []);
        setOrders(oData.orders || []);
      } catch (err) {
        console.warn('Failed to load history records:', err);
      } finally {
        setIsLoading(false);
      }

      // Load voice consultation history from localStorage
      try {
        const savedVoice = JSON.parse(localStorage.getItem('varur_voice_history') || '[]');
        setVoiceConsultations(savedVoice);
      } catch (e) {
        console.warn('Failed to parse voice history:', e);
      }
    }

    loadHistory();
  }, [token]);

  // Filtered screenings
  const filteredScreenings = screenings.filter((s) => {
    const matchesSearch =
      (s.userName || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.houseId || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.preliminaryCondition || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.symptoms || []).some((sym: string) => sym.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesRisk = filterRisk === 'all' || s.riskLevel === filterRisk;
    return matchesSearch && matchesRisk;
  });

  // Filtered orders
  const filteredOrders = orders.filter((o) => {
    const matchesSearch =
      (o.orderId || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (o.houseId || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (o.pharmacyName || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (o.items || []).some((i: any) => (i.name || '').toLowerCase().includes(searchQuery.toLowerCase()));

    return matchesSearch;
  });

  // Filtered voice consultations
  const filteredVoice = voiceConsultations.filter((v) => {
    const matchesSearch =
      (v.question || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (v.answer || '').toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSearch;
  });

  const getRiskLabel = (risk: string) => {
    if (risk === 'High') return t.riskHigh;
    if (risk === 'Moderate') return t.riskModerate;
    return t.riskLow;
  };

  const getOrderStatusLabel = (status: string) => {
    if (status === 'Delivered') return t.statusDelivered;
    if (status === 'Out for Village Delivery') return t.statusOutForDelivery;
    if (status === 'Confirmed') return t.statusConfirmed;
    return t.statusPlaced;
  };

  const playVoiceSnippet = (text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const cleanText = text.replace(/[*#_~`>•-]/g, ' ').slice(0, 150);
    const utt = new SpeechSynthesisUtterance(cleanText);
    if (language === 'kannada') {
      utt.lang = 'kn-IN';
      utt.rate = 0.9;
    } else if (language === 'hindi') {
      utt.lang = 'hi-IN';
      utt.rate = 0.95;
    } else {
      utt.lang = 'en-IN';
      utt.rate = 1.0;
    }
    window.speechSynthesis.speak(utt);
  };

  return (
    <div className="max-w-6xl mx-auto py-8 px-4 sm:px-6 lg:px-8 space-y-6">
      {/* Header Banner - 100% Isolated */}
      <div className="bg-linear-to-r from-emerald-800 via-teal-800 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="p-2.5 rounded-2xl bg-white/10 backdrop-blur-xs">
              <Calendar className="w-6 h-6 text-emerald-300" />
            </span>
            <h2 className="text-xl sm:text-2xl font-bold">{t.historyTitle}</h2>
          </div>
          <p className="text-xs sm:text-sm text-emerald-100 mt-2 max-w-xl">
            {t.historySubtitle}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onStartScreening && (
            <button
              onClick={onStartScreening}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white text-emerald-900 font-bold text-xs hover:bg-emerald-50 transition-colors"
            >
              <Activity className="w-4 h-4 text-emerald-600" />
              <span>{t.newScreening}</span>
            </button>
          )}
          {onNavigateToOrders && (
            <button
              onClick={onNavigateToOrders}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>{t.medicineOrder}</span>
            </button>
          )}
        </div>
      </div>

      {/* Tabs & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-3">
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setActiveTab('screenings')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
              activeTab === 'screenings'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
            }`}
          >
            <Activity className="w-4 h-4" />
            <span>
              {t.allScreeningsTab} ({screenings.length})
            </span>
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
              activeTab === 'orders'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>
              {t.allOrdersTab} ({orders.length})
            </span>
          </button>

          <button
            onClick={() => setActiveTab('voice')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
              activeTab === 'voice'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
            }`}
          >
            <Mic className="w-4 h-4" />
            <span>
              {t.allVoiceTab} ({voiceConsultations.length})
            </span>
          </button>
        </div>

        {/* Search Bar */}
        <div className="flex items-center gap-2">
          <div className="relative flex-1 sm:w-64">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.searchHistoryPlaceholder}
              className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {activeTab === 'screenings' && (
            <select
              value={filterRisk}
              onChange={(e) => setFilterRisk(e.target.value)}
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-700 dark:text-slate-300 font-semibold focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
            >
              <option value="all">{t.filterAll}</option>
              <option value="High">{t.filterHigh}</option>
              <option value="Moderate">{t.filterModerate}</option>
              <option value="Low">{t.filterLow}</option>
            </select>
          )}
        </div>
      </div>

      {/* Screenings Tab */}
      {activeTab === 'screenings' && (
        <div className="space-y-3">
          {filteredScreenings.length === 0 ? (
            <div className="text-center py-12 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 space-y-3">
              <FileText className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto" />
              <p className="text-sm font-bold text-slate-600 dark:text-slate-400">
                {t.noScreeningsFound}
              </p>
              {onStartScreening && (
                <button
                  onClick={onStartScreening}
                  className="px-4 py-2 rounded-xl bg-emerald-600 text-white font-bold text-xs"
                >
                  {t.startScreeningBtn}
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredScreenings.map((s) => {
                const isHigh = s.riskLevel === 'High';
                const isMod = s.riskLevel === 'Moderate';

                return (
                  <div
                    key={s._id || s.screeningId}
                    className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3 hover:border-emerald-500/50 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                            {s.userName || 'Varur Resident'}
                          </h4>
                          <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                            {t.houseLabel}: {s.houseId}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          {new Date(s.createdAt).toLocaleString(
                            language === 'kannada' ? 'kn-IN' : language === 'hindi' ? 'hi-IN' : 'en-IN'
                          )}
                        </p>
                      </div>

                      <span
                        className={`text-[11px] font-bold px-2.5 py-1 rounded-full border ${
                          isHigh
                            ? 'bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300 border-red-300'
                            : isMod
                            ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300 border-amber-300'
                            : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 border-emerald-300'
                        }`}
                      >
                        {getRiskLabel(s.riskLevel)}
                      </span>
                    </div>

                    <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-1">
                      <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                        {s.preliminaryCondition}
                      </p>
                      <div className="flex flex-wrap gap-1 pt-1">
                        {(s.symptoms || []).map((sym: string, idx: number) => (
                          <span
                            key={idx}
                            className="text-[10px] px-2 py-0.5 rounded-md bg-white dark:bg-slate-700 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-600"
                          >
                            {sym}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <div className="text-[11px] text-slate-500">
                        <span>{s.screeningId}</span>
                      </div>
                      <button
                        onClick={() => setSelectedScreeningModal(s)}
                        className="flex items-center gap-1 text-xs font-bold text-emerald-600 hover:text-emerald-700"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>{t.viewReportDetails}</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Orders Tab */}
      {activeTab === 'orders' && (
        <div className="space-y-3">
          {filteredOrders.length === 0 ? (
            <div className="text-center py-12 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 space-y-3">
              <ShoppingBag className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto" />
              <p className="text-sm font-bold text-slate-600 dark:text-slate-400">
                {t.noOrdersFound}
              </p>
              {onNavigateToOrders && (
                <button
                  onClick={onNavigateToOrders}
                  className="px-4 py-2 rounded-xl bg-emerald-600 text-white font-bold text-xs"
                >
                  {t.orderMedicineNow}
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredOrders.map((o) => (
                <div
                  key={o._id || o.orderId}
                  className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                          {o.pharmacyName}
                        </h4>
                        <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                          {t.houseLabel}: {o.houseId}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        {new Date(o.createdAt).toLocaleString(
                          language === 'kannada' ? 'kn-IN' : language === 'hindi' ? 'hi-IN' : 'en-IN'
                        )}
                      </p>
                    </div>

                    <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300">
                      {getOrderStatusLabel(o.status)}
                    </span>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-1">
                    <div className="text-xs text-slate-700 dark:text-slate-300 space-y-1">
                      {(o.items || []).map((item: any, idx: number) => (
                        <div key={idx} className="flex justify-between text-[11px]">
                          <span>
                            {item.quantity}x {item.name}
                          </span>
                          <span className="font-semibold">₹{item.price * item.quantity}</span>
                        </div>
                      ))}
                    </div>
                    <div className="border-t border-slate-200 dark:border-slate-700 pt-1.5 flex justify-between text-xs font-bold text-slate-900 dark:text-white">
                      <span>{t.totalAmount}</span>
                      <span>₹{o.totalAmount}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
                    <span>
                      {t.deliveryAddressLabel}: {o.landmark || o.houseId}
                    </span>
                    <button
                      onClick={() => setSelectedOrderModal(o)}
                      className="text-emerald-600 font-bold hover:underline"
                    >
                      {t.viewReportDetails}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Voice Consultations Tab */}
      {activeTab === 'voice' && (
        <div className="space-y-3">
          {filteredVoice.length === 0 ? (
            <div className="text-center py-12 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 space-y-3">
              <Mic className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto" />
              <p className="text-sm font-bold text-slate-600 dark:text-slate-400">
                {t.noVoiceFound}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredVoice.map((v) => (
                <div
                  key={v.id}
                  className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-2.5"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <span className="p-2 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600">
                        <User className="w-4 h-4" />
                      </span>
                      <p className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">
                        "{v.question}"
                      </p>
                    </div>

                    <button
                      onClick={() => playVoiceSnippet(v.answer)}
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-xs font-bold hover:bg-emerald-100 transition-colors shrink-0"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>{t.reListenAudio}</span>
                    </button>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">
                    {v.answer}
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                    <span>
                      {new Date(v.timestamp).toLocaleString(
                        language === 'kannada' ? 'kn-IN' : language === 'hindi' ? 'hi-IN' : 'en-IN'
                      )}
                    </span>
                    <span className="font-semibold text-emerald-600 uppercase">
                      {v.language}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Full Screening Details Modal with Printable Official Card */}
      {selectedScreeningModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  {t.printReport} • {selectedScreeningModal.screeningId}
                </h3>
              </div>
              <button
                onClick={() => setSelectedScreeningModal(null)}
                className="p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">{t.patientNameLabel}:</span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {selectedScreeningModal.userName} ({selectedScreeningModal.age},{' '}
                  {selectedScreeningModal.gender})
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">{t.houseLabel}:</span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {selectedScreeningModal.houseId}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">{t.riskLow} / {t.riskModerate} / {t.riskHigh}:</span>
                <span className="font-bold text-emerald-700 dark:text-emerald-300">
                  {getRiskLabel(selectedScreeningModal.riskLevel)}
                </span>
              </div>
            </div>

            <div className="space-y-2 text-xs">
              <h4 className="font-bold text-slate-900 dark:text-white">{t.whyResult}</h4>
              <p className="text-slate-600 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/50 p-3 rounded-2xl border border-slate-100 dark:border-slate-800">
                {selectedScreeningModal.explanation || selectedScreeningModal.preliminaryCondition}
              </p>
            </div>

            <div className="space-y-2 text-xs">
              <h4 className="font-bold text-slate-900 dark:text-white">{t.guidance}</h4>
              <p className="text-slate-600 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/50 p-3 rounded-2xl border border-slate-100 dark:border-slate-800 whitespace-pre-line">
                {selectedScreeningModal.actionableGuidance}
              </p>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => window.print()}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs"
              >
                <Printer className="w-4 h-4" />
                <span>{t.printReport}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Order Details Modal */}
      {selectedOrderModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  {selectedOrderModal.orderId}
                </h3>
              </div>
              <button
                onClick={() => setSelectedOrderModal(null)}
                className="p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">{t.pharmacyStoreLabel}:</span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {selectedOrderModal.pharmacyName}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">{t.houseLabel}:</span>
                <span className="font-bold">{selectedOrderModal.houseId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">{t.orderStatusLabel}</span>
                <span className="font-bold text-emerald-600">
                  {getOrderStatusLabel(selectedOrderModal.status)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">{t.contactPhoneLabel}:</span>
                <span>{selectedOrderModal.contactPhone}</span>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-1 text-xs">
              <p className="font-bold text-slate-900 dark:text-white mb-1">
                {t.itemsOrderedLabel}:
              </p>
              {(selectedOrderModal.items || []).map((i: any, idx: number) => (
                <div key={idx} className="flex justify-between text-[11px]">
                  <span>
                    {i.quantity}x {i.name}
                  </span>
                  <span>₹{i.price * i.quantity}</span>
                </div>
              ))}
              <div className="border-t border-slate-200 dark:border-slate-700 pt-1 flex justify-between font-bold text-slate-900 dark:text-white">
                <span>{t.totalAmount}</span>
                <span>₹{selectedOrderModal.totalAmount}</span>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setSelectedOrderModal(null)}
                className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs"
              >
                {t.close || 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
