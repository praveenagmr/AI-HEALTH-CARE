/**
 * Footer Component for Varur Rural Healthcare System
 * 100% Language Isolation: Strictly displays only Kannada when Kannada is selected,
 * only Hindi when Hindi is selected, and only English when English is selected.
 */
import React from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { HeartPulse, Phone } from 'lucide-react';

export const Footer: React.FC = () => {
  const { language, setLanguage, t } = useLanguage();

  const footerTexts = {
    kannada: {
      aboutMission:
        'ವರೂರು ಗ್ರಾಮದ ನಿವಾಸಿಗಳಿಗೆ ಕೃತಕ ಬುದ್ಧಿಮತ್ತೆ ಆಧಾರಿತ ಪ್ರಾಥಮಿಕ ಆರೋಗ್ಯ ತಪಾಸಣೆ, ೩ ಭಾಷೆಗಳ ಧ್ವನಿ ಸಹಾಯಕ, ಮತ್ತು ಮನೆ ಬಾಗಿಲಿಗೆ ಔಷಧ ವಿತರಣಾ ವ್ಯವಸ್ಥೆ.',
      helplineTitle: 'ತುರ್ತು ಸಹಾಯವಾಣಿಗಳು (೨೪/೭)',
      stateAmbulance: 'ರಾಜ್ಯ ಆಂಬ್ಯುಲೆನ್ಸ್: ೧೦೮ (ಉಚಿತ)',
      karnatakaHelpline: 'ಕರ್ನಾಟಕ ಆರೋಗ್ಯ ಸಹಾಯವಾಣಿ: ೧೦೪',
      phcContact: 'ವರೂರು ಪ್ರಾಥಮಿಕ ಆರೋಗ್ಯ ಕೇಂದ್ರ: ೦೮೩೬-೨೩೧೦೧೦೮',
      kimsContact: 'ಕಿಮ್ಸ್ ಆಸ್ಪತ್ರೆ ಹುಬ್ಬಳ್ಳಿ: ೦೮೩೬-೨೨೭೨೦೪೪',
      pharmaciesTitle: 'ವರೂರು ಔಷಧ ಅಂಗಡಿಗಳು (ಮನೆ ಬಾಗಿಲಿನ ವಿತರಣೆ)',
      pharmacy1: 'ಶ್ರೀ ಬಸವೇಶ್ವರ ಮೆಡಿಕಲ್ಸ್ (೯೪೮೦೧೨೩೪೫೧)',
      pharmacy2: 'ಜೈನ್ ಮೆಡಿಕಲ್ಸ್ (೯೮೪೫೨೩೩೪೧೨)',
      pharmacy3: 'ಸಂಜೀವನಿ ಮೆಡಿಕಲ್ಸ್ (೯೭೪೧೨೮೮೯೦೨)',
      pharmacy4: 'ಪ್ರಧಾನಮಂತ್ರಿ ಜನೌಷಧಿ ಕೇಂದ್ರ ವರೂರು (೦೮೩೬-೨೨೪೫೫೧೦)',
      deliveryPromise: '✓ ವರೂರು ಮನೆ ಸಂಖ್ಯೆಗಳಿಗೆ ೩೦-೪೫ ನಿಮಿಷಗಳಲ್ಲಿ ಔಷಧ ವಿತರಣೆ',
      disclaimerTitle: 'ಮುಖ್ಯ ಸೂಚನೆ',
      disclaimerText:
        'ಈ ಪೋರ್ಟಲ್ ಪ್ರಾಥಮಿಕ ತಪಾಸಣೆ ಮತ್ತು ಮಾರ್ಗದರ್ಶನಕ್ಕಾಗಿ ಮಾತ್ರ. ಗಂಭೀರ ರೋಗಲಕ್ಷಣಗಳಿದ್ದಲ್ಲಿ ತಕ್ಷಣ ವೈದ್ಯರನ್ನು ಭೇಟಿ ಮಾಡಿ.',
      copyright: '© ವರೂರು ಗ್ರಾಮೀಣ ಆರೋಗ್ಯ ಮಿಷನ್ • ಹುಬ್ಬಳ್ಳಿ ತಾಲ್ಲೂಕು, ಧಾರವಾಡ ಜಿಲ್ಲೆ, ಕರ್ನಾಟಕ.',
    },
    hindi: {
      aboutMission:
        'वरूर गांव के निवासियों के लिए एआई आधारित प्रारंभिक स्वास्थ्य जांच, 3 भाषाओं का वॉयस असिस्टेंट और घर तक आवश्यक दवा वितरण प्रणाली।',
      helplineTitle: 'आपातकालीन हेल्पलाइन (24/7)',
      stateAmbulance: 'राज्य एम्बुलेंस: 108 (निशुल्क)',
      karnatakaHelpline: 'कर्नाटक स्वास्थ्य हेल्पलाइन: 104',
      phcContact: 'वरूर प्राथमिक स्वास्थ्य केंद्र: 0836-2310108',
      kimsContact: 'किम्स अस्पताल हुबली: 0836-2272044',
      pharmaciesTitle: 'वरूर दवा दुकानें (होम डिलीवरी)',
      pharmacy1: 'श्री बसवेश्वर मेडिकल्स (9480123451)',
      pharmacy2: 'जैन मेडिकल्स (9845233412)',
      pharmacy3: 'संजीवनी मेडिकल्स (9741288902)',
      pharmacy4: 'प्रधानमंत्री जन औषधि केंद्र वरूर (0836-2245510)',
      deliveryPromise: '✓ वरूर घर संख्या पर 30-45 मिनट में दवा वितरण',
      disclaimerTitle: 'महत्वपूर्ण सूचना',
      disclaimerText:
        'यह पोर्टल प्रारंभिक जांच और मार्गदर्शन के लिए है। गंभीर स्थिति में तुरंत नजदीकी डॉक्टर या अस्पताल से संपर्क करें।',
      copyright: '© वरूर ग्रामीण स्वास्थ्य मिशन • हुबली तालुका, धारवाड़ जिला, कर्नाटक।',
    },
    english: {
      aboutMission:
        'AI-based rural healthcare screening, local health intelligence, multilingual voice assistance, and doorstep medicine delivery for Varur village.',
      helplineTitle: 'Emergency Helplines (24/7)',
      stateAmbulance: 'State Ambulance: 108 (24x7 Free)',
      karnatakaHelpline: 'Karnataka Health Helpline: 104',
      phcContact: 'Varur PHC Clinic: 0836-2310108',
      kimsContact: 'KIMS Hospital Hubballi: 0836-2272044',
      pharmaciesTitle: 'Varur Chemists (Doorstep Delivery)',
      pharmacy1: 'Shri Basaveshwara Medicals (9480123451)',
      pharmacy2: 'Jain Medical & Surgical (9845233412)',
      pharmacy3: 'Sanjeevani Medicals (9741288902)',
      pharmacy4: 'Pradhan Mantri Jan Aushadhi Kendra (0836-2245510)',
      deliveryPromise: '✓ 30-45 mins delivery to Varur House IDs',
      disclaimerTitle: 'Important Disclaimer',
      disclaimerText:
        'This portal is for preliminary triage and emergency guidance only. For acute symptoms, visit a physician immediately.',
      copyright: '© Varur Rural Health Mission • Hubballi Taluk, Dharwad Dist, Karnataka.',
    },
  };

  const f = footerTexts[language] || footerTexts.english;

  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800 text-xs mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Col 1: About Varur Mission */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white font-bold">
                <HeartPulse className="w-5 h-5" />
              </div>
              <span className="font-bold text-sm text-white">{t.appName}</span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed">
              {f.aboutMission}
            </p>
            <p className="text-[11px] text-emerald-400 font-semibold">
              {t.talukInfo}
            </p>
          </div>

          {/* Col 2: Emergency Helplines */}
          <div className="space-y-2.5">
            <h4 className="font-bold text-white uppercase tracking-wider text-[11px]">
              {f.helplineTitle}
            </h4>
            <ul className="space-y-1.5 text-slate-400">
              <li className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-red-400" />
                <span>{f.stateAmbulance}</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-emerald-400" />
                <span>{f.karnatakaHelpline}</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-blue-400" />
                <span>{f.phcContact}</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-amber-400" />
                <span>{f.kimsContact}</span>
              </li>
            </ul>
          </div>

          {/* Col 3: Village Chemists (Home Delivery) */}
          <div className="space-y-2.5">
            <h4 className="font-bold text-white uppercase tracking-wider text-[11px]">
              {f.pharmaciesTitle}
            </h4>
            <ul className="space-y-1 text-slate-400">
              <li>• {f.pharmacy1}</li>
              <li>• {f.pharmacy2}</li>
              <li>• {f.pharmacy3}</li>
              <li>• {f.pharmacy4}</li>
              <li className="text-emerald-400 font-semibold pt-1">
                {f.deliveryPromise}
              </li>
            </ul>
          </div>

          {/* Col 4: Language Selection */}
          <div className="space-y-2.5">
            <h4 className="font-bold text-white uppercase tracking-wider text-[11px]">
              {t.languagesTitle}
            </h4>
            <div className="flex flex-wrap gap-1.5">
              <button
                onClick={() => setLanguage('kannada')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  language === 'kannada'
                    ? 'bg-emerald-600 text-white font-bold'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {t.kannadaChoice}
              </button>
              <button
                onClick={() => setLanguage('hindi')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  language === 'hindi'
                    ? 'bg-emerald-600 text-white font-bold'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {t.hindiChoice}
              </button>
              <button
                onClick={() => setLanguage('english')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  language === 'english'
                    ? 'bg-emerald-600 text-white font-bold'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {t.englishChoice}
              </button>
            </div>

            <div className="pt-2 text-[11px] text-slate-500">
              <p className="font-semibold text-slate-400">{f.disclaimerTitle}</p>
              <p className="mt-0.5 leading-snug">{f.disclaimerText}</p>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-6 text-center text-slate-500 text-[11px]">
          <p>{f.copyright}</p>
        </div>
      </div>
    </footer>
  );
};
