/**
 * Language Context supporting Kannada, Hindi, English
 */
import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language, translations } from '../i18n/translations.ts';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (typeof translations)['english'];
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('varur_health_lang');
    if (saved === 'kannada' || saved === 'hindi' || saved === 'english') {
      return saved;
    }
    return 'kannada'; // Default to Kannada for Varur village
  });

  useEffect(() => {
    localStorage.setItem('varur_health_lang', language);
  }, [language]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  const currentTranslations = translations[language] || translations.english;

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t: currentTranslations }}>
      {children}
    </LanguageContext.Provider>
  );
};

export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useLanguage must be used within LanguageProvider');
  return ctx;
}
