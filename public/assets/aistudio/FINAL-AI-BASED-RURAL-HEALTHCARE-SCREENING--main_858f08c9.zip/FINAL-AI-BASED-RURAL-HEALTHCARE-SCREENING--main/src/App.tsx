/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Varur Rural Healthcare System - Main App Component
 */
import React, { useState } from 'react';
import { ThemeProvider } from './context/ThemeContext.tsx';
import { LanguageProvider, useLanguage } from './context/LanguageContext.tsx';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { Navbar } from './components/Navbar.tsx';
import { HomePage } from './components/HomePage.tsx';
import { HealthScreeningWizard } from './components/HealthScreeningWizard.tsx';
import { VarurVillageDirectory } from './components/VarurVillageDirectory.tsx';
import { MedicalsAndOrdersModal } from './components/MedicalsAndOrdersModal.tsx';
import { HistoryPage } from './components/HistoryPage.tsx';
import { UserProfileDashboard } from './components/UserProfileDashboard.tsx';
import { AdminPanel } from './components/AdminPanel.tsx';
import { VoiceAssistantModal } from './components/VoiceAssistantModal.tsx';
import { AuthModals } from './components/AuthModals.tsx';
import { Footer } from './components/Footer.tsx';
import { Mic } from 'lucide-react';

function AppContent() {
  const { user, isAdmin } = useAuth();
  const { t } = useLanguage();
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [voiceAssistantOpen, setVoiceAssistantOpen] = useState<boolean>(false);
  const [authModalType, setAuthModalType] = useState<'login' | 'register' | null>(null);

  // Suggested medicines passed to order page from screening
  const [suggestedOrderMedicines, setSuggestedOrderMedicines] = useState<string[]>([]);
  const [orderHouseId, setOrderHouseId] = useState<string>('VRR-H01');

  const handleOrderMedicinesForScreening = (medicines: string[], houseId: string) => {
    setSuggestedOrderMedicines(medicines);
    setOrderHouseId(houseId);
    setCurrentTab('orders');
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors duration-200">
      {/* Navbar with Day/Night toggle, 3-language switcher, Auth & Voice assistant */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        openVoiceAssistant={() => setVoiceAssistantOpen(true)}
        openLoginModal={() => setAuthModalType('login')}
        openRegisterModal={() => setAuthModalType('register')}
      />

      {/* Main Tab Content */}
      <main className="flex-1">
        {currentTab === 'home' && (
          <HomePage
            onStartScreening={() => setCurrentTab('screening')}
            openVoiceAssistant={() => setVoiceAssistantOpen(true)}
            onNavigateToTab={(tab) => setCurrentTab(tab)}
            openLoginModal={() => setAuthModalType('login')}
            openRegisterModal={() => setAuthModalType('register')}
          />
        )}

        {currentTab === 'screening' && (
          <HealthScreeningWizard
            onOrderMedicinesForScreening={handleOrderMedicinesForScreening}
            onNavigateToHospitals={() => setCurrentTab('hospitals')}
          />
        )}

        {currentTab === 'hospitals' && (
          <VarurVillageDirectory
            onOrderMedicinesFromStore={(_storeId) => setCurrentTab('orders')}
          />
        )}

        {currentTab === 'orders' && (
          <MedicalsAndOrdersModal
            initialMedicines={suggestedOrderMedicines}
            initialHouseId={orderHouseId}
          />
        )}

        {currentTab === 'history' && (
          <HistoryPage
            onStartScreening={() => setCurrentTab('screening')}
            onNavigateToOrders={() => setCurrentTab('orders')}
          />
        )}

        {currentTab === 'profile' && (
          <UserProfileDashboard
            onStartScreening={() => setCurrentTab('screening')}
            onNavigateToOrders={() => setCurrentTab('orders')}
          />
        )}

        {currentTab === 'admin' && <AdminPanel />}
      </main>

      {/* Floating Action Trigger for Multilingual Voice Assistant - 100% Isolated */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-2.5">
        <button
          onClick={() => setVoiceAssistantOpen(true)}
          className="group flex items-center gap-2.5 px-4 py-3 rounded-full bg-linear-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-xs sm:text-sm shadow-xl shadow-emerald-600/30 hover:shadow-2xl transition-all hover:scale-105"
          title={t.voiceAssistant}
        >
          <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
            <Mic className="w-4 h-4 text-white animate-pulse" />
          </div>
          <span>{t.voiceAssistant}</span>
        </button>
      </div>

      {/* Voice Assistant Modal with UI navigation capability */}
      <VoiceAssistantModal
        isOpen={voiceAssistantOpen}
        onClose={() => setVoiceAssistantOpen(false)}
        onNavigate={(tab) => {
          setCurrentTab(tab);
          setVoiceAssistantOpen(false);
        }}
      />

      {/* Auth Modals (Login & Register) */}
      <AuthModals
        type={authModalType}
        onClose={() => setAuthModalType(null)}
        onSwitchType={(type) => setAuthModalType(type)}
      />

      {/* Footer */}
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <AuthProvider>
          <AppContent />
        </AuthProvider>
      </LanguageProvider>
    </ThemeProvider>
  );
}
